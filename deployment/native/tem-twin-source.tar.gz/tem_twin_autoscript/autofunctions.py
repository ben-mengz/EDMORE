"""
Image-based auto functions for the twin. They only use camera frames and control changes, never the
twin's hidden misalignments, so they behave like the routines on a real instrument.

- Beam-tilt autofocus: tilting the beam by ±t shifts the image by ±Δf·t. The shift between the two
  images gives the defocus Δf, which is removed with the objective lens or, with
  focus_method="Stage_Z", with the stage height (eucentric focus).
- Rotation-centre alignment: wobbling the focus by ±Δ shifts the image by Δ·τ when the beam is
  tilted by τ from the objective axis. The shift gives τ, which is removed with beam tilt.
- Objective autostigmator: minimises the anisotropy of the Thon rings of amorphous carbon in the
  frame's power spectrum by coordinate descent on the objective stigmator.
"""

import logging

import numpy as np
from autoscript_tem_microscope_client import structures as st

log = logging.getLogger("tem_twin.auto")


# ------------------------------------------------------------------ image helpers
def _window(n):
    w = np.hanning(n)
    return np.outer(w, w)


def image_shift(a, b):
    """Shift (dx, dy) in pixels, x right and y up, that moves the content of image a onto image b."""
    n = a.shape[0]
    c = slice(n // 4, 3 * n // 4)
    a = a[c, c]; b = b[c, c]
    w = _window(a.shape[0])
    A = np.fft.fft2((a - a.mean()) * w)
    B = np.fft.fft2((b - b.mean()) * w)
    R = B * np.conj(A)
    R /= np.abs(R) + 1e-12
    r = np.fft.ifft2(R).real
    m = r.shape[0]
    j, i = np.unravel_index(np.argmax(r), r.shape)

    def sub(v0, vm, vp):
        d = vm - 2 * v0 + vp
        return 0.0 if d == 0 else 0.5 * (vm - vp) / d
    dx = i + sub(r[j, i], r[j, (i - 1) % m], r[j, (i + 1) % m])
    dy = j + sub(r[j, i], r[(j - 1) % m, i], r[(j + 1) % m, i])
    dx = dx - m if dx > m / 2 else dx
    dy = dy - m if dy > m / 2 else dy
    return float(dx), float(-dy)          # rows run downwards; report y upwards


def _frame(t):
    img, info = t.link.frame()
    return img, info


def _px_nm(info):
    from .handlers import MAGS
    return 2 * MAGS[info["S"]["mag"]][3] / info["w"]


# ------------------------------------------------------------------ beam-tilt autofocus
def beam_tilt_autofocus(t, settings):
    S = t.S()
    if S["mode"] != "img":
        raise ValueError("Beam-tilt autofocus needs imaging mode")
    iters = int(settings.maximum_iterations) if settings and settings.maximum_iterations else 5
    target = (settings.iterate_to_defocus if settings and settings.iterate_to_defocus is not None else 0.0) / 1e-9
    use_stage = bool(settings and settings.focus_method == "Stage_Z")
    b0 = dict(S["btilt"])
    tilt, df = 0.25, 0.0                            # mrad; start small so a large defocus stays inside the correlation window
    for _ in range(iters):
        t.set(btilt={"x": b0["x"] + tilt, "y": b0["y"]}); ip, info = _frame(t)
        t.set(btilt={"x": b0["x"] - tilt, "y": b0["y"]}); im, _ = _frame(t)
        t.set(btilt=b0)
        px = _px_nm(info)
        dx, _dy = image_shift(im, ip)
        df = -dx * px / (2 * tilt * 1e-3)          # image moves by -Δf·tilt: Δf in nm from the objective's focal plane
        err = df - target
        if use_stage:
            t.set(stage={"z": t.S()["stage"]["z"] - err / 1000.0})
        else:
            t.set(dfc=t.S()["dfc"] - err)
        log.info("beam-tilt autofocus (tilt %.2f mrad): measured %.0f nm, corrected %.0f nm with %s",
                 tilt, df, err, "stage Z" if use_stage else "objective")
        if abs(err) < max(10.0, 2 * px):
            break
        # next tilt: large enough for precision, small enough that the residual shift stays within ~20 px
        tilt = float(np.clip(20 * px / (2 * max(abs(err) * 0.3, 1.0) * 1e-3), 0.25, 3.0))
    return st.RunBeamTiltAutoFocusResults(0.0, df * 1e-9, st.Point(0.0, 0.0))


# ------------------------------------------------------------------ rotation centre
def rotation_center(t, settings):
    iters = (settings.maximum_number_of_iterations if settings and settings.maximum_number_of_iterations else 6)
    S = t.S()
    if S["mode"] != "img":
        return st.RunRotationCenterAlignmentResults("Bad", "Rotation-centre alignment needs imaging mode")
    from .handlers import MAGS
    px_nm = 2 * MAGS[S["mag"]][3] / 256
    wob = float(np.clip(2500 * px_nm, 150, 8000))       # focus wobble (nm): about 5 px of image shift per mrad of tilt
    tau = (99.0, 99.0)
    for _ in range(int(iters)):
        f0 = t.S()["dfc"]
        t.set(dfc=f0 + wob); ip, info = _frame(t)
        t.set(dfc=f0 - wob); im, _ = _frame(t)
        t.set(dfc=f0)
        dx, dy = image_shift(im, ip)
        px = _px_nm(info)
        tau = (-dx * px / (2 * wob * 1e-3), -dy * px / (2 * wob * 1e-3))   # mrad
        b = t.S()["btilt"]
        t.set(btilt={"x": b["x"] - tau[0], "y": b["y"] - tau[1]})
        log.info("rotation centre: residual beam tilt %.2f, %.2f mrad", *tau)
        if np.hypot(*tau) < 0.1:
            break
    ok = np.hypot(*tau) < 0.3
    return st.RunRotationCenterAlignmentResults("Good" if ok else "Improved",
                                                "Residual tilt %.2f mrad after correction" % np.hypot(*tau))


# ------------------------------------------------------------------ objective autostigmator
LAMBDA_NM = {120: 0.003349, 200: 0.002508}
CS_NM = 1.2e6


def power_spectrum(frames):
    n = frames[0].shape[0]
    w = _window(n)
    P = np.zeros((n, n))
    for img in frames:
        P += np.abs(np.fft.fftshift(np.fft.fft2((img - img.mean()) * w))) ** 2
    return P / len(frames)


def fit_defocus_map(P, px_nm, lam, sectors=24, dmin=-3000.0, dmax=600.0, cs_nm=CS_NM):
    """Defocus seen along each direction of the power spectrum, from the Thon-ring positions.

    Returns sector angles (world frame, x right / y up) and the best-matching defocus per sector.
    """
    n = P.shape[0]
    c = n // 2
    jj, ii = np.indices(P.shape)
    kx = (ii - c) / (n * px_nm)
    ky = -(jj - c) / (n * px_nm)
    k = np.hypot(kx, ky)
    ang = np.mod(np.arctan2(ky, kx), np.pi)
    kmax = 0.5 / px_nm
    kb = np.linspace(0.12 * kmax, 0.62 * kmax, 90)
    band = (k >= kb[0]) & (k < kb[-1])
    rb = np.clip(np.searchsorted(kb, k[band]) - 1, 0, len(kb) - 2)
    sb = np.clip((ang[band] / np.pi * sectors).astype(int), 0, sectors - 1)
    logP = np.log(P[band] + 1e-12)
    prof = np.zeros((sectors, len(kb) - 1)); cnt = np.zeros_like(prof)
    np.add.at(prof, (sb, rb), logP); np.add.at(cnt, (sb, rb), 1)
    prof /= np.maximum(cnt, 1)
    kc = 0.5 * (kb[1:] + kb[:-1])
    # remove the smooth background so only the ring oscillation remains
    from numpy.lib.stride_tricks import sliding_window_view
    pad = np.pad(prof, ((0, 0), (7, 7)), mode="edge")
    bg = sliding_window_view(pad, 15, axis=1).mean(axis=2)
    osc = prof - bg
    osc = (osc - osc.mean(axis=1, keepdims=True)) / (osc.std(axis=1, keepdims=True) + 1e-9)
    d = np.arange(dmin, dmax, 2.0)
    chi = np.pi * lam * d[:, None] * kc[None, :] ** 2 + 0.5 * np.pi * cs_nm * lam ** 3 * kc[None, :] ** 4
    model = np.sin(chi) ** 2
    model = (model - model.mean(axis=1, keepdims=True)) / (model.std(axis=1, keepdims=True) + 1e-9)
    score = osc @ model.T / osc.shape[1]                       # sectors × candidates
    best = d[np.argmax(score, axis=1)]
    quality = score.max(axis=1)
    theta = (np.arange(sectors) + 0.5) * np.pi / sectors
    return theta, best, quality


def fit_astigmatism(theta, d, q, qmin=0.2):
    """Robust fit of Δf(θ) = Δf0 + a·cos2θ + b·sin2θ to the per-direction defocus.

    Sectors with weak ring contrast, sectors that locked onto a different ring family (far from the median) and
    then residual outliers are rejected. Returns (Δf0, [a, b], rms) or None.
    """
    good = q > max(qmin, 0.5 * float(np.median(q)))
    if good.sum() < 8:
        return None
    good &= np.abs(d - np.median(d[good])) < 800.0
    if good.sum() < 8:
        return None
    keep = good.copy()
    for _ in range(5):
        X = np.column_stack([np.ones(keep.sum()), np.cos(2 * theta[keep]), np.sin(2 * theta[keep])])
        coef, *_ = np.linalg.lstsq(X, d[keep], rcond=None)
        r = coef[0] + coef[1] * np.cos(2 * theta) + coef[2] * np.sin(2 * theta) - d
        lim = max(15.0, 3.0 * 1.4826 * np.median(np.abs(r[keep])))
        new_keep = good & (np.abs(r) < lim)
        if new_keep.sum() < 8 or np.array_equal(new_keep, keep):
            break
        keep = new_keep
    rms = float(np.sqrt(np.mean(r[keep] ** 2)))
    return float(coef[0]), np.array(coef[1:]), rms


def measure_astigmatism(t, frames=4):
    imgs = []
    info = None
    for _ in range(frames):
        img, info = _frame(t)
        imgs.append(img)
    lam = LAMBDA_NM.get(int(info["S"]["ht"]), LAMBDA_NM[200])
    theta, d, q = fit_defocus_map(power_spectrum(imgs), _px_nm(info), lam)
    fit = fit_astigmatism(theta, d, q)
    if fit is None:
        return None
    return {"defocus": fit[0], "vec": fit[1], "residual": fit[2], "quality": float(q.mean())}


def objective_autostigmator(t, settings):
    S = t.S()
    if S["mode"] != "img" or S["mag"] < 2:
        return st.RunObjectiveAutoStigmatorResults(0.0, 0.0, 1.0, False)
    st0 = np.array([S["objstig"]["x"], S["objstig"]["y"]], float)
    f0 = S["dfc"]
    t.set(dfc=f0 - 400)                                   # underfocus so several Thon rings are in the band
    try:
        m0 = measure_astigmatism(t)
        if m0 is None:
            log.info("objective stigmator: no Thon rings found (move to amorphous film)")
            return st.RunObjectiveAutoStigmatorResults(0.0, 0.0, 1.0, False)
        # calibrate the stigmator response (measured astigmatism per stigmator step)
        step = 20.0
        cols = []
        for e in (np.array([step, 0.0]), np.array([0.0, step])):
            v = st0 + e
            t.set(objstig={"x": float(v[0]), "y": float(v[1])})
            mi = measure_astigmatism(t)
            cols.append(((mi["vec"] if mi else m0["vec"]) - m0["vec"]) / step)
        M = np.column_stack(cols)
        if not (0.3 < abs(np.linalg.det(M)) < 3 and np.linalg.cond(M) < 4):
            log.info("objective stigmator: calibration unreliable, assuming a unit response")
            M = np.eye(2)

        def step_from(vec):
            dv = -np.linalg.solve(M, vec)
            n = np.hypot(*dv)
            return dv * (100.0 / n) if n > 100.0 else dv   # never move more than 100 nm in one go

        cur = st0 + step_from(m0["vec"])
        t.set(objstig={"x": float(cur[0]), "y": float(cur[1])})
        m = measure_astigmatism(t)
        maxit = int(settings.maximum_iterations) if settings and settings.maximum_iterations else 3
        for _ in range(max(0, min(maxit, 3) - 1)):
            if m is None or np.hypot(*m["vec"]) < 3:
                break
            cur = cur + step_from(m["vec"])
            t.set(objstig={"x": float(cur[0]), "y": float(cur[1])})
            m = measure_astigmatism(t)
    finally:
        t.set(dfc=f0)
    rem = m["vec"] if m else np.zeros(2)
    amp = float(np.hypot(*rem))
    orient = float(np.arctan2(rem[1], rem[0]) / 2)
    reliable = bool(m is not None and m["residual"] < 25)
    log.info("objective stigmator: initial %.1f nm, remaining %.1f nm (fit rms %.1f nm)",
             np.hypot(*m0["vec"]), amp, m["residual"] if m else -1)
    return st.RunObjectiveAutoStigmatorResults(amp * 1e-9, orient, float(m["residual"] * 1e-9 if m else 1.0), reliable)
