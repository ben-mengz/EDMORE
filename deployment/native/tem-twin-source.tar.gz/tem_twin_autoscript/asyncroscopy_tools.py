"""Adapt asyncroscopy's ElectronMicroscope commands to the TEM Twin SDK.

Based on pycroscopy/asyncroscopy (MIT), electron_microscope.py and
auto_script.py. See ASYNCROSCOPY_LICENSE. No Tango server or second simulator
is created: every instrument operation uses the shared AutoScript client.
"""

import base64
import math
import time

import numpy as np


# TEM auto_focus upstream calls an objective auto-stigmator, not focus-only.
# Keep one unambiguous, verified implementation under its existing skill name.
ALIGNMENT_OVERRIDES = {"auto_focus": "align_objective_stigmation"}
UNSUPPORTED_COMMANDS = {
    "acquire_spectrum": "No simulated spectrum detector",
    "acquire_scanned_image": "No STEM scanning detector",
    "acquire_scanned_data_advanced": "No 4D-STEM simulation",
    "place_beam": "No paused STEM scan position",
    "place_beam_list": "No paused STEM scan position",
    "set_fov": "Upstream controls STEM scan FOV, not TEM magnification",
    "get_fov": "Upstream controls STEM scan FOV, not TEM magnification",
    "calibrate_screen_current": "No monochromator focus model",
    "set_screen_current": "No monochromator current calibration model",
    "set_diffraction_shift": "Upstream angular contract conflicts with image-shift metres",
    "get_diffraction_shift": "No calibrated angular diffraction-shift model",
    "get_data_from_key": "No DATA/Tiled service; use acquisition image_ref and cache",
}


def finite(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError("Control values must be finite")
    return value


def vector(value, length):
    if len(value) != length:
        raise ValueError(f"Expected exactly {length} values")
    return [finite(item) for item in value]


class AsyncroscopyTools:
    def __init__(self, service):
        self.service = service
        self.images = []

    def blank_beam(self) -> dict:
        """Blank the TEM beam through AutoScript."""
        return self.service.configure_imaging(blanked=True)

    def unblank_beam(self) -> dict:
        """Unblank the TEM beam through AutoScript."""
        return self.service.configure_imaging(blanked=False)

    def set_column_valves(self, state: str) -> dict:
        """Set column valves to 'open' or 'close'."""
        if state not in ("open", "close"):
            raise ValueError("state must be open or close")
        with self.service.client() as m:
            getattr(m.vacuum.column_valves, state)()
            return {"state": str(m.vacuum.column_valves.state)}

    def set_defocus(self, defocus: float) -> dict:
        """Set absolute defocus in metres (asyncroscopy convention)."""
        return self.service.set_defocus(finite(defocus))

    def get_defocus(self) -> float:
        """Read defocus in metres."""
        with self.service.client() as m:
            return float(m.optics.defocus)

    def set_image_shift(self, shift: list[float]) -> list[float]:
        """Set TEM image shift [x, y] in metres; not STEM beam shift."""
        x, y = vector(shift, 2)
        with self.service.client() as m:
            m.optics.deflectors.image_shift = self.service.types["point"](x, y)
            return self.get_image_shift()

    def get_image_shift(self) -> list[float]:
        """Read TEM image shift [x, y] in metres."""
        with self.service.client() as m:
            p = m.optics.deflectors.image_shift
            return [float(p.x), float(p.y)]

    def set_beam_tilt(self, tilt: list[float]) -> dict:
        """Set absolute beam tilt [x, y] in radians."""
        return self.service.set_beam_tilt(*vector(tilt, 2))

    def get_beam_tilt(self) -> list[float]:
        """Read beam tilt [x, y] in radians."""
        with self.service.client() as m:
            p = m.optics.deflectors.beam_tilt
            return [float(p.x), float(p.y)]

    def get_parameters(self) -> dict:
        """Read supported TEM parameters via AutoScript; lengths m, angles rad."""
        return self.service.get_alignment_state()

    def set_screen(self, position: str) -> dict:
        """Insert or retract the screen: in/insert/inserted or out/retract/retracted."""
        normalized = position.lower()
        if normalized not in ("in", "insert", "inserted", "out", "retract", "retracted"):
            raise ValueError("Unknown screen position")
        with self.service.client() as m:
            screen = m.detectors.screen
            if normalized in ("in", "insert", "inserted"):
                screen.insert()
            else:
                screen.retract()
            return {"position": str(screen.position)}

    def get_screen_current(self) -> float:
        """Read screen current in pA, matching asyncroscopy (not amperes)."""
        with self.service.client() as m:
            return float(m.detectors.screen.measure_current()) * 1e12

    def get_stage(self) -> list[float]:
        """Read [x, y, z, alpha, beta]; lengths metres, angles degrees."""
        with self.service.client() as m:
            p = m.specimen.stage.position
            return [float(p.x), float(p.y), float(p.z), math.degrees(p.a), math.degrees(p.b)]

    def move_stage(self, position: list[float]) -> list[float]:
        """Move to [x,y,z,alpha,beta] in metres/degrees. Unmodelled tilt changes are rejected."""
        x, y, z, a, b = vector(position, 5)
        if abs(x) > 1e-3 or abs(y) > 1e-3 or abs(z) > 375e-6:
            raise ValueError("Stage target exceeds Twin axis limits")
        with self.service.client() as m:
            current = self.get_stage()
            if not (math.isclose(a, current[3], abs_tol=1e-10) and math.isclose(b, current[4], abs_tol=1e-10)):
                raise ValueError("Stage tilt is not modelled by this TEM GUI")
            target = self.service.types["stage_position"](x=x, y=y, z=z)
            m.specimen.stage.absolute_move(target)
            self.service._wait_stage(m.specimen.stage)
            return self.get_stage()

    def acquire_camera_image(self, imsize: int = 256, exposure_time: float = 0.005) -> dict:
        """Acquire BM-Ceta through AutoScript. Return image_ref and metadata, not a Tiled key.

        The eight most recent images are available with get_image_data_cached;
        index 0 is the newest. image_ref is accepted by calculate_alignment.
        """
        if imsize not in (256, 512, 1024):
            raise ValueError("imsize must be 256, 512 or 1024")
        if not 0 < finite(exposure_time) <= 10:
            raise ValueError("exposure_time must be in (0, 10] seconds")
        started = time.perf_counter()
        with self.service.client() as m:
            image = self.service._acquire_camera_image(m, "BM-Ceta", imsize, exposure_time)
            array = np.asarray(image.data).copy()
            self.images.insert(0, array)
            del self.images[8:]
            return {"image_ref": self.service.calculator.remember(array),
                    "shape": list(array.shape), "dtype": str(array.dtype),
                    "pixel_size_m": float(image.metadata.binary_result.pixel_size.x),
                    "cache_index": 0, "mean": float(array.mean()),
                    "acquisition_seconds": time.perf_counter() - started}

    def get_image_data_cached(self, index: int = 0) -> dict:
        """Return a cached AutoScript image as base64 bytes with shape/dtype; newest index is 0."""
        with self.service._lock:
            if not 0 <= index < len(self.images):
                raise ValueError("No cached image at index; acquire_camera_image first")
            array = self.images[index]
            return {"shape": list(array.shape), "dtype": str(array.dtype),
                    "encoding": "base64", "data": base64.b64encode(array.tobytes()).decode("ascii")}


COMMANDS = (
    "blank_beam", "unblank_beam", "set_column_valves", "set_defocus", "get_defocus",
    "set_image_shift", "get_image_shift", "set_beam_tilt", "get_beam_tilt",
    "get_parameters", "set_screen", "get_screen_current", "get_stage", "move_stage",
    "acquire_camera_image", "get_image_data_cached",
)


def register_asyncroscopy_tools(mcp, service):
    adapter = AsyncroscopyTools(service)
    for name in COMMANDS:
        readonly = name.startswith("get_")
        mcp.tool(annotations={"readOnlyHint": readonly, "destructiveHint": not readonly,
                              "openWorldHint": False})(getattr(adapter, name))
