"""Granular MCP tools for an AutoScript TEM server.

Atomic AutoScript controls remain available. Six bounded phase tools reuse
autoalign.py; EDMORE owns their order, approval, and execution-result review.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import threading
import time
from contextlib import contextmanager
from typing import Any, Callable

import numpy as np


def _autoscript_types():
    from autoscript_tem_microscope_client import TemMicroscopeClient
    from autoscript_tem_microscope_client.enumerations import CameraType, FocusMethod
    from autoscript_tem_microscope_client.structures import (
        Point,
        RunBeamTiltAutoFocusSettings,
        RunObjectiveAutoStigmatorSettings,
        RunRotationCenterAlignmentSettings,
        StagePosition,
    )

    return {
        "client": TemMicroscopeClient,
        "camera": CameraType,
        "focus_method": FocusMethod,
        "point": Point,
        "beam_focus_settings": RunBeamTiltAutoFocusSettings,
        "objective_stig_settings": RunObjectiveAutoStigmatorSettings,
        "rotation_center_settings": RunRotationCenterAlignmentSettings,
        "stage_position": StagePosition,
    }


def _point(value: Any) -> dict[str, float]:
    return {"x": float(value.x), "y": float(value.y)}


def _stage(value: Any) -> dict[str, float]:
    return {name: float(getattr(value, name)) for name in ("x", "y", "z", "a", "b")}


class AutoScriptToolService:
    """Thread-safe, lazily connected AutoScript client used by MCP tools."""

    VECTOR_CONTROLS = {
        "beam_shift": ("optics", "deflectors", "beam_shift"),
        "beam_tilt": ("optics", "deflectors", "beam_tilt"),
        "gun_tilt": ("optics", "deflectors", "gun_tilt"),
        "condenser_stigmator": ("optics", "stigmators", "condenser_stigmator"),
        "objective_stigmator": ("optics", "stigmators", "objective_stigmator"),
    }

    def __init__(
        self,
        autoscript_host: str = "127.0.0.1",
        autoscript_port: int = 7521,
        client_factory: Callable[[], Any] | None = None,
        type_factory: Callable[[], dict[str, Any]] = _autoscript_types,
        operation_settle_seconds: float = 0.15,
        motion_timeout_seconds: float = 60.0,
        operation_lock=None,
    ):
        self.host = autoscript_host
        self.port = autoscript_port
        self._type_factory = type_factory
        self._types: dict[str, Any] | None = None
        self._client_factory = client_factory
        self._client: Any | None = None
        self._lock = threading.RLock()
        from .operation_lock import OperationLock
        self._operation_lock = operation_lock or OperationLock(
            os.environ.get("TEM_NODE_OPERATION_LOCK"),
            timeout_seconds=max(300.0, motion_timeout_seconds),
        )
        self.operation_settle_seconds = max(0.0, float(operation_settle_seconds))
        self.motion_timeout_seconds = max(0.1, float(motion_timeout_seconds))
        from .alignment_calculation import AlignmentCalculator
        self.calculator = AlignmentCalculator()

    @property
    def types(self) -> dict[str, Any]:
        if self._types is None:
            self._types = self._type_factory()
        return self._types

    def _new_client(self):
        factory = self._client_factory or self.types["client"]
        client = factory()
        client.connect(self.host, self.port)
        return client

    def _disconnect(self):
        client, self._client = self._client, None
        if client is not None:
            try:
                client.disconnect()
            except Exception:
                pass

    @contextmanager
    def client(self):
        with self._operation_lock:
            with self._lock:
                if self._client is None:
                    self._client = self._new_client()
                try:
                    yield self._client
                except Exception:
                    self._disconnect()
                    raise

    @staticmethod
    def _resolve(root: Any, path: tuple[str, ...]):
        value = root
        for name in path:
            value = getattr(value, name)
        return value

    def _align(self, phase: str) -> dict[str, Any]:
        from .alignment_tools import run_alignment
        with self.client() as microscope:
            return run_alignment(
                microscope,
                phase,
                settle_seconds=self.operation_settle_seconds,
                motion_timeout_seconds=self.motion_timeout_seconds,
            )

    def _settle(self):
        if self.operation_settle_seconds:
            time.sleep(self.operation_settle_seconds)

    def _wait_stage(self, stage):
        deadline = time.monotonic() + self.motion_timeout_seconds
        while bool(getattr(stage, "is_moving", False)):
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Stage did not finish within {self.motion_timeout_seconds:g} seconds"
                )
            time.sleep(0.1)
        self._settle()

    def _wait_aperture(self, aperture, expected_state: str):
        deadline = time.monotonic() + self.motion_timeout_seconds
        while str(aperture.insertion_state).lower() != expected_state.lower():
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"C2 aperture did not reach {expected_state} within "
                    f"{self.motion_timeout_seconds:g} seconds"
                )
            time.sleep(0.1)
        self._settle()

    def _acquire_camera_image(self, microscope, camera, image_size_px, exposure_s):
        # AutoScript acquisition is synchronous; the pre-delay lets recent lens,
        # deflector, aperture, and stage changes become visible in the returned frame.
        self._settle()
        return microscope.acquisition.acquire_camera_image(camera, image_size_px, exposure_s)

    def align_beam_and_c2(self) -> dict[str, Any]:
        """Align beam shift/C2 with autoalign.py and verify spot <0.02, spread <0.01. Mutates controls; no automatic retry."""
        return self._align("beam")

    def align_gun_tilt(self) -> dict[str, Any]:
        """Optimize gun tilt with autoalign.py; verify probe current gain <0.5%. Mutates controls; no automatic retry."""
        return self._align("gun")

    def align_condenser_stigmation(self) -> dict[str, Any]:
        """Correct condenser stig with autoalign.py; verify ellipticity <0.03. Mutates controls; no automatic retry."""
        return self._align("c2stig")

    def align_eucentric_z(self) -> dict[str, Any]:
        """Correct stage Z with autoalign.py; verify residual Z correction <100 nm. Moves stage; no automatic retry."""
        return self._align("z")

    def align_rotation_center(self) -> dict[str, Any]:
        """Align rotation centre at eucentric focus; verify tilt offset <0.8 mrad. Requires aligned Z; no automatic retry."""
        return self._align("rot")

    def align_objective_stigmation(self) -> dict[str, Any]:
        """Correct objective stig with autoalign.py; verify Thon-ring astigmatism <3 nm. Requires aligned Z; no automatic retry."""
        return self._align("ostig")

    def microscope_status(self) -> dict[str, Any]:
        """Check the AutoScript connection and identify the target server."""
        with self.client() as microscope:
            system = microscope.service.system
            return {
                "connected": True,
                "host": self.host,
                "port": self.port,
                "name": str(system.name),
                "serial_number": str(system.serial_number),
                "autoscript_version": str(microscope.service.autoscript.server.version),
            }

    def get_alignment_state(self) -> dict[str, Any]:
        """Read the controls needed by an alignment workflow, using SI units."""
        with self.client() as m:
            deflectors = m.optics.deflectors
            stigmators = m.optics.stigmators
            c2 = m.optics.aperture_mechanisms.C2
            return {
                "units": {
                    "beam_shift": "m",
                    "beam_tilt": "rad",
                    "gun_tilt": "logical",
                    "stigmators": "logical",
                    "c2_position": "m",
                    "stage": "m and rad",
                    "defocus": "m",
                    "beam_diameter": "m",
                },
                "projector_mode": str(m.optics.projector_mode),
                "magnification": float(m.optics.magnification.value.nominal),
                "beam_diameter": float(m.optics.beam_diameter),
                "defocus": float(m.optics.defocus),
                "beam_blanked": bool(m.optics.is_beam_blanked),
                "beam_shift": _point(deflectors.beam_shift),
                "beam_tilt": _point(deflectors.beam_tilt),
                "gun_tilt": _point(deflectors.gun_tilt),
                "condenser_stigmator": _point(stigmators.condenser_stigmator),
                "objective_stigmator": _point(stigmators.objective_stigmator),
                "c2": {"state": str(c2.insertion_state), "position": _point(c2.position)},
                "stage": _stage(m.specimen.stage.position),
            }

    def configure_imaging(
        self,
        magnification: float | None = None,
        beam_diameter_m: float | None = None,
        defocus_m: float | None = None,
        projector_mode: str | None = None,
        blanked: bool | None = None,
    ) -> dict[str, Any]:
        """Set basic imaging conditions; all lengths are metres."""
        with self.client() as m:
            if projector_mode is not None:
                if projector_mode not in ("Imaging", "Diffraction"):
                    raise ValueError("projector_mode must be Imaging or Diffraction")
                m.optics.projector_mode = projector_mode
            if magnification is not None:
                available = list(m.optics.magnification.available_values)
                if not available:
                    raise RuntimeError("AutoScript returned no available magnifications")
                m.optics.magnification.value = min(
                    available, key=lambda value: abs(float(value.nominal) - float(magnification))
                )
            if beam_diameter_m is not None:
                if beam_diameter_m <= 0:
                    raise ValueError("beam_diameter_m must be positive")
                m.optics.beam_diameter = float(beam_diameter_m)
            if defocus_m is not None:
                m.optics.defocus = float(defocus_m)
            if blanked is not None:
                m.optics.blank() if blanked else m.optics.unblank()
            self._settle()
            return {
                "projector_mode": str(m.optics.projector_mode),
                "magnification": float(m.optics.magnification.value.nominal),
                "beam_diameter_m": float(m.optics.beam_diameter),
                "defocus_m": float(m.optics.defocus),
                "blanked": bool(m.optics.is_beam_blanked),
            }

    def measure_beam(
        self,
        beam_fraction_of_fov: float = 0.02,
        image_size_px: int = 256,
        exposure_s: float = 0.005,
        camera: str = "BM-Ceta",
    ) -> dict[str, Any]:
        """Measure beam centroid, radius, and ellipticity from a camera frame.

        Centroid and radius use field half-widths: x=1 is the right edge and
        y=1 is the top edge. This is an observation tool and does not judge
        whether the beam is aligned.
        """
        if not 0 < beam_fraction_of_fov <= 2:
            raise ValueError("beam_fraction_of_fov must be in (0, 2]")
        if image_size_px < 32 or image_size_px > 4096:
            raise ValueError("image_size_px must be between 32 and 4096")
        if exposure_s <= 0:
            raise ValueError("exposure_s must be positive")
        with self.client() as m:
            first = self._acquire_camera_image(m, camera, image_size_px, exposure_s)
            pixel_size_m = float(first.metadata.binary_result.pixel_size.x)
            fov_m = pixel_size_m * image_size_px
            m.optics.beam_diameter = float(beam_fraction_of_fov) * fov_m
            image = self._acquire_camera_image(m, camera, image_size_px, exposure_s)
            data = np.asarray(image.data, dtype=np.float64)
            peak = float(np.percentile(data, 99.95))
            threshold = 0.25 * peak
            ys, xs = np.nonzero(data > threshold)
            result: dict[str, Any] = {
                "camera": camera,
                "image_size_px": int(image_size_px),
                "exposure_s": float(exposure_s),
                "pixel_size_m": pixel_size_m,
                "field_of_view_m": fov_m,
                "requested_beam_fraction": float(beam_fraction_of_fov),
                "peak_counts": peak,
                "mean_counts": float(np.mean(data)),
                "std_counts": float(np.std(data)),
                "threshold_counts": threshold,
                "illuminated_pixels": int(len(xs)),
            }
            if len(xs) < 4 or peak <= 0:
                return {**result, "beam_found": False}
            n_y, n_x = data.shape
            u = (xs + 0.5) / (n_x / 2) - 1
            v = 1 - (ys + 0.5) / (n_y / 2)
            centroid = np.array([u.mean(), v.mean()])
            covariance = np.cov(np.vstack([u - centroid[0], v - centroid[1]]))
            major, minor = sorted(np.linalg.eigvalsh(covariance), reverse=True)
            ellipticity = 1 - np.sqrt(max(minor, 1e-12) / max(major, 1e-12))
            return {
                **result,
                "beam_found": True,
                "centroid_half_fov": {"x": float(centroid[0]), "y": float(centroid[1])},
                "centroid_distance_half_fov": float(np.hypot(*centroid)),
                "radius_half_fov": float(2 * np.sqrt(max((major + minor) / 2, 0))),
                "ellipticity": float(ellipticity),
            }

    def measure_screen_current(self, samples: int = 3) -> dict[str, Any]:
        """Measure fluorescent-screen current repeatedly and report amperes."""
        if samples < 1 or samples > 100:
            raise ValueError("samples must be between 1 and 100")
        with self.client() as m:
            values = [float(m.detectors.screen.measure_current()) for _ in range(samples)]
        return {
            "unit": "A",
            "samples": values,
            "mean": float(np.mean(values)),
            "std": float(np.std(values)),
        }

    def measure_condenser_stigmation(
        self,
        probe_step: float = 0.05,
        beam_fraction_of_fov: float = 0.2,
        image_size_px: int = 256,
        exposure_s: float = 0.05,
        camera: str = "BM-Ceta",
    ) -> dict[str, Any]:
        """Measure beam ellipticity and probe four stigmator directions, restoring the control."""
        if probe_step <= 0:
            raise ValueError("probe_step must be positive")
        with self.client() as m:
            stigmators = m.optics.stigmators
            base = stigmators.condenser_stigmator
            result = self.measure_beam(beam_fraction_of_fov, image_size_px, exposure_s, camera)
            baseline = float(result.get("ellipticity", 1.0))
            probes = []
            try:
                for dx, dy in ((probe_step, 0.0), (-probe_step, 0.0), (0.0, probe_step), (0.0, -probe_step)):
                    stigmators.condenser_stigmator = self.types["point"](base.x + dx, base.y + dy)
                    measured = self.measure_beam(beam_fraction_of_fov, image_size_px, exposure_s, camera)
                    probes.append({
                        "delta": {"x": dx, "y": dy},
                        "ellipticity": float(measured.get("ellipticity", 1.0)),
                    })
            finally:
                stigmators.condenser_stigmator = base
        best = min(probes, key=lambda item: item["ellipticity"])
        return {
            **result,
            "metric": "beam_ellipticity",
            "aligned_threshold": 0.03,
            "probe_step": probe_step,
            "probes": probes,
            "best_delta": best["delta"],
            "best_probe_ellipticity": best["ellipticity"],
            "improvement_available": best["ellipticity"] < baseline,
            "control_restored": True,
        }

    def measure_eucentric_offset(
        self,
        camera: str = "BM-Ceta",
        maximum_iterations: int = 6,
    ) -> dict[str, Any]:
        """Measure the required stage-Z correction, restoring stage Z afterwards."""
        if maximum_iterations < 1 or maximum_iterations > 50:
            raise ValueError("maximum_iterations must be between 1 and 50")
        settings = self.types["beam_focus_settings"](
            camera_detector=camera,
            focus_method=self.types["focus_method"].STAGE_Z,
            maximum_iterations=maximum_iterations,
        )
        with self.client() as m:
            stage = m.specimen.stage
            before = stage.position
            try:
                result = m.auto_functions.run_beam_tilt_auto_focus(settings)
                self._wait_stage(stage)
                after = stage.position
                required_delta = float(after.z) - float(before.z)
            finally:
                stage.absolute_move(self.types["stage_position"](z=float(before.z)))
                self._wait_stage(stage)
        return {
            "unit": "m",
            "required_stage_delta_m": required_delta,
            "absolute_offset_m": abs(required_delta),
            "aligned_threshold_m": 100e-9,
            "stage_restored": True,
            "measurement": str(result),
        }

    def measure_rotation_center(
        self,
        maximum_iterations: int = 6,
    ) -> dict[str, Any]:
        """Measure the official rotation-center correction and restore beam tilt."""
        if maximum_iterations < 1 or maximum_iterations > 50:
            raise ValueError("maximum_iterations must be between 1 and 50")
        settings = self.types["rotation_center_settings"](maximum_number_of_iterations=maximum_iterations)
        with self.client() as m:
            deflectors = m.optics.deflectors
            base_tilt = deflectors.beam_tilt
            try:
                result = m.auto_functions.run_rotation_center_alignment(settings)
                corrected = deflectors.beam_tilt
                delta = np.array([float(corrected.x) - float(base_tilt.x), float(corrected.y) - float(base_tilt.y)])
            finally:
                deflectors.beam_tilt = base_tilt
        return {
            "unit": "rad",
            "required_beam_tilt_delta_rad": {"x": float(delta[0]), "y": float(delta[1])},
            "distance_mrad": float(np.hypot(*delta) * 1e3),
            "aligned_threshold_mrad": 0.8,
            "controls_restored": True,
            "measurement": str(result),
        }

    @staticmethod
    def _electron_wavelength_nm(volts: float) -> float:
        h, m0, e, c = 6.62607015e-34, 9.1093837e-31, 1.602176634e-19, 2.99792458e8
        return h / math.sqrt(2 * m0 * e * volts * (1 + e * volts / (2 * m0 * c * c))) * 1e9

    def measure_objective_astigmatism(
        self,
        frames: int = 4,
        image_size_px: int = 256,
        exposure_s: float = 0.2,
        camera: str = "BM-Ceta",
        cs_m: float = 1.2e-3,
        measurement_defocus_m: float = -400e-9,
    ) -> dict[str, Any]:
        """Fit objective astigmatism from AutoScript camera-image power spectra."""
        if frames < 2 or frames > 20:
            raise ValueError("frames must be between 2 and 20")
        from .autofunctions import fit_astigmatism, fit_defocus_map, power_spectrum

        with self.client() as m:
            original_defocus = float(m.optics.defocus)
            images = []
            pixel_size_m = None
            try:
                m.optics.defocus = original_defocus + measurement_defocus_m
                for _ in range(frames):
                    image = self._acquire_camera_image(m, camera, image_size_px, exposure_s)
                    images.append(np.asarray(image.data, dtype=np.float64))
                    pixel_size_m = float(image.metadata.binary_result.pixel_size.x)
                volts = float(m.source.acceleration_voltage.value)
            finally:
                m.optics.defocus = original_defocus
        wavelength_nm = self._electron_wavelength_nm(volts or 200e3)
        theta, defocus, quality = fit_defocus_map(
            power_spectrum(images), float(pixel_size_m) * 1e9, wavelength_nm, cs_nm=cs_m * 1e9
        )
        fit = fit_astigmatism(theta, defocus, quality)
        if fit is None:
            return {
                "measurable": False,
                "reason": "No reliable Thon-ring fit; move to amorphous film",
                "defocus_restored": True,
            }
        mean_defocus_nm, vector_nm, residual_nm = fit
        return {
            "measurable": True,
            "unit": "nm",
            "mean_defocus_nm": float(mean_defocus_nm),
            "astigmatism_vector_nm": {"x": float(vector_nm[0]), "y": float(vector_nm[1])},
            "astigmatism_nm": float(np.hypot(*vector_nm)),
            "fit_residual_nm": float(residual_nm),
            "fit_quality": float(np.mean(quality)),
            "aligned_threshold_nm": 3.0,
            "defocus_restored": True,
        }

    def _mean_screen_current(self, microscope: Any, samples: int) -> float:
        self._settle()
        return float(np.mean([microscope.detectors.screen.measure_current() for _ in range(samples)]))

    def measure_gun_tilt(
        self,
        probe_step: float = 0.03,
        samples: int = 2,
        beam_fraction_of_fov: float = 0.35,
        image_size_px: int = 256,
        exposure_s: float = 0.02,
        camera: str = "BM-Ceta",
    ) -> dict[str, Any]:
        """Probe four gun-tilt directions and restore the original setting."""
        if probe_step <= 0:
            raise ValueError("probe_step must be positive")
        if samples < 1 or samples > 20:
            raise ValueError("samples must be between 1 and 20")
        with self.client() as m:
            first = self._acquire_camera_image(m, camera, image_size_px, exposure_s)
            fov_m = float(first.metadata.binary_result.pixel_size.x) * image_size_px
            saved_diameter = float(m.optics.beam_diameter)
            m.optics.beam_diameter = beam_fraction_of_fov * fov_m
            deflectors = m.optics.deflectors
            base = deflectors.gun_tilt
            baseline = self._mean_screen_current(m, samples)
            probes = []
            try:
                for dx, dy in ((probe_step, 0.0), (-probe_step, 0.0), (0.0, probe_step), (0.0, -probe_step)):
                    deflectors.gun_tilt = self.types["point"](base.x + dx, base.y + dy)
                    current = self._mean_screen_current(m, samples)
                    probes.append({
                        "delta": {"x": dx, "y": dy},
                        "current_A": current,
                        "gain_fraction": (current / baseline - 1.0) if baseline > 0 else 0.0,
                    })
            finally:
                deflectors.gun_tilt = base
                m.optics.beam_diameter = saved_diameter
        best = max(probes, key=lambda item: item["current_A"])
        return {
            "unit": "A",
            "baseline_current_A": baseline,
            "probe_step": probe_step,
            "probes": probes,
            "best_delta": best["delta"],
            "maximum_gain_fraction": max(0.0, float(best["gain_fraction"])),
            "control_restored": True,
        }

    def set_vector_control(self, control: str, x: float, y: float, relative: bool = False) -> dict[str, Any]:
        """Set one two-axis alignment control using its native AutoScript unit."""
        path = self.VECTOR_CONTROLS.get(control)
        if path is None:
            raise ValueError("control must be one of: " + ", ".join(sorted(self.VECTOR_CONTROLS)))
        with self.client() as m:
            parent = self._resolve(m, path[:-1])
            current = getattr(parent, path[-1])
            target_x = float(current.x) + float(x) if relative else float(x)
            target_y = float(current.y) + float(y) if relative else float(y)
            setattr(parent, path[-1], self.types["point"](target_x, target_y))
            self._settle()
            updated = getattr(parent, path[-1])
        unit = "m" if control == "beam_shift" else "rad" if control == "beam_tilt" else "logical"
        return {"control": control, "unit": unit, "relative": relative, "value": _point(updated)}

    def set_beam_shift(self, x_m: float, y_m: float, relative: bool = False) -> dict[str, Any]:
        """Set beam shift x/y in metres, either absolute or relative."""
        return self.set_vector_control("beam_shift", x_m, y_m, relative)

    def set_beam_tilt(self, x_rad: float, y_rad: float, relative: bool = False) -> dict[str, Any]:
        """Set beam tilt x/y in radians, either absolute or relative."""
        return self.set_vector_control("beam_tilt", x_rad, y_rad, relative)

    def set_gun_tilt(self, x: float, y: float, relative: bool = False) -> dict[str, Any]:
        """Set dimensionless AutoScript gun-tilt x/y, either absolute or relative."""
        return self.set_vector_control("gun_tilt", x, y, relative)

    def set_condenser_stigmator(self, x: float, y: float, relative: bool = False) -> dict[str, Any]:
        """Set dimensionless condenser-stigmator x/y, either absolute or relative."""
        return self.set_vector_control("condenser_stigmator", x, y, relative)

    def set_objective_stigmator(self, x: float, y: float, relative: bool = False) -> dict[str, Any]:
        """Set dimensionless objective-stigmator x/y, either absolute or relative."""
        return self.set_vector_control("objective_stigmator", x, y, relative)

    def set_defocus(self, defocus_m: float, relative: bool = False) -> dict[str, Any]:
        """Set objective defocus in metres, either absolute or relative."""
        with self.client() as m:
            target = float(m.optics.defocus) + float(defocus_m) if relative else float(defocus_m)
            m.optics.defocus = target
            self._settle()
            return {"unit": "m", "relative": relative, "defocus_m": float(m.optics.defocus)}

    def set_beam_diameter(self, beam_diameter_m: float) -> dict[str, Any]:
        """Set illuminated beam diameter in metres."""
        if beam_diameter_m <= 0:
            raise ValueError("beam_diameter_m must be positive")
        with self.client() as m:
            m.optics.beam_diameter = float(beam_diameter_m)
            self._settle()
            return {"unit": "m", "beam_diameter_m": float(m.optics.beam_diameter)}

    def set_c2_aperture(
        self,
        inserted: bool | None = None,
        x_m: float | None = None,
        y_m: float | None = None,
        relative: bool = False,
    ) -> dict[str, Any]:
        """Insert/retract C2 and optionally set its position in metres."""
        with self.client() as m:
            c2 = m.optics.aperture_mechanisms.C2
            if inserted is True:
                c2.insert()
                self._wait_aperture(c2, "Inserted")
            elif inserted is False:
                c2.retract()
                self._wait_aperture(c2, "Retracted")
            if (x_m is None) != (y_m is None):
                raise ValueError("x_m and y_m must be supplied together")
            if x_m is not None and y_m is not None:
                current = c2.position
                target_x = float(current.x) + float(x_m) if relative else float(x_m)
                target_y = float(current.y) + float(y_m) if relative else float(y_m)
                c2.position = self.types["point"](target_x, target_y)
                self._settle()
            return {"state": str(c2.insertion_state), "position_m": _point(c2.position)}

    def set_stage_z(self, z_m: float, relative: bool = False) -> dict[str, Any]:
        """Move stage Z in metres, either absolute or relative."""
        with self.client() as m:
            stage = m.specimen.stage
            current = stage.position
            target = float(current.z) + float(z_m) if relative else float(z_m)
            stage.absolute_move(self.types["stage_position"](z=target))
            self._wait_stage(stage)
            return {"unit": "m", "relative": relative, "stage": _stage(stage.position)}

    def run_beam_tilt_auto_focus(
        self,
        camera: str = "BM-Ceta",
        focus_method: str = "StageZ",
        maximum_iterations: int = 6,
    ) -> dict[str, Any]:
        """Run the vendor AutoScript beam-tilt autofocus primitive."""
        if maximum_iterations < 1 or maximum_iterations > 50:
            raise ValueError("maximum_iterations must be between 1 and 50")
        method_enum = self.types["focus_method"]
        requested = focus_method.replace("_", "").lower()
        method = next(
            (value for name, value in vars(method_enum).items() if name.replace("_", "").lower() == requested),
            None,
        )
        if method is None:
            raise ValueError("Unknown AutoScript focus_method: " + focus_method)
        settings = self.types["beam_focus_settings"](
            camera_detector=camera,
            focus_method=method,
            maximum_iterations=maximum_iterations,
        )
        with self.client() as m:
            before = _stage(m.specimen.stage.position)
            result = m.auto_functions.run_beam_tilt_auto_focus(settings)
            self._wait_stage(m.specimen.stage)
            after = _stage(m.specimen.stage.position)
        return {"before_stage": before, "after_stage": after, "result": str(result)}

    def run_objective_auto_stigmator(self, camera: str = "BM-Ceta") -> dict[str, Any]:
        """Run the vendor AutoScript objective auto-stigmator primitive."""
        settings = self.types["objective_stig_settings"](camera_detector=camera)
        with self.client() as m:
            result = m.auto_functions.run_objective_auto_stigmator(settings)
        return {
            "astigmatism_m": float(result.astigmatism),
            "result": str(result),
        }

    def get_twin_metrics(self) -> dict[str, Any]:
        """Read simulation-only hidden metrics. Never use this on real hardware."""
        with self.client() as m:
            return json.loads(m.service.autoscript.server.configuration.get_value("twin.metrics"))

    def randomize_twin(self, seed: int | None = None) -> dict[str, Any]:
        """Randomize simulation misalignment. This tool is unavailable on real hardware."""
        key = "twin.randomize" if seed is None else f"twin.randomize={int(seed)}"
        with self.client() as m:
            raw = m.service.autoscript.server.configuration.get_value(key)
        try:
            value = json.loads(raw)
        except (TypeError, json.JSONDecodeError):
            value = raw
        return {"seed": seed, "result": value}


def create_mcp(service: AutoScriptToolService):
    try:
        from fastmcp import FastMCP
    except ImportError as exc:
        raise RuntimeError("FastMCP is required; install tem-twin-autoscript[mcp]") from exc

    mcp = FastMCP("TEM AutoScript Twin")
    from .asyncroscopy_tools import register_asyncroscopy_tools

    register_asyncroscopy_tools(mcp, service)
    from .alignment_tools import ALIGNMENT_TOOLS
    for name in ALIGNMENT_TOOLS:
        mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": True,
                              "idempotentHint": False, "openWorldHint": False})(getattr(service, name))
    mcp.tool(annotations={"readOnlyHint": True, "destructiveHint": False,
                          "openWorldHint": False})(service.calculator.calculate_alignment)
    for method_name in (
        "microscope_status",
        "get_alignment_state",
        "configure_imaging",
        "measure_beam",
        "measure_screen_current",
        "measure_condenser_stigmation",
        "measure_eucentric_offset",
        "measure_rotation_center",
        "measure_objective_astigmatism",
        "measure_gun_tilt",
        "set_beam_shift",
        "set_gun_tilt",
        "set_condenser_stigmator",
        "set_objective_stigmator",
        "set_beam_diameter",
        "set_c2_aperture",
        "set_stage_z",
        "get_twin_metrics",
        "randomize_twin",
    ):
        mcp.tool()(getattr(service, method_name))
    return mcp


def main(argv: list[str] | None = None) -> int:
    # Retain the old module entry point, but never bypass Tango in a live MCP.
    from .tango_mcp import main as gateway_main
    gateway_main(argv)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
