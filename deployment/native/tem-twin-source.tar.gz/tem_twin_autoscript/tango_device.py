"""Tango device exposing the existing, validated TEM operations via AutoScript.

Commands use JSON strings to preserve the structured MCP argument/result
contracts. DescribeTools advertises those schemas to the single MCP gateway.
"""

import asyncio
import json
import threading

from tango import DevState
from tango.server import Device, command, device_property

from .mcp_server import AutoScriptToolService, create_mcp


def operation_tools(service):
    return asyncio.run(create_mcp(service).get_tools())


class TEMDeviceBase(Device):
    autoscript_host = device_property(dtype=str, default_value="127.0.0.1")
    autoscript_port = device_property(dtype=int, default_value=7521)

    def init_device(self):
        super().init_device()
        self._operation_lock = threading.Lock()
        self._service = AutoScriptToolService(self.autoscript_host, self.autoscript_port)
        self._tools = operation_tools(self._service)
        try:
            self._service.microscope_status()
            self.set_state(DevState.ON)
            self.set_status("AutoScript connected; simulation device")
        except Exception as exc:
            self.set_state(DevState.FAULT)
            self.set_status(str(exc))

    def delete_device(self):
        if hasattr(self, "_service"):
            self._service._disconnect()

    @command(dtype_out=str)
    def DescribeTools(self):
        """Return the approved operation schemas; never expose arbitrary SDK methods."""
        return json.dumps({"protocol": 1, "device": self.get_name(), "kind": "simulation",
                           "tools": [tool.to_mcp_tool().model_dump(mode="json", by_alias=True)
                                     for tool in self._tools.values()]})

    def _invoke(self, name, raw):
        arguments = json.loads(raw)
        if not isinstance(arguments, dict):
            raise ValueError("Command arguments must be a JSON object")
        if not self._operation_lock.acquire(blocking=False):
            raise RuntimeError("Device busy; do not overlap instrument operations")
        self.set_state(DevState.RUNNING)
        try:
            result = asyncio.run(self._tools[name].run(arguments))
            self.set_state(DevState.ON)
            self.set_status("Ready")
            return json.dumps({"content": [part.model_dump(mode="json", by_alias=True)
                                            for part in result.content],
                               "structuredContent": result.structured_content,
                               "meta": {"device": self.get_name(), "transport": "tango-autoscript"}},
                              allow_nan=False)
        except Exception as exc:
            self.set_state(DevState.FAULT)
            self.set_status(f"{name} failed: {exc}. Verify state before retrying.")
            raise
        finally:
            self._operation_lock.release()


def make_command(name, description):
    def execute(self, arguments):
        return self._invoke(name, arguments)
    execute.__name__ = name
    execute.__doc__ = description or name
    return command(dtype_in=str, dtype_out=str)(execute)


# Build named Tango commands once from the same operation contract used in tests.
# This constructs a lazy SDK service, not a connection or an MCP listener.
TEMTwinDevice = type("TEMTwinDevice", (TEMDeviceBase,), {
    "__module__": __name__,
    **{name: make_command(name, tool.description)
       for name, tool in operation_tools(AutoScriptToolService()).items()},
})


if __name__ == "__main__":
    TEMTwinDevice.run_server()
