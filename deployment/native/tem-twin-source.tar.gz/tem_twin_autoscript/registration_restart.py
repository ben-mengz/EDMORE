"""Ask the same-job supervisor to restart only its Twin child (no Slurm calls)."""
import argparse
import json
import secrets
import time
from pathlib import Path
from .registration_server import write_private


def restart(control, timeout=50):
    control = Path(control)
    request_id = secrets.token_hex(16)
    write_private(control/'reload-request.json', {'id': request_id})
    response = control/'reload-response.json'
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if response.exists():
            value = json.loads(response.read_text())
            if value.get('id') == request_id:
                if not value.get('ok'): raise RuntimeError('Twin child restart failed')
                return
        time.sleep(0.2)
    raise TimeoutError('Twin supervisor did not acknowledge the restart')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--control-dir', required=True)
    args = parser.parse_args()
    restart(args.control_dir)


if __name__ == '__main__': main()
