"""Cloud Tango device that sends approved operations to a remote TEM node."""

from __future__ import annotations

import asyncio
import json
import threading
import urllib.error
import urllib.request

from tango import DevState
from tango.server import Device, command, device_property

from .mcp_server import AutoScriptToolService, create_mcp
from .tango_device import make_command, operation_tools


class RemoteNodeClient:
    def __init__(self, url: str, token: str, timeout_seconds: float):
        self.url = url.rstrip("/")
        self.token = token
        self.timeout_seconds = timeout_seconds

    def request(self, path: str, payload=None):
        data = None if payload is None else json.dumps(payload, allow_nan=False).encode("utf-8")
        request = urllib.request.Request(
            self.url + path,
            data=data,
            headers={"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"},
            method="GET" if payload is None else "POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                return json.loads(response.read())
        except urllib.error.HTTPError as error:
            body = error.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Remote node returned HTTP {error.code}: {body}") from error

    def describe(self):
        return self.request("/api/v1/describe")

    def invoke(self, name, arguments):
        return self.request(f"/api/v1/invoke/{name}", arguments)


class TEMHTTPProxyBase(Device):
    node_url = device_property(dtype=str)
    node_token = device_property(dtype=str)
    operation_timeout_seconds = device_property(dtype=float, default_value=300.0)

    def init_device(self):
        super().init_device()
        self._operation_lock = threading.Lock()
        self._tools = operation_tools(AutoScriptToolService())
        self._client = RemoteNodeClient(
            self.node_url, self.node_token, float(self.operation_timeout_seconds)
        )
        try:
            self._validate_identity(self._client.describe())
            self.set_state(DevState.ON)
            self.set_status(f"Connected to remote TEM node {self.node_url}")
        except Exception as error:
            self.set_state(DevState.FAULT)
            self.set_status(f"Remote node unavailable: {error}")

    def _validate_identity(self, descriptor):
        if descriptor.get("protocol") != 1:
            raise RuntimeError("Unsupported remote node protocol")
        if descriptor.get("device", "").lower() != self.get_name().lower():
            raise RuntimeError(
                f"Remote identity {descriptor.get('device')} does not match Tango device {self.get_name()}"
            )

    @command(dtype_out=str)
    def DescribeTools(self):
        # Discovery remains available while the microscope computer is offline.
        return json.dumps(
            {
                "protocol": 1,
                "device": self.get_name(),
                "kind": "remote",
                "tools": [
                    tool.to_mcp_tool().model_dump(mode="json", by_alias=True)
                    for tool in self._tools.values()
                ],
            },
            allow_nan=False,
        )

    def _invoke(self, name, raw):
        arguments = json.loads(raw)
        if not isinstance(arguments, dict):
            raise ValueError("Command arguments must be a JSON object")
        if not self._operation_lock.acquire(blocking=False):
            raise RuntimeError("Device busy; another operation is in progress")
        self.set_state(DevState.RUNNING)
        try:
            self._validate_identity(self._client.describe())
            result = self._client.invoke(name, arguments)
            if result.get("meta", {}).get("device", "").lower() != self.get_name().lower():
                raise RuntimeError("Remote node result identity mismatch")
            self.set_state(DevState.ON)
            self.set_status("Ready")
            return json.dumps(result, allow_nan=False)
        except Exception as error:
            self.set_state(DevState.FAULT)
            self.set_status(f"{name} failed: {error}. Verify device state before retrying.")
            raise
        finally:
            self._operation_lock.release()


TEMHTTPProxyDevice = type(
    "TEMHTTPProxyDevice",
    (TEMHTTPProxyBase,),
    {
        "__module__": __name__,
        **{
            name: make_command(name, tool.description)
            for name, tool in operation_tools(AutoScriptToolService()).items()
        },
    },
)


if __name__ == "__main__":
    TEMHTTPProxyDevice.run_server()
