"""Read-only web monitor for a remote AutoScript TEM endpoint."""

import argparse
import asyncio
import base64
import concurrent.futures
import contextlib
import logging
import signal
import threading
import time
import uuid
from pathlib import Path

import cv2
import numpy as np
from aiohttp import WSMsgType, web


ROOT = Path(__file__).parent
logger = logging.getLogger(__name__)


def _point(value):
    return {"x": float(value.x), "y": float(value.y)}


def _stage(value):
    return {axis: float(getattr(value, axis)) for axis in ("x", "y", "z", "a", "b")}


def _magnification(value):
    return {
        "label": str(getattr(value, "label", value)),
        "nominal": float(getattr(value, "nominal", 0)),
        "sub_mode": str(getattr(value, "magnification_sub_mode", "")),
        "objective_lens_mode": str(getattr(value, "objective_lens_mode", "")),
    }


def _jpeg_data_url(data):
    pixels = np.asarray(data)
    if pixels.ndim > 2:
        pixels = pixels[..., 0]
    pixels = pixels.astype(np.float32, copy=False)
    finite = pixels[np.isfinite(pixels)]
    if finite.size:
        low, high = np.percentile(finite, (0.5, 99.5))
    else:
        low, high = 0.0, 1.0
    if high <= low:
        high = low + 1.0
    display = np.clip((pixels - low) * (255.0 / (high - low)), 0, 255).astype(np.uint8)
    ok, encoded = cv2.imencode(".jpg", display, [cv2.IMWRITE_JPEG_QUALITY, 90])
    if not ok:
        raise RuntimeError("Could not encode camera image")
    return "data:image/jpeg;base64," + base64.b64encode(encoded).decode("ascii"), {
        "shape": list(pixels.shape),
        "dtype": str(np.asarray(data).dtype),
        "min": float(np.min(finite)) if finite.size else None,
        "max": float(np.max(finite)) if finite.size else None,
        "mean": float(np.mean(finite)) if finite.size else None,
        "display_low": float(low),
        "display_high": float(high),
    }


class AutoScriptSource:
    """Keep all vendor-client calls on one worker thread."""

    def __init__(self, host, port, camera="BM-Ceta", size=512, exposure=0.05,
                 settle_seconds=0.15, motion_timeout_seconds=60.0, operation_lock=None):
        self.host = host
        self.port = port
        self.camera = camera
        self.size = size
        self.exposure = exposure
        self.settle_seconds = max(0.0, float(settle_seconds))
        self.motion_timeout_seconds = max(0.1, float(motion_timeout_seconds))
        self.client = None
        self.c2_shadow = None
        self.lock = threading.Lock()
        from .operation_lock import OperationLock
        self.operation_lock = operation_lock or OperationLock.from_environment()
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="autoscript-monitor")
        from .handlers import TwinMicroscope
        from .orc_server import OrcServer
        from .twin_link import TwinLink

        self.twin_link = TwinLink()
        self.twin = TwinMicroscope(self.twin_link)
        self.physics_server = OrcServer(self.twin, host="127.0.0.1", port=0)
        self.physics_server.start()
        self.twin_link.set(spec=True, ht=200, beam=True, valves=True)

    def _settle(self):
        if self.settle_seconds:
            time.sleep(self.settle_seconds)

    def _wait_stage(self, stage):
        deadline = time.monotonic() + self.motion_timeout_seconds
        while bool(getattr(stage, "is_moving", False)):
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Stage did not finish within {self.motion_timeout_seconds:g} seconds"
                )
            time.sleep(0.1)
        self._settle()

    def _wait_aperture(self, aperture, expected_state):
        deadline = time.monotonic() + self.motion_timeout_seconds
        while str(aperture.insertion_state).lower() != expected_state.lower():
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"C2 aperture did not reach {expected_state} within "
                    f"{self.motion_timeout_seconds:g} seconds"
                )
            time.sleep(0.1)
        self._settle()

    def _connect(self):
        if self.client is not None:
            return
        from autoscript_tem_microscope_client import TemMicroscopeClient

        client = TemMicroscopeClient()
        client.connect(self.host, self.port)
        self.client = client

    @staticmethod
    def _read(name, getter, transform=lambda value: value):
        try:
            return transform(getter()), None
        except Exception as error:
            return None, f"{name}: {type(error).__name__}: {error}"

    def _sync_physics_twin(self, values):
        """Mirror official-server readbacks into the responsive local physics model."""
        magnification = (values.get("magnification") or {}).get("nominal") or 20_000
        model_magnifications = (1_500, 20_000, 250_000, 4_000_000)
        mag_index = min(range(len(model_magnifications)),
                        key=lambda index: abs(np.log(max(magnification, 1) / model_magnifications[index])))
        point = lambda name: values.get(name) or {"x": 0.0, "y": 0.0}
        stage = values.get("stage") or {axis: 0.0 for axis in "xyzab"}
        c2 = point("c2_position")
        c2_state = values.get("c2_state") == "Inserted"
        c2_shadow = getattr(self, "c2_shadow", None)
        if c2_shadow is not None and c2_shadow["in"] == c2_state:
            c2 = {"x": c2_shadow["x"] * 20e-6, "y": c2_shadow["y"] * 20e-6}
        patch = {
            "spec": True,
            "ht": 200,
            "beam": not bool(values.get("beam_blanked")),
            "valves": True,
            "mode": "img" if values.get("projector_mode") == "Imaging" else "diff",
            "mag": mag_index,
            "bright": float(np.clip(values.get("intensity") or 0.0, 0, 1)) * 100,
            "spot": int(np.clip(values.get("spot_size") or 1, 1, 5)),
            "dfc": float(values.get("defocus_m") or 0.0) * 1e9,
            "bs": {"x": point("beam_shift")["x"] / 2.5e-6, "y": point("beam_shift")["y"] / 2.5e-6},
            "btilt": {"x": point("beam_tilt")["x"] / 1e-3, "y": point("beam_tilt")["y"] / 1e-3},
            "gun": dict(point("gun_tilt")),
            "proj": {"x": point("image_shift")["x"] / 2.5e-6, "y": point("image_shift")["y"] / 2.5e-6},
            "c2stig": dict(point("condenser_stigmator")),
            "objstig": {"x": point("objective_stigmator")["x"] * 100,
                         "y": point("objective_stigmator")["y"] * 100},
            "c2": {"in": c2_state, "x": c2["x"] / 20e-6, "y": c2["y"] / 20e-6},
            "stage": {"x": stage["x"] * 1e9, "y": stage["y"] * 1e9, "z": stage["z"] * 1e6},
        }
        self.twin_link.set(**patch)
        return {"magnification_nominal": model_magnifications[mag_index], "magnification_index": mag_index}

    def _render_through_offline_server(self, microscope, values):
        from .handlers import acquire_image

        mapping = self._sync_physics_twin(values)
        rendered = acquire_image(self.twin, self.camera, self.size, self.exposure)
        # The final acquisition still crosses the official Offline API in both directions.
        microscope.service.offline.set_image(rendered)
        self._settle()
        image = microscope.acquisition.acquire_camera_image(self.camera, self.size, self.exposure)
        return image, mapping

    def _push_physics_to_remote(self, microscope):
        """Commit visible physics controls to the official Offline Server via its SDK."""
        from autoscript_tem_microscope_client.structures import Point, StagePosition
        from .handlers import MAGS

        state = self.twin_link.state()["S"]
        microscope.optics.projector_mode = "Imaging" if state["mode"] == "img" else "Diffraction"
        microscope.optics.intensity = float(state["bright"]) / 100
        microscope.optics.spot_size_index = int(state["spot"])
        available = microscope.optics.magnification.available_values
        target = MAGS[state["mag"]][0]
        microscope.optics.magnification.value = min(available, key=lambda value: abs(np.log(value.nominal / target)))
        microscope.optics.focusing.tem.defocus = float(state["dfc"]) * 1e-9
        if state["beam"]:
            microscope.optics.blanker.unblank()
        else:
            microscope.optics.blanker.blank()
        microscope.optics.deflectors.beam_shift = Point(state["bs"]["x"] * 2.5e-6, state["bs"]["y"] * 2.5e-6)
        microscope.optics.deflectors.beam_tilt = Point(state["btilt"]["x"] * 1e-3, state["btilt"]["y"] * 1e-3)
        microscope.optics.deflectors.gun_tilt = Point(state["gun"]["x"], state["gun"]["y"])
        microscope.optics.deflectors.image_shift = Point(state["proj"]["x"] * 2.5e-6, state["proj"]["y"] * 2.5e-6)
        microscope.optics.stigmators.condenser_stigmator = Point(state["c2stig"]["x"], state["c2stig"]["y"])
        microscope.optics.stigmators.objective_stigmator = Point(state["objstig"]["x"] / 100,
                                                                  state["objstig"]["y"] / 100)
        remote_stage = microscope.specimen.stage.position
        microscope.specimen.stage.absolute_move_safe(StagePosition(
            x=state["stage"]["x"] * 1e-9, y=state["stage"]["y"] * 1e-9,
            z=state["stage"]["z"] * 1e-6, a=remote_stage.a, b=remote_stage.b))
        self._wait_stage(microscope.specimen.stage)
        c2 = microscope.optics.aperture_mechanisms.C2
        c2_position = Point(state["c2"]["x"] * 20e-6, state["c2"]["y"] * 20e-6)
        warnings = []
        if state["c2"]["in"]:
            c2.insert()
            self._wait_aperture(c2, "Inserted")
            try:
                c2.position = c2_position
            except Exception as error:
                self.c2_shadow = dict(state["c2"])
                warnings.append(f"Offline Server could not represent C2 position {c2_position}; "
                                f"the Hybrid physics shadow keeps the correction: {error}")
            else:
                self.c2_shadow = None
        else:
            c2.retract()
            self._wait_aperture(c2, "Retracted")
            self.c2_shadow = None
        return warnings

    def _run_alignment(self, microscope, arguments):
        from autoscript_tem_microscope_client import TemMicroscopeClient
        from .alignment_tools import run_alignment
        from .autoalign import AutoAligner, STEPS

        phases = arguments.get("phases") or [step[0] for step in STEPS]
        if isinstance(phases, str):
            phases = [phases]
        valid = {step[0] for step in STEPS}
        if not phases or any(phase not in valid for phase in phases):
            raise ValueError("Invalid alignment phase")
        fix = bool(arguments.get("fix", True))
        local = TemMicroscopeClient()
        logs = []
        try:
            local.connect("127.0.0.1", self.physics_server.port)
            if fix and len(phases) == 1:
                result = run_alignment(local, phases[0], settle_seconds=0.15)
            else:
                aligner = AutoAligner(local, log=logs.append, settle_seconds=0.15)
                values = aligner.run(fix=fix, steps=phases)
                result = {
                    "success": all(status in ("ok", "fixed") for status, _detail in values.values()),
                    "fix": fix,
                    "phases": {phase: {"status": status, "detail": detail}
                               for phase, (status, detail) in values.items()},
                    "logs": logs,
                }
            if fix:
                warnings = self._push_physics_to_remote(microscope)
                if warnings:
                    result["mirror_warnings"] = warnings
            return result
        finally:
            try:
                local.disconnect()
            except Exception:
                pass

    def _snapshot(self):
        started = time.perf_counter()
        with self.operation_lock, self.lock:
            self._connect()
            microscope = self.client
            errors = []
            values = {}
            fields = (
                ("system_name", lambda: microscope.service.system.name, str),
                ("projector_mode", lambda: microscope.optics.projector_mode, str),
                ("magnification", lambda: microscope.optics.magnification.value, _magnification),
                ("intensity", lambda: microscope.optics.intensity, float),
                ("spot_size", lambda: microscope.optics.spot_size_index, int),
                ("defocus_m", lambda: microscope.optics.focusing.tem.defocus, float),
                ("beam_shift", lambda: microscope.optics.deflectors.beam_shift, _point),
                ("beam_tilt", lambda: microscope.optics.deflectors.beam_tilt, _point),
                ("gun_shift", lambda: microscope.optics.deflectors.gun_shift, _point),
                ("gun_tilt", lambda: microscope.optics.deflectors.gun_tilt, _point),
                ("image_shift", lambda: microscope.optics.deflectors.image_shift, _point),
                ("image_tilt", lambda: microscope.optics.deflectors.image_tilt, _point),
                ("condenser_stigmator", lambda: microscope.optics.stigmators.condenser_stigmator, _point),
                ("objective_stigmator", lambda: microscope.optics.stigmators.objective_stigmator, _point),
                ("beam_blanked", lambda: microscope.optics.blanker.is_beam_blanked, bool),
                ("c2_state", lambda: microscope.optics.aperture_mechanisms.C2.insertion_state, str),
                ("c2_position", lambda: microscope.optics.aperture_mechanisms.C2.position, _point),
                ("stage", lambda: microscope.specimen.stage.position, _stage),
                ("acceleration_voltage_v", lambda: microscope.source.acceleration_voltage.value, float),
            )
            for name, getter, transform in fields:
                value, error = self._read(name, getter, transform)
                values[name] = value
                if error:
                    errors.append(error)
            mapping = None
            image, error = self._read("camera", lambda: self._render_through_offline_server(microscope, values))
            if error:
                errors.append(error)
                frame = frame_info = None
            else:
                image, mapping = image
                frame, frame_info = _jpeg_data_url(image.data)
            return {
                "connected": True,
                "endpoint": f"{self.host}:{self.port}",
                "camera": self.camera,
                "exposure_s": self.exposure,
                "values": values,
                "capabilities": {
                    "magnifications": [_magnification(value) for value in microscope.optics.magnification.available_values],
                    "projector_modes": ["Imaging", "Diffraction"],
                    "offline_sample": values.get("system_name") == "Offline",
                },
                "hybrid": {"enabled": True, "physics_engine": "TEM Alignment Twin",
                           "sample": "Au nanoparticles on holey carbon", "mapping": mapping},
                "frame": frame,
                "frame_info": frame_info,
                "errors": errors,
                "latency_ms": round((time.perf_counter() - started) * 1000),
                "captured_at": time.time(),
            }

    @staticmethod
    def _bounded_number(arguments, name, minimum, maximum):
        value = float(arguments[name])
        if not np.isfinite(value) or not minimum <= value <= maximum:
            raise ValueError(f"{name} must be between {minimum} and {maximum}")
        return value

    def _command(self, command, arguments):
        from autoscript_tem_microscope_client.structures import StagePosition

        with self.operation_lock, self.lock:
            self._connect()
            microscope = self.client
            if microscope.service.system.name != "Offline":
                raise RuntimeError("Remote controls are enabled only for an AutoScript Offline server")
            if command == "set_optics":
                if "intensity" in arguments:
                    microscope.optics.intensity = self._bounded_number(arguments, "intensity", 0, 1)
                if "spot_size" in arguments:
                    microscope.optics.spot_size_index = int(self._bounded_number(arguments, "spot_size", 1, 11))
                if "projector_mode" in arguments:
                    mode = str(arguments["projector_mode"])
                    if mode not in ("Imaging", "Diffraction"):
                        raise ValueError("Invalid projector mode")
                    microscope.optics.projector_mode = mode
                if "magnification" in arguments:
                    nominal = self._bounded_number(arguments, "magnification", 1, 10_000_000)
                    available = microscope.optics.magnification.available_values
                    match = next((value for value in available if float(value.nominal) == nominal), None)
                    if match is None:
                        raise ValueError("Magnification is not available in the current optical state")
                    microscope.optics.magnification.value = match
                if "defocus_nm" in arguments:
                    value = self._bounded_number(arguments, "defocus_nm", -100_000, 100_000)
                    microscope.optics.focusing.tem.defocus = value * 1e-9
            elif command == "set_vector":
                target = str(arguments.get("target", ""))
                x = self._bounded_number(arguments, "x", -1_000_000, 1_000_000)
                y = self._bounded_number(arguments, "y", -1_000_000, 1_000_000)
                deflectors = {
                    "beam_shift": (microscope.optics.deflectors, 1e-6),
                    "beam_tilt": (microscope.optics.deflectors, 1e-3),
                    "gun_shift": (microscope.optics.deflectors, 1e-6),
                    "gun_tilt": (microscope.optics.deflectors, 1),
                    "image_shift": (microscope.optics.deflectors, 1e-6),
                    "image_tilt": (microscope.optics.deflectors, 1e-3),
                    "condenser_stigmator": (microscope.optics.stigmators, 1),
                    "objective_stigmator": (microscope.optics.stigmators, 1),
                }
                if target not in deflectors:
                    raise ValueError("Unsupported vector control")
                owner, scale = deflectors[target]
                setattr(owner, target, (x * scale, y * scale))
            elif command == "move_stage":
                current = microscope.specimen.stage.position
                values = {}
                limits = {"x": (-1000, 1000, 1e-6), "y": (-1000, 1000, 1e-6),
                          "z": (-400, 400, 1e-6), "a": (-1570.8, 1570.8, 1e-3),
                          "b": (-785.398, 785.398, 1e-3)}
                for axis, (minimum, maximum, scale) in limits.items():
                    values[axis] = (self._bounded_number(arguments, axis, minimum, maximum) * scale
                                    if axis in arguments else float(getattr(current, axis)))
                microscope.specimen.stage.absolute_move_safe(StagePosition(**values))
                self._wait_stage(microscope.specimen.stage)
            elif command == "set_beam_blank":
                if bool(arguments.get("blanked")):
                    microscope.optics.blanker.blank()
                else:
                    microscope.optics.blanker.unblank()
            elif command == "set_c2":
                action = str(arguments.get("action", ""))
                c2 = microscope.optics.aperture_mechanisms.C2
                if action == "insert":
                    c2.insert()
                    self._wait_aperture(c2, "Inserted")
                elif action == "retract":
                    c2.retract()
                    self._wait_aperture(c2, "Retracted")
                elif action == "position":
                    x = self._bounded_number(arguments, "x", -1000, 1000)
                    y = self._bounded_number(arguments, "y", -1000, 1000)
                    c2.position = (x * 1e-6, y * 1e-6)
                    self._settle()
                else:
                    raise ValueError("Unsupported C2 operation")
                self.c2_shadow = None
            elif command == "randomize_twin":
                self.twin_link.call("randomize", seed=None)
            elif command == "run_alignment":
                return {"command": command, "accepted": True,
                        "alignment": self._run_alignment(microscope, arguments)}
            else:
                raise ValueError("Unsupported command")
            return {"command": command, "accepted": True}

    async def command(self, command, arguments):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self.executor, self._command, command, arguments)

    async def snapshot(self):
        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(self.executor, self._snapshot)
        except Exception as error:
            await loop.run_in_executor(self.executor, self._disconnect)
            return {
                "connected": False,
                "endpoint": f"{self.host}:{self.port}",
                "camera": self.camera,
                "values": {},
                "frame": None,
                "frame_info": None,
                "errors": [f"{type(error).__name__}: {error}"],
                "latency_ms": None,
                "captured_at": time.time(),
            }

    def _disconnect(self):
        if self.client is None:
            return
        try:
            self.client.disconnect()
        finally:
            self.client = None

    async def close(self):
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(self.executor, self._disconnect)
        self.executor.shutdown(wait=True, cancel_futures=True)
        self.physics_server.stop()
        self.twin_link.close()


class RemoteMonitor:
    def __init__(self, source, interval=0.25):
        self.source = source
        self.interval = interval
        self.viewers = set()
        self.snapshot = None
        self.revision = 0
        self.instance = uuid.uuid4().hex
        self.running = False

    def message(self):
        return {"type": "state", "instance": self.instance, "revision": self.revision, "snapshot": self.snapshot}

    async def run(self):
        self.running = True
        try:
            while True:
                self.snapshot = await self.source.snapshot()
                self.revision += 1
                await self.broadcast()
                await asyncio.sleep(self.interval)
        finally:
            self.running = False

    async def broadcast(self):
        viewers = list(self.viewers)
        if not viewers:
            return
        results = await asyncio.gather(
            *(asyncio.wait_for(viewer.send_json(self.message()), 3) for viewer in viewers),
            return_exceptions=True,
        )
        failed = [viewer for viewer, result in zip(viewers, results) if isinstance(result, BaseException)]
        self.viewers.difference_update(failed)
        await asyncio.gather(*(viewer.close() for viewer in failed), return_exceptions=True)


def create_app(monitor, device_tools=None, device_id=None, api_token=None, mode="offline"):
    def require_api_token(request):
        if not api_token or request.headers.get("Authorization") != f"Bearer {api_token}":
            raise web.HTTPUnauthorized(headers={"WWW-Authenticate": "Bearer"})

    async def index(_request):
        return web.FileResponse(ROOT / "web" / "remote-monitor.html", headers={"Cache-Control": "no-store"})

    async def script(_request):
        return web.FileResponse(ROOT / "web" / "remote-monitor.js", headers={"Cache-Control": "no-cache"})

    async def health(_request):
        connected = bool(monitor.snapshot and monitor.snapshot.get("connected"))
        return web.json_response({
            "ready": monitor.running and connected,
            "connected": connected,
            "revision": monitor.revision,
            "endpoint": f"{monitor.source.host}:{monitor.source.port}",
            "read_only": False,
            "control_mode": "offline_only",
            "hybrid_physics": True,
            "device_id": device_id,
            "mode": mode,
        }, status=200 if connected else 503)

    async def describe(request):
        require_api_token(request)
        return web.json_response({
            "protocol": 1,
            "device": device_id,
            "kind": "simulation" if mode == "offline" else "hardware",
            "tools": [tool.to_mcp_tool().model_dump(mode="json", by_alias=True)
                      for tool in device_tools.values()],
        })

    async def invoke(request):
        require_api_token(request)
        name = request.match_info["name"]
        tool = device_tools.get(name)
        if tool is None:
            raise web.HTTPNotFound(text="Unknown device operation")
        try:
            arguments = await request.json()
        except Exception as error:
            raise web.HTTPBadRequest(text=f"Invalid JSON: {error}") from error
        if not isinstance(arguments, dict):
            raise web.HTTPBadRequest(text="Operation arguments must be a JSON object")

        def execute():
            return asyncio.run(tool.run(arguments))

        try:
            result = await asyncio.to_thread(execute)
        except Exception as error:
            return web.json_response({
                "error": f"{type(error).__name__}: {error}",
                "outcome": "unknown" if isinstance(error, TimeoutError) else "failed",
                "retry": False,
            }, status=500)
        return web.json_response({
            "content": [part.model_dump(mode="json", by_alias=True) for part in result.content],
            "structuredContent": result.structured_content,
            "meta": {"device": device_id, "transport": "windows-node-http"},
        })

    async def stream(request):
        origin = request.headers.get("Origin")
        if origin and origin != f"{request.scheme}://{request.host}":
            raise web.HTTPForbidden()
        ws = web.WebSocketResponse(max_msg_size=2 * 1024 * 1024, heartbeat=20, compress=True)
        await ws.prepare(request)
        monitor.viewers.add(ws)
        try:
            if monitor.snapshot:
                await ws.send_json(monitor.message())
            async for message in ws:
                if message.type == WSMsgType.TEXT:
                    value = {}
                    try:
                        value = message.json()
                        if not isinstance(value, dict) or value.get("type") != "command":
                            raise ValueError("Invalid command message")
                        result = await monitor.source.command(value.get("command"), value.get("arguments") or {})
                        await ws.send_json({"type": "ack", "request_id": value.get("request_id"), "result": result})
                    except Exception as error:
                        await ws.send_json({"type": "ack", "request_id": value.get("request_id") if isinstance(value, dict) else None,
                                            "error": f"{type(error).__name__}: {error}"})
        finally:
            monitor.viewers.discard(ws)
        return ws

    async def shutdown(_app):
        await asyncio.gather(*(ws.close(code=1001, message=b"Monitor stopping") for ws in list(monitor.viewers)),
                             return_exceptions=True)

    app = web.Application()
    app.add_routes([web.get("/", index), web.get("/remote-monitor.js", script),
                    web.get("/health", health), web.get("/stream", stream)])
    if device_tools is not None:
        if not device_id or not api_token:
            raise ValueError("device_id and api_token are required for the device API")
        app.add_routes([web.get("/api/v1/describe", describe),
                        web.post("/api/v1/invoke/{name}", invoke)])
    app.on_shutdown.append(shutdown)
    return app


async def serve(args):
    from .operation_lock import OperationLock

    operation_lock = OperationLock.from_environment()
    source = AutoScriptSource(
        args.autoscript_host,
        args.autoscript_port,
        args.camera,
        args.size,
        args.exposure,
        args.settle_seconds,
        args.motion_timeout_seconds,
        operation_lock,
    )
    monitor = RemoteMonitor(source, args.interval)
    device_tools = None
    if args.enable_device_api:
        from .mcp_server import AutoScriptToolService, create_mcp

        service = AutoScriptToolService(
            args.autoscript_host,
            args.autoscript_port,
            operation_settle_seconds=args.settle_seconds,
            motion_timeout_seconds=args.motion_timeout_seconds,
            operation_lock=operation_lock,
        )
        device_tools = await create_mcp(service).get_tools()
    runner = web.AppRunner(create_app(
        monitor,
        device_tools=device_tools,
        device_id=args.device_id,
        api_token=args.api_token,
        mode=args.mode,
    ))
    await runner.setup()
    await web.TCPSite(runner, args.host, args.port).start()
    task = asyncio.create_task(monitor.run())
    stop = asyncio.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        asyncio.get_running_loop().add_signal_handler(sig, stop.set)
    print(f"Remote AutoScript monitor: http://{args.host}:{args.port}/", flush=True)
    try:
        await stop.wait()
    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        await runner.cleanup()
        await source.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--autoscript-host", default="141.20.47.165")
    parser.add_argument("--autoscript-port", type=int, default=7521)
    parser.add_argument("--camera", default="BM-Ceta")
    parser.add_argument("--size", type=int, default=512)
    parser.add_argument("--exposure", type=float, default=0.05)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8778)
    parser.add_argument("--interval", type=float, default=0.25)
    parser.add_argument("--settle-seconds", type=float, default=0.15)
    parser.add_argument("--motion-timeout-seconds", type=float, default=60.0)
    parser.add_argument("--enable-device-api", action="store_true")
    parser.add_argument("--device-id")
    parser.add_argument("--api-token")
    parser.add_argument("--mode", choices=("offline", "hardware"), default="offline")
    logging.basicConfig(level=logging.INFO)
    asyncio.run(serve(parser.parse_args()))


if __name__ == "__main__":
    main()
