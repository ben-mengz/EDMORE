"""Run the browser-independent AutoScript simulation server."""

import argparse
import logging
import signal
import threading

from .runtime import TwinRuntime


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7521)
    parser.add_argument("--as-is", action="store_true")
    parser.add_argument("--headless", action="store_true", help="Compatibility flag; the engine is always server-side")
    parser.add_argument("--no-browser", action="store_true", help="Compatibility flag; browsers never host the engine")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO)
    stop = threading.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: stop.set())
    runtime = TwinRuntime(args.host, args.port, prepare=not args.as_is)
    try:
        while not stop.wait(0.5):
            if not runtime.link.connected:
                raise RuntimeError("Backend engine stopped")
    finally:
        runtime.close()


if __name__ == "__main__":
    main()
