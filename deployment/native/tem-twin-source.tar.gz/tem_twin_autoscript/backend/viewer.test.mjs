import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';
import { JSDOM } from 'jsdom';

test('viewer sends bounded input and synchronizes form properties without running physics', () => {
  const dom = new JSDOM('<main id="twin-view"></main>', { runScripts: 'outside-only', url: 'http://localhost' });
  const window = dom.window;
  let socket;
  const sent = [];
  window.WebSocket = class {
    static OPEN = 1;
    readyState = 1;
    constructor() { socket = this; }
    send(message) { sent.push(JSON.parse(message)); }
  };
  window.eval(fs.readFileSync(new URL('../web/morphdom.min.js', import.meta.url), 'utf8'));
  window.eval(fs.readFileSync(new URL('../web/viewer.js', import.meta.url), 'utf8'));
  socket.onopen();
  const html = '<section><input type="checkbox" data-twin-node="1"><button data-twin-node="2">Press</button></section>';
  const state = checked => socket.onmessage({ data: JSON.stringify({ type: 'state', instance: 'server-1', revision: 1,
    snapshot: { html, controls: { '1': { checked, value: 'on' } }, images: {} } }) });
  try {
    state(true);
    assert.equal(window.document.querySelector('input').checked, true);
    state(false);
    assert.equal(window.document.querySelector('input').checked, false);
    window.document.querySelector('button').click();
    assert.deepEqual(sent, [{ type: 'click', node: '2', instance: 'server-1' }]);
    assert.equal(window.TEM, undefined);
  } finally { window.close(); }
});
