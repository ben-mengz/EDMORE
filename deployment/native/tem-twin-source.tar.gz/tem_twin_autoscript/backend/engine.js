
(() => {
"use strict";
// ---------------- constants ----------------
const MAGS = [
  {name:"LOW", label:"1,500×", R:40000, f:[1000,10000]},
  {name:"MEDIUM", label:"20 k×", R:2500, f:[100,1000]},
  {name:"HIGH", label:"250 k×", R:200, f:[10,100]},
  {name:"VERY HIGH", label:"4 M×", R:12.5, f:[2,15]},
];
const LAMBDA = {120:0.003349, 200:0.002508}; // nm
const CS = 1.2e6; // nm
const C2S = [{n:"Small · 30 µm",sf:0.55,tr:0.35},{n:"Medium · 50 µm",sf:0.8,tr:0.65},{n:"Large · 100 µm",sf:1.05,tr:1.0}];
const C2NONE = {sf:1.35,tr:2.0};
const OBJS = [{n:"Small · 10 µm",r:5,ctr:1.9},{n:"Medium · 20 µm",r:9,ctr:1.5},{n:"Large · 40 µm",r:18,ctr:1.2}];
const XO = 45; // brightness value at crossover
const D_AU = [0.2355,0.2039,0.1442,0.1230,0.1177]; // nm
const I_AU = [1.0,0.55,0.32,0.34,0.1];
const N = 256, M = 320, OFF = 32; // screen px, specimen buffer px, margin

// ---------------- state ----------------
const S = {
  ht:0, spec:false, beam:false, spot:3, bright:75,
  bs:{x:0,y:0},
  c2:{in:false,size:1,x:0,y:0},
  obj:{in:false,size:2,x:0,y:0},
  c2stig:{x:0,y:0}, objstig:{x:0,y:0},
  gun:{x:0,y:0}, btilt:{x:0,y:0}, proj:{x:0,y:0},
  stage:{x:0,y:0,z:0}, mode:"img", mag:0, dfc:0,
  wob:"off", fft:false, stop:false, display:"camera", valves:true,
};
const UI = {apSel:"c2", stig:"c2", dir:"gun", coarse:false, guide:true, truth:false};
let H = null, seed = 0;

function rng(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}}
function polar(r, lo, hi){const m = lo+(hi-lo)*r(), a = r()*Math.PI*2; return {x:m*Math.cos(a), y:m*Math.sin(a)};}
function randomize(s){
  seed = (s ?? Math.floor(Math.random()*1e9))>>>0;
  const r = rng(seed);
  H = {
    bs: polar(r,0.45,0.8), c2: polar(r,0.22,0.45), cs: polar(r,0.3,0.6),
    gun: polar(r,0.35,0.65), z0: (r()<.5?-1:1)*(15+30*r()),
    tau: polar(r,2,4.5), obj: polar(r,6,13), os: polar(r,18,45), proj: polar(r,0.3,0.5),
  };
  specCache.clear(); optCache.clear(); waveCache.clear();
  return seed;
}

// ---------------- helpers ----------------
const hyp = v => Math.hypot(v.x, v.y);
const sub = (a,b) => ({x:a.x-b.x, y:a.y-b.y});
const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
function hash(x,y,s){let h=(Math.imul(x|0,374761393)+Math.imul(y|0,668265263)+Math.imul(s|0,982451653))|0;h=Math.imul(h^(h>>>13),1274126177);h^=h>>>16;return (h>>>0)/4294967296;}
function vnoise(x,y,s){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi;const u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);
  const a=hash(xi,yi,s),b=hash(xi+1,yi,s),c=hash(xi,yi+1,s),d=hash(xi+1,yi+1,s);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v;}
const smooth = (a,b,x) => {const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};

// ---------------- optical model ----------------
const ALPHA = 5e-3; // probe semi-angle set by the C2 aperture (rad)
function model(){
  const lam = LAMBDA[S.ht] || LAMBDA[200];
  const ap = S.c2.in ? C2S[S.c2.size] : C2NONE;
  const R = MAGS[S.mag].R;
  const s = (S.bright - XO)/55*1.5*ap.sf;          // beam radius at the specimen plane (screen radii, signed)
  const m = 0.008*S.spot + 0.01;                     // demagnified source size
  const zE = S.stage.z - H.z0;
  const dfEff = S.dfc + zE*1000;                     // imaged plane relative to the specimen (nm)
  const zi = S.mode === "img" ? ALPHA*dfEff/R : 0;   // extra spread of the cone between specimen and imaged plane
  const se = s + zi;                                 // beam radius at the imaged plane
  const ce = sub(S.c2stig, H.cs), E = 0.12*hyp(ce);
  const rA = Math.hypot(se+E, m), rB = Math.hypot(se-E, m), th = Math.atan2(ce.y, ce.x)/2;
  // shadow projection: a screen offset d from the beam centre shows specimen point d*ig
  let ig = 1;
  if (zi !== 0) ig = Math.abs(se) < 1e-4 ? 8*Math.sign(s || 1) : clamp(s/se, -8, 8);
  const shadow = smooth(0.3, 0.8, Math.abs(ig - 1));
  const bsE = sub(S.bs, H.bs), apE = S.c2.in ? sub(S.c2, H.c2) : {x:0,y:0};
  const k = 0.9*Math.abs(s);
  const C = {x: bsE.x + apE.x*k, y: bsE.y + apE.y*k};
  const gE = hyp(sub(S.gun, H.gun)), gf = Math.exp(-(gE*gE)/(0.45*0.45));
  const flux = (1.4/Math.pow(S.spot,0.8))*ap.tr*gf;
  const I = flux*2.65/(rA*rB);
  const ast = sub(S.objstig, H.os);
  const tau = sub(S.btilt, H.tau);
  const projE = sub(S.proj, H.proj);
  const objE = sub(S.obj, H.obj);
  const objR = OBJS[S.obj.size].r;
  const objRel = hyp(sub(objE, tau));
  const alphaC = clamp(0.35/Math.max(Math.hypot(s,m),0.04), 0.35, 8);
  const illum = 1.2e-4/Math.max(Math.hypot(s,m), 0.08);   // local illumination semi-angle (rad), sets spatial coherence
  const thetaG = lam/D_AU[0]*1000;
  const objPass = !S.obj.in || objRel < objR;
  const fringePass = !S.obj.in || (objR - objRel) > thetaG + 0.5*alphaC;
  return {lam,ap,R,s,se,zi,ig,shadow,m,E,rA,rB,th,C,bsE,apE,gE,gf,flux,I,zE,dfEff,ast,tau,projE,objE,objR,objRel,alphaC,illum,thetaG,objPass,fringePass,
          edge: S.c2.in ? 0.012 : 0.12};
}

// ---------------- specimen (world coordinates, nm) ----------------
// world() writes intensity transmission _t, phase shift _ph and region label _cls
let _t = 1, _ph = 0, _cls = "vacuum";
function world(wx, wy, px){
  _ph = 0;
  const gx = ((wx + 31000) % 62000 + 62000) % 62000, gy = ((wy + 31000) % 62000 + 62000) % 62000;
  if (gx < 8000 || gx > 54000 || gy < 8000 || gy > 54000){ _t = 0.02; _cls = "Cu grid bar"; return; }
  const hx = Math.floor(wx/3200), hy = Math.floor(wy/3200);
  if (hash(hx,hy,11) < 0.78){
    const cx = (hx+0.5+(hash(hx,hy,12)-0.5)*0.18)*3200, cy = (hy+0.5+(hash(hx,hy,13)-0.5)*0.18)*3200;
    const rr = 700 + hash(hx,hy,14)*600;
    if ((wx-cx)*(wx-cx)+(wy-cy)*(wy-cy) < rr*rr){ _t = 1; _cls = "hole (vacuum)"; return; }
  }
  _cls = "amorphous carbon";
  let t = Math.exp(-0.18*(0.9 + 0.25*vnoise(wx/15000, wy/15000, 3)));
  let ph = 0.4;
  if (px < 5) ph += 0.42*(hash(Math.floor(wx/px), Math.floor(wy/px), 41) - 0.5);   // amorphous film: white-noise phase, σ ≈ 0.12 rad
  const f = vnoise(wx/700, wy/700, 5)*0.65 + vnoise(wx/180, wy/180, 6)*0.35;
  const p = smooth(0.5, 0.78, f);
  if (p > 0){
    if (px >= 5){
      t *= 1 - 0.6*p*(0.75 + 0.5*vnoise(wx/60, wy/60, 8));
      if (p > 0.5) _cls = "Au particle cluster";
    } else {
      const cxI = Math.floor(wx/24), cyI = Math.floor(wy/24);
      if (hash(cxI,cyI,21) < p*0.95){
        const r = 3 + hash(cxI,cyI,22)*6.5, room = 12 - r - 0.5;
        const pcx = (cxI+0.5)*24 + (hash(cxI,cyI,23)-0.5)*2*room, pcy = (cyI+0.5)*24 + (hash(cxI,cyI,24)-0.5)*2*room;
        const d2 = ((wx-pcx)*(wx-pcx)+(wy-pcy)*(wy-pcy))/(r*r);
        if (d2 < 1){
          const thk = Math.sqrt(1-d2);
          t *= Math.exp(-0.09*thk*r);
          ph += 0.22*thk*r;
          _cls = "Au particle";
          if (px < 0.12 && hash(cxI,cyI,25) < 0.7){   // on a zone axis: {111} lattice, 0.2355 nm
            const a = Math.floor(hash(cxI,cyI,26)*12)*Math.PI/12;
            ph += 0.5*thk*Math.cos(2*Math.PI*(wx*Math.cos(a)+wy*Math.sin(a))/D_AU[0]);
          }
        }
      }
    }
  }
  _t = t; _ph = ph;
}

const specCache = new Map(), optCache = new Map(), waveCache = new Map();
function cachePut(map, k, v){ map.set(k, v); if (map.size > 6) map.delete(map.keys().next().value); }

// low / medium magnification: mass-thickness transmission on the M×M grid
function geometry(ox, oy, R){
  const key = [ox.toFixed(3), oy.toFixed(3), R, S.spec].join("|");
  if (specCache.has(key)) return specCache.get(key);
  const px = R/128, T = new Float32Array(M*M);
  if (!S.spec) T.fill(1);
  else for (let j=0;j<M;j++){
    const wy = oy - (j - M/2 + 0.5)*px;
    for (let i=0;i<M;i++){ world(ox + (i - M/2 + 0.5)*px, wy, px); T[j*M+i] = _t; }
  }
  const g = {T, px, key};
  cachePut(specCache, key, g);
  return g;
}

function boxBlur(src, rx, ry){
  const out = new Float32Array(src.length), tmp = new Float32Array(src.length);
  const pass = (a, b, r, horiz) => {
    if (r < 1){ b.set(a); return; }
    const inv = 1/(2*r+1);
    for (let l=0;l<M;l++){
      let acc = 0;
      for (let q=-r;q<=r;q++){ const c = clamp(q,0,M-1); acc += horiz ? a[l*M+c] : a[c*M+l]; }
      for (let q=0;q<M;q++){
        if (horiz) b[l*M+q] = acc*inv; else b[q*M+l] = acc*inv;
        const add = clamp(q+r+1,0,M-1), rem = clamp(q-r,0,M-1);
        acc += horiz ? a[l*M+add]-a[l*M+rem] : a[add*M+l]-a[rem*M+l];
      }
    }
  };
  const r1 = Math.round(rx/Math.SQRT2), r2 = Math.round(ry/Math.SQRT2);
  out.set(src);
  for (let n=0;n<2;n++){ pass(out, tmp, r1, true); pass(tmp, out, r2, false); }
  return out;
}

// ---------------- FFT (radix-2, in place) ----------------
const fftTables = {};
function fftTab(n){
  if (fftTables[n]) return fftTables[n];
  const bits = Math.round(Math.log2(n)), rev = new Uint32Array(n), cos = new Float64Array(n/2), sin = new Float64Array(n/2);
  for (let i=0;i<n;i++){ let r = 0; for (let b=0;b<bits;b++) r |= ((i>>b)&1) << (bits-1-b); rev[i] = r; }
  for (let i=0;i<n/2;i++){ cos[i] = Math.cos(2*Math.PI*i/n); sin[i] = Math.sin(2*Math.PI*i/n); }
  return (fftTables[n] = {rev, cos, sin});
}
function fft1(re, im, n, inv){
  const {rev, cos, sin} = fftTab(n);
  for (let i=0;i<n;i++){ const j = rev[i]; if (j > i){ let t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; } }
  for (let size=2; size<=n; size<<=1){
    const half = size>>1, step = n/size;
    for (let i=0;i<n;i+=size){
      for (let j=0, k=0; j<half; j++, k+=step){
        const wr = cos[k], wi = inv ? sin[k] : -sin[k], a = i+j, b = a+half;
        const tr = re[b]*wr - im[b]*wi, ti = re[b]*wi + im[b]*wr;
        re[b] = re[a]-tr; im[b] = im[a]-ti; re[a] += tr; im[a] += ti;
      }
    }
  }
}
function fft2(re, im, n, inv){
  const rr = new Float64Array(n), ii = new Float64Array(n);
  for (let y=0;y<n;y++){ const o = y*n; for (let x=0;x<n;x++){ rr[x] = re[o+x]; ii[x] = im[o+x]; } fft1(rr, ii, n, inv); for (let x=0;x<n;x++){ re[o+x] = rr[x]; im[o+x] = ii[x]; } }
  for (let x=0;x<n;x++){ for (let y=0;y<n;y++){ rr[y] = re[y*n+x]; ii[y] = im[y*n+x]; } fft1(rr, ii, n, inv); for (let y=0;y<n;y++){ re[y*n+x] = rr[y]; im[y*n+x] = ii[y]; } }
  if (inv){ const s = 1/(n*n); for (let i=0;i<n*n;i++){ re[i] *= s; im[i] *= s; } }
}

// ---------------- high magnification: exit wave × CTF ----------------
const NH = 256;
function exitWave(ox, oy, px){
  const key = [ox.toFixed(4), oy.toFixed(4), px, S.spec].join("|");
  if (waveCache.has(key)) return waveCache.get(key);
  const n = NH, re = new Float64Array(n*n), im = new Float64Array(n*n), t0 = new Float32Array(n*n), T = new Float32Array(M*M);
  for (let j=0;j<n;j++){
    const wy = oy - (j - n/2 + 0.5)*px;
    for (let i=0;i<n;i++){
      const idx = j*n+i;
      if (S.spec) world(ox + (i - n/2 + 0.5)*px, wy, px); else { _t = 1; _ph = 0; }
      const a = Math.sqrt(_t);
      re[idx] = a*Math.cos(_ph); im[idx] = a*Math.sin(_ph); t0[idx] = _t;
    }
  }
  for (let j=0;j<M;j++) for (let i=0;i<M;i++) T[j*M+i] = t0[((j-OFF)&(n-1))*n + ((i-OFF)&(n-1))];
  fft2(re, im, n, false);
  const w = {re, im, T, key};
  cachePut(waveCache, key, w);
  return w;
}
function hrImage(m, df){
  const R = MAGS[S.mag].R, px = R/128, n = NH, lam = m.lam;
  const oxr = S.stage.x + df*m.tau.x*1e-3, oyr = S.stage.y + df*m.tau.y*1e-3;   // off-axis rotation centre: image walks with focus
  const ox = Math.round(oxr/px)*px, oy = Math.round(oyr/px)*px;
  const sdx = oxr - ox, sdy = oyr - oy;                                           // sub-pixel remainder, applied as a phase ramp
  const W = exitWave(ox, oy, px);
  const A = hyp(m.ast), phiA = Math.atan2(m.ast.y, m.ast.x)/2;
  const key = [W.key, df.toFixed(1), m.ast.x.toFixed(2), m.ast.y.toFixed(2), S.obj.in, S.obj.size, S.obj.x.toFixed(2), S.obj.y.toFixed(2),
               m.tau.x.toFixed(2), m.tau.y.toFixed(2), m.illum.toExponential(2), S.ht, sdx.toFixed(4), sdy.toFixed(4)].join("|");
  if (optCache.has(key)) return optCache.get(key);
  const re = new Float64Array(n*n), im = new Float64Array(n*n);
  const dk = 1/(n*px), ofx = m.objE.x - m.tau.x, ofy = m.objE.y - m.tau.y, r2 = m.objR*m.objR;
  const a = m.illum, delta = 4, l3 = lam*lam*lam;
  for (let j=0;j<n;j++){
    const ky = -(j < n/2 ? j : j - n)*dk;
    for (let i=0;i<n;i++){
      const kx = (i < n/2 ? i : i - n)*dk, idx = j*n+i;
      if (S.obj.in){ const tx = kx*lam*1000 - ofx, ty = ky*lam*1000 - ofy; if (tx*tx + ty*ty > r2) continue; }
      const k2 = kx*kx + ky*ky, k = Math.sqrt(k2);
      const d = df + A*Math.cos(2*(Math.atan2(ky, kx) - phiA));
      const x = Math.PI*lam*d*k2 + 0.5*Math.PI*CS*l3*k2*k2;
      const sp = Math.PI*a*(CS*lam*lam*k2*k + d*k);
      const env = Math.exp(-sp*sp - 0.5*Math.PI*Math.PI*lam*lam*delta*delta*k2*k2);
      const xs = x - 2*Math.PI*(kx*sdx + ky*sdy);
      const c = Math.cos(xs)*env, s = -Math.sin(xs)*env, wr = W.re[idx], wi = W.im[idx];
      re[idx] = wr*c - wi*s; im[idx] = wr*s + wi*c;
    }
  }
  fft2(re, im, n, true);
  const img = new Float32Array(M*M);
  for (let j=0;j<M;j++) for (let i=0;i<M;i++){ const q = ((j-OFF)&(n-1))*n + ((i-OFF)&(n-1)); img[j*M+i] = re[q]*re[q] + im[q]*im[q]; }
  const res = {img, T: W.T, df, px};
  cachePut(optCache, key, res);
  return res;
}

function specimenImage(m, dfExtra){
  const R = MAGS[S.mag].R, df = m.dfEff + dfExtra;
  if (S.mag >= 2) return hrImage(m, df);
  const ox = S.stage.x + df*m.tau.x*1e-3, oy = S.stage.y + df*m.tau.y*1e-3;
  const g = geometry(Math.round(ox/(R/128)*4)/4*(R/128), Math.round(oy/(R/128)*4)/4*(R/128), R);
  const key = [g.key, df.toFixed(1), m.ast.x.toFixed(2), m.ast.y.toFixed(2), S.obj.in, S.obj.size, m.objPass].join("|");
  if (optCache.has(key)) return optCache.get(key);
  let T = g.T;
  if (S.obj.in && S.spec){
    const o = OBJS[S.obj.size], t2 = new Float32Array(T.length);
    for (let i=0;i<T.length;i++) t2[i] = m.objPass ? Math.max(0.02, 1-(1-T[i])*o.ctr) : 0.03 + (1-T[i])*0.85;
    T = t2;
  }
  const k = 0.004/g.px;
  const sx = Math.min(40, Math.abs(df + m.ast.x)*k + 0.35), sy = Math.min(40, Math.abs(df - m.ast.x)*k + 0.35);
  let out = boxBlur(T, sx, sy);
  const fr = clamp(-df/4000, -0.7, 0.7)*0.4;
  if (Math.abs(fr) > 0.02){
    const b2 = boxBlur(out, 1.6, 1.6), o2 = new Float32Array(out.length);
    for (let i=0;i<out.length;i++) o2[i] = Math.max(0, out[i] + fr*(out[i]-b2[i]));
    out = o2;
  }
  const res = {img: out, T: g.T, df, px: g.px};
  cachePut(optCache, key, res);
  return res;
}

// ---------------- scattered beams in a focused-probe image ----------------
// With the probe focused in the eucentric-focus plane, beams scattered by the sample at angle θ
// reach that plane displaced by θ·Δz, where Δz is the sample's distance from it. On the screen they form
// concentric rings (Au Debye rings, amorphous-carbon halo) around the probe image.
// The rings shrink to nothing when the sample sits at eucentric focus.
function coverage(wx, wy){
  const gx = ((wx + 31000) % 62000 + 62000) % 62000, gy = ((wy + 31000) % 62000 + 62000) % 62000;
  if (gx < 8000 || gx > 54000 || gy < 8000 || gy > 54000) return [0, 0];
  const hx = Math.floor(wx/3200), hy = Math.floor(wy/3200);
  if (hash(hx,hy,11) < 0.78){
    const cx = (hx+0.5+(hash(hx,hy,12)-0.5)*0.18)*3200, cy = (hy+0.5+(hash(hx,hy,13)-0.5)*0.18)*3200, rr = 700 + hash(hx,hy,14)*600;
    if ((wx-cx)*(wx-cx)+(wy-cy)*(wy-cy) < rr*rr) return [0, 0];
  }
  const f = vnoise(wx/700, wy/700, 5)*0.65 + vnoise(wx/180, wy/180, 6)*0.35;
  return [0.6*smooth(0.5, 0.78, f), 1];
}
function scatterRings(m){
  if (!S.spec || S.mode !== "img") return null;
  const R = m.R, rad = Math.max(Math.abs(m.s)*R, R/64);
  let au = 0, c = 0, n = 0;
  for (let a=-2;a<=2;a++) for (let b=-2;b<=2;b++){
    if (a*a+b*b > 5) continue;
    const cv = coverage(S.stage.x + m.C.x*R + a*rad/2, S.stage.y + m.C.y*R + b*rad/2);
    au += cv[0]; c += cv[1]; n++;
  }
  au /= n; c /= n;
  const dz = Math.abs(m.dfEff), P0 = 8.3*m.flux, rings = [];
  const cut = S.obj.in ? m.objR - m.objRel : 1e9;
  const add = (thetaMrad, P, wFrac, spotty, id) => {
    if (thetaMrad > cut || P <= 0) return;
    const rho = thetaMrad*1e-3*dz/R;
    const w = Math.hypot(Math.abs(m.se)*0.7, wFrac*rho + 0.006);
    const rr = Math.max(rho, w);
    rings.push({rho, w, k: P/(2*Math.pow(Math.PI,1.5)*rr*w), spotty, id});
  };
  for (let r=0;r<D_AU.length;r++) add(m.lam/D_AU[r]*1000, P0*0.1*au*I_AU[r], 0.03, true, r);
  add(12, P0*0.09*c, 0.45, false, 9);           // amorphous carbon halo, first maximum ≈ 0.21 nm
  add(0, P0*0.05*c, 0, false, 10);              // small-angle diffuse scattering
  if (rings.length){ const g = rings[rings.length-1]; if (g.id === 10){ g.w = Math.hypot(Math.abs(m.se)*0.7, 6e-3*dz/R + 0.006); g.k = P0*0.05*c/(Math.PI*g.w*g.w); g.gauss = true; } }
  return rings.length ? rings : null;
}

// ---------------- rendering ----------------
const cv = document.getElementById("screen"), ctx = cv.getContext("2d");
const off = document.createElement("canvas"); off.width = N; off.height = N;
const offCtx = off.getContext("2d");
const imgData = offCtx.createImageData(N, N);
const raw = new Float32Array(N*N);  // detector intensity before display mapping, used by observe()
const inCircle = new Uint8Array(N*N);
for (let j=0;j<N;j++) for (let i=0;i<N;i++){ const u=(i+0.5)/128-1, v=(j+0.5)/128-1; inCircle[j*N+i] = u*u+v*v <= 1 ? 1 : 0; }
const fftCv = document.getElementById("fft"), fftCtx = fftCv.getContext("2d");
let lastObs = null, frameWaiters = [], screenCurrent = 0, dispRange = [0,1];
let noiseSeed = 1;
const sample = new Float32Array(Math.ceil(N*N/3));

function render(t){
  const m = model();
  const on = S.ht > 0 && S.beam && S.valves;
  const screen = S.display === "screen";
  const phase = (Math.floor(t/333) % 2) ? 1 : -1;
  let wobShift = 0, dfExtra = 0;
  if (S.mode === "img" && S.wob === "image") wobShift = clamp(phase*m.zE*1000*0.02/m.R, -0.24, 0.24);
  if (S.mode === "img" && S.wob === "focus") dfExtra = phase*3000;
  let spec = null;
  if (on && S.mode === "img") spec = specimenImage(m, dfExtra);
  const rings = on ? scatterRings(m) : null;
  let sum = 0;
  noiseSeed = (noiseSeed*1103515245 + 12345) >>> 0;
  let ns = noiseSeed;
  const cosT = Math.cos(m.th), sinT = Math.sin(m.th);
  const kEdge = Math.min(300, 4*Math.min(m.rA, m.rB)/m.edge + 4);
  const lam = m.lam;
  for (let j=0;j<N;j++){
    const v = (j+0.5)/128 - 1;
    for (let i=0;i<N;i++){
      const u = (i+0.5)/128 - 1, idx = j*N+i;
      if (screen && !inCircle[idx]){ raw[idx] = 0; continue; }
      let I = 0;
      if (on){
        if (S.mode === "img"){
          const dx = u - m.C.x, dy = -v - m.C.y;
          const xr = dx*cosT + dy*sinT, yr = -dx*sinT + dy*cosT;
          const q = Math.sqrt((xr/m.rA)*(xr/m.rA) + (yr/m.rB)*(yr/m.rB));
          let mask = 1/(1+Math.exp((q-1)*kEdge));
          if (!S.c2.in && q > 1) mask += 0.06*Math.exp(-(q-1)*3);
          const si = clamp(Math.round(i + OFF + wobShift*128), 0, M-1), sj = clamp(j + OFF, 0, M-1);
          let val = spec.img[sj*M+si];
          if (m.shadow > 0.001){
            const sx = m.C.x + dx*m.ig + wobShift, sy = m.C.y + dy*m.ig;
            const fx = clamp((sx+1)*128 - 0.5 + OFF, 0, M-1.001), fy = clamp((1-sy)*128 - 0.5 + OFF, 0, M-1.001);
            const x0 = fx|0, y0 = fy|0, ax = fx-x0, ay = fy-y0, T = spec.T, b = y0*M+x0;
            const tv = (T[b]*(1-ax) + T[b+1]*ax)*(1-ay) + (T[b+M]*(1-ax) + T[b+M+1]*ax)*ay;
            val += (tv - val)*m.shadow;
          }
          I = m.I*mask*val;
          if (rings){
            const r = Math.hypot(dx, dy);
            let ang = null;
            for (let q=0;q<rings.length;q++){
              const g = rings[q];
              if (g.gauss){ const e = r/g.w; if (e < 4) I += g.k*Math.exp(-e*e); continue; }
              const e = (r - g.rho)/g.w;
              if (e > 4 || e < -4) continue;
              let mod = 1;
              if (g.spotty){ if (ang === null) ang = Math.atan2(dy, dx); const h = hash(Math.floor((ang+Math.PI)/(2*Math.PI)*70*(g.id+1)), g.id, 91); mod = 0.35 + 1.95*h*h; }
              I += g.k*mod*Math.exp(-e*e);
            }
          }
        } else {
          const px = u*40, py = -v*40;
          const oxm = m.projE.x*40 + m.tau.x, oym = m.projE.y*40 + m.tau.y;
          const qx = px-oxm, qy = py-oym, k = Math.hypot(qx,qy);
          const ac = m.alphaC, acv = Math.max(ac, 0.7);
          I += m.flux*4/(acv*acv)*(1/(1+Math.exp((k-acv)*6/acv))) + m.flux*2.5*Math.exp(-k/1.1);
          if (S.spec){
            const ang = Math.atan2(qy,qx);
            for (let r=0;r<D_AU.length;r++){
              const th = lam/D_AU[r]*1000, w = 0.3 + ac*0.8, dd = (k-th)/w;
              if (Math.abs(dd) < 3){
                const sp = hash(Math.floor((ang+Math.PI)/(2*Math.PI)*90*(r+1)), r, 77);
                I += 2.2*m.flux*I_AU[r]*Math.exp(-dd*dd)*(0.3 + 1.6*sp*sp*sp);
              }
            }
            I += m.flux*0.35*Math.exp(-k/6);
          }
          if (S.obj.in){
            const ax = m.projE.x*40 + m.objE.x, ay = m.projE.y*40 + m.objE.y;
            if (Math.hypot(px-ax, py-ay) > m.objR) I *= 0.004;
          }
          if (S.stop && ((Math.abs(px) < 1.3 && py < 0) || Math.hypot(px,py) < 2.6)) I *= 0.01;
        }
        ns = (ns*1664525 + 1013904223) >>> 0;
        I *= 1 + ((ns/4294967296) - 0.5)*0.22/Math.sqrt(I + 0.15);
        if (I < 0) I = 0;
      }
      raw[idx] = I;
      if (inCircle[idx]) sum += I;
    }
  }
  screenCurrent = sum/(128*128)*1.8;
  toDisplay(on);
  offCtx.putImageData(imgData, 0, 0);
  const W = cv.width;
  ctx.imageSmoothingEnabled = true;
  ctx.fillStyle = "#0b0d10"; ctx.fillRect(0,0,W,W);
  ctx.drawImage(off, 0, 0, W, W);
  overlays(m, on, W);
  updateFFT(on);
  hud(m, on);
  lastObs = null;
  const ws = frameWaiters; frameWaiters = []; ws.forEach(f => f());
  return m;
}

// detector intensity -> pixels: phosphor screen, camera with auto contrast, or camera with log (HDR) mapping
function toDisplay(on){
  const d = imgData.data, mode = S.display;
  if (mode === "screen"){
    const gain = S.mode === "diff" ? 1.8 : 1.1;
    for (let idx=0, p=0; idx<N*N; idx++, p+=4){
      if (!inCircle[idx]){ d[p]=12; d[p+1]=14; d[p+2]=17; d[p+3]=255; continue; }
      const v = 1 - Math.exp(-raw[idx]*gain), v4 = v*v*v*v;
      d[p] = 30*v + 215*v4; d[p+1] = 255*Math.pow(v,0.9); d[p+2] = 50*v + 195*v4; d[p+3] = 255;
    }
    return;
  }
  let n = 0, hi = 0;
  for (let idx=0; idx<N*N; idx+=3){ sample[n++] = raw[idx]; }
  for (let idx=0; idx<N*N; idx++) if (raw[idx] > hi) hi = raw[idx];
  const srt = sample.subarray(0, n).sort();
  let lo = 0, top = hi;
  if (mode === "camera"){ lo = srt[Math.floor(n*0.01)]; top = srt[Math.floor(n*0.995)]; }
  if (!on || top - lo < 1e-6){ lo = 0; top = Math.max(top, 1e-6); }
  dispRange = [lo, top];
  if (mode === "hdr"){
    // HDR: log scale over 3 decades, blended with histogram equalisation of the lit pixels,
    // so a converged spot shows its internal (shadow) structure instead of a saturated disc
    const ref = Math.max(top*1e-3, 1e-6), norm = 1/Math.log1p(top/ref), thr = ref;
    let start = 0; while (start < n && srt[start] <= thr) start++;
    const span = Math.max(1, n - start);
    for (let idx=0, p=0; idx<N*N; idx++, p+=4){
      const I = raw[idx];
      let g = 0;
      if (I > thr){
        let a0 = start, b0 = n;
        while (a0 < b0){ const mid = (a0 + b0) >> 1; if (srt[mid] < I) a0 = mid + 1; else b0 = mid; }
        g = 255*(0.45*Math.log1p(I/ref)*norm + 0.55*(0.06 + 0.94*(a0 - start)/span));
      }
      d[p]=g; d[p+1]=g; d[p+2]=g; d[p+3]=255;
    }
  } else {
    const sc = 255/(top - lo);
    for (let idx=0, p=0; idx<N*N; idx++, p+=4){ const g = (raw[idx]-lo)*sc; d[p]=g; d[p+1]=g; d[p+2]=g; d[p+3]=255; }
  }
}

function overlays(m, on, W){
  const c = W/2, R = W/2;
  ctx.save();
  ctx.strokeStyle = "rgba(230,173,72,.8)"; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(c-9,c); ctx.lineTo(c+9,c); ctx.moveTo(c,c-9); ctx.lineTo(c,c+9); ctx.stroke();
  if (S.display === "screen"){
    ctx.strokeStyle = "rgba(255,255,255,.07)";
    ctx.beginPath(); ctx.arc(c,c,R*0.5,0,Math.PI*2); ctx.stroke();
  }
  if (on && S.mode === "diff"){
    if (S.obj.in){
      const ax = c + (m.projE.x*40 + m.objE.x)/40*R, ay = c - (m.projE.y*40 + m.objE.y)/40*R;
      ctx.strokeStyle = "rgba(180,200,220,.45)"; ctx.setLineDash([4,4]);
      ctx.beginPath(); ctx.arc(ax, ay, m.objR/40*R, 0, Math.PI*2); ctx.stroke(); ctx.setLineDash([]);
    }
    if (S.stop){
      ctx.fillStyle = "rgba(40,44,50,.92)";
      ctx.fillRect(c-1.3/40*R, c, 2.6/40*R, R);
      ctx.beginPath(); ctx.arc(c, c, 2.6/40*R, 0, Math.PI*2); ctx.fill();
    }
    const L = 10/40*R;
    ctx.strokeStyle = "rgba(220,230,240,.8)"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(c - L/2, W*0.9); ctx.lineTo(c + L/2, W*0.9); ctx.stroke();
    ctx.fillStyle = "rgba(220,230,240,.9)"; ctx.font = "500 12px 'IBM Plex Mono', monospace"; ctx.textAlign = "center";
    ctx.fillText("10 mrad", c, W*0.9 - 7);
  } else if (on){
    const fov = MAGS[S.mag].R*2, target = fov*0.22;
    const pw = Math.pow(10, Math.floor(Math.log10(target)));
    const nice = [1,2,5,10].map(x=>x*pw).reduce((a,b)=> Math.abs(b-target)<Math.abs(a-target)?b:a);
    const L = nice/fov*W;
    ctx.strokeStyle = "rgba(0,0,0,.5)"; ctx.lineWidth = 6;
    ctx.beginPath(); ctx.moveTo(c - L/2, W*0.9); ctx.lineTo(c + L/2, W*0.9); ctx.stroke();
    ctx.strokeStyle = "rgba(235,240,245,.9)"; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(c - L/2, W*0.9); ctx.lineTo(c + L/2, W*0.9); ctx.stroke();
    ctx.fillStyle = "rgba(235,240,245,.95)"; ctx.font = "500 12px 'IBM Plex Mono', monospace"; ctx.textAlign = "center";
    ctx.shadowColor = "rgba(0,0,0,.8)"; ctx.shadowBlur = 3;
    ctx.fillText(nice >= 1000 ? (nice/1000)+" µm" : nice+" nm", c, W*0.9 - 8);
  }
  if (!on){
    ctx.fillStyle = "rgba(160,175,190,.6)"; ctx.font = "500 14px 'IBM Plex Sans Condensed', sans-serif"; ctx.textAlign = "center";
    ctx.fillText(S.ht === 0 ? "High tension off" : (!S.valves ? "Column valves closed" : "Beam off"), c, c + 30);
  }
  ctx.restore();
}

// live FFT of the whole camera frame (256², Hann window, log power, light 3×3 smoothing)
const FN = N, fre = new Float64Array(N*N), fim = new Float64Array(N*N), hann = new Float64Array(N);
for (let i=0;i<N;i++) hann[i] = 0.5 - 0.5*Math.cos(2*Math.PI*(i+0.5)/N);
const fftImg = fftCtx.createImageData(FN, FN), fpow = new Float32Array(FN*FN), fsm = new Float32Array(FN*FN);
function updateFFT(on){
  const show = S.fft && S.mode === "img" && on && S.mag >= 2;
  fftCv.hidden = !show; document.getElementById("fftLab").hidden = !show;
  if (!show) return;
  let mean = 0;
  for (let q=0;q<N*N;q++) mean += raw[q];
  mean /= N*N;
  for (let j=0;j<N;j++) for (let i=0;i<N;i++){ const q = j*N+i; fre[q] = (raw[q] - mean)*hann[i]*hann[j]; fim[q] = 0; }
  fft2(fre, fim, N, false);
  for (let j=0;j<N;j++) for (let i=0;i<N;i++){
    const q = j*N+i, sj = (j + N/2) % N, si = (i + N/2) % N;
    fpow[sj*FN+si] = fre[q]*fre[q] + fim[q]*fim[q];
  }
  for (let j=0;j<FN;j++) for (let i=0;i<FN;i++){
    let acc = 0, w = 0;
    for (let b=-1;b<=1;b++) for (let a=-1;a<=1;a++){ const y = j+b, x = i+a; if (x<0||y<0||x>=FN||y>=FN) continue; const wt = (a||b) ? 1 : 2; acc += fpow[y*FN+x]*wt; w += wt; }
    fsm[j*FN+i] = Math.log(1e-12 + acc/w);
  }
  const c = (FN/2)*FN + FN/2; fsm[c] = fsm[c+1];
  const srt = Float32Array.from(fsm).sort(), lo = srt[Math.floor(FN*FN*0.03)], hi = srt[Math.floor(FN*FN*0.998)];
  const sc = 255/Math.max(hi - lo, 1e-6);
  for (let q=0, p=0; q<FN*FN; q++, p+=4){ const g = clamp((fsm[q]-lo)*sc, 0, 255); fftImg.data[p]=g; fftImg.data[p+1]=g; fftImg.data[p+2]=g; fftImg.data[p+3]=255; }
  fftCtx.putImageData(fftImg, 0, 0);
}

function hud(m, on){
  const mag = MAGS[S.mag];
  document.getElementById("hud").innerHTML =
    `<b>${S.mode === "img" ? "IMAGING" : "DIFFRACTION"}</b><br>${S.mode === "img" ? mag.name+" · "+mag.label : "camera length 250 mm"}<br>${S.ht ? S.ht+" kV" : "HT off"} · spot ${S.spot}<br>${{camera:"CAMERA",hdr:"CAMERA HDR",screen:"SCREEN"}[S.display]}` +
    (S.wob !== "off" && S.mode === "img" ? `<br><b style="color:#e6ad48">WOBBLER ${S.wob.toUpperCase()}</b>` : "");
  document.getElementById("cur").textContent = on ? screenCurrent.toFixed(2) : "0.00";
}

// ---------------- observation (what an operator / agent can measure) ----------------
function observe(){
  // Beam position and shape from the lit area (pixels above 25% of the peak), as an operator judges it by eye,
  // so specimen contrast inside the beam does not bias the centroid.
  if (lastObs) return lastObs;
  let peak = 0;
  for (let q=0;q<N*N;q++) if (raw[q] > peak) peak = raw[q];
  if (peak <= 1e-6) return (lastObs = {current:0, centroid:{x:0,y:0}, radius:0, ellipticity:0, angle:0});
  const thr = 0.25*peak;
  let s=0, sx=0, sy=0;
  for (let j=0;j<N;j++) for (let i=0;i<N;i++){ if (raw[j*N+i] < thr) continue; const u=(i+0.5)/128-1, v=-((j+0.5)/128-1); s++; sx+=u; sy+=v; }
  const cx = sx/s, cy = sy/s;
  let xx=0, yy=0, xy=0;
  for (let j=0;j<N;j++) for (let i=0;i<N;i++){ if (raw[j*N+i] < thr) continue; const u=(i+0.5)/128-1-cx, v=-((j+0.5)/128-1)-cy; xx+=u*u; yy+=v*v; xy+=u*v; }
  xx/=s; yy/=s; xy/=s;
  const tr = xx+yy, det = xx*yy-xy*xy, disc = Math.sqrt(Math.max(0, tr*tr/4-det));
  const l1 = tr/2+disc, l2 = Math.max(1e-9, tr/2-disc);
  lastObs = {current: screenCurrent, centroid:{x:cx, y:cy}, radius: 2*Math.sqrt((l1+l2)/2), ellipticity: 1-Math.sqrt(l2/l1), angle: 0.5*Math.atan2(2*xy, xx-yy)};
  return lastObs;
}

// ---------------- metrics (ground truth) ----------------
function metrics(){
  const m = model();
  return {
    beamShift: hyp(m.bsE), c2Aperture: S.c2.in ? hyp(sub(S.c2,H.c2)) : null, c2Stig: hyp(sub(S.c2stig,H.cs)),
    gunTilt: m.gE, eucentricZ_um: m.zE, rotationCentre_mrad: hyp(m.tau), objApertureOffset_mrad: S.obj.in ? m.objRel : null,
    projector: hyp(m.projE), objStig_nm: hyp(m.ast), defocus_nm: m.dfEff, scherzer_nm: -1.2*Math.sqrt(CS*m.lam),
  };
}

// ---------------- guided procedure ----------------
const steps = [
  {t:"Insert the specimen holder", d:"Load the gold-nanoparticle specimen on holey carbon into the column.", cue:["spec"], ok:()=>S.spec},
  {t:"Set the high tension", d:"Choose 200 kV for this materials specimen. Beam-sensitive biological sections usually get 120 kV.", cue:["ht"], ok:()=>S.ht===200},
  {t:"Turn the beam on", d:"Switch the beam on. It will usually be somewhere off-centre and may be faint.", cue:["beam"], ok:()=>S.beam},
  {t:"Centre the beam with beam shift", d:"Turn Brightness toward crossover so the beam is a small bright spot, then use Beam shift to put it on the cross.", cue:["bright","bs"], ok:()=>{const m=model();return S.beam && hyp(m.C)<0.05 && Math.hypot(m.rA,m.rB)<1.2;}},
  {t:"Peak the gun tilt", d:"In Direct alignment choose Gun tilt. Move it until the screen current reading is at its maximum.", cue:["dir"], ok:()=>model().gE<0.08},
  {t:"Insert the condenser aperture", d:"Choose Condenser (C2) in Apertures, pick a size, then press Insert. The soft halo around the beam disappears.", cue:["ap"], ok:()=>S.c2.in},
  {t:"Centre the condenser aperture", d:"Converge to crossover and centre the spot with Beam shift. Spread the beam and centre it with the aperture pad. Repeat until the beam stays on the cross while you turn Brightness through crossover.", cue:["bright","bs","ap"], ok:()=>S.c2.in && hyp(model().bsE)<0.03 && hyp(sub(S.c2,H.c2))<0.03},
  {t:"Correct condenser astigmatism", d:"Go just above or below crossover. An astigmatic beam is elliptical and flips 90° as you pass through crossover. Use the Condenser stigmator until it expands and contracts as a circle.", cue:["bright","stig"], ok:()=>hyp(sub(S.c2stig,H.cs))<0.05},
  {t:"Spread the beam over the screen", d:"Turn Brightness away from crossover until the illumination fills the whole screen evenly.", cue:["bright"], ok:()=>{const m=model();return Math.min(m.rA,m.rB)>1.1 && hyp(m.C)<0.1;}},
  {t:"Find eucentric focus with Z", d:"Press Eucentric focus and retract the objective aperture. Focused beam (Tecnai manual method 2): at Medium magnification set Display to HDR and converge the beam with Brightness. You see a bright central spot with concentric rings around it: Au Debye rings and the carbon halo. Change Z. If the rings grow, go the other way. You are at eucentric focus when the rings have collapsed into the spot. Ring radius is scattering angle × Z error × magnification, so finish at High magnification, where the last few µm still show rings. Wobbler method: set the Wobbler to Image and change Z until the image stops shaking. Switch the wobbler off when done.", cue:["focus","mag","wob","disp","bright","z"], ok:()=>Math.abs(model().zE)<0.3 && S.wob==="off"},
  {t:"Align the rotation centre", d:"Go to High magnification. Set the Wobbler to Focus and choose Beam tilt in Direct alignment. Adjust until the image pulses in place without moving sideways, then switch the wobbler off.", cue:["mag","wob","dir"], ok:()=>hyp(model().tau)<0.3 && S.wob==="off"},
  {t:"Centre the pattern with the projector", d:"Switch to Diffraction. Choose Projector alignment and bring the central spot onto the cross. Insert the beam stop to check it covers the spot.", cue:["mode","dir","stop"], ok:()=>S.mode==="diff" && hyp(model().projE)<0.03},
  {t:"Centre the objective aperture", d:"Still in Diffraction, choose Objective in Apertures, pick Large, insert it and centre it around the central spot. Large keeps the 0.235 nm Au(111) reflection inside for lattice imaging.", cue:["ap"], ok:()=>{const m=model();return S.obj.in && m.objRel < 0.15*m.objR && m.fringePass;}},
  {t:"Focus at high magnification", d:"Back to Imaging at High magnification. Focus with the slider and fine buttons until the particle edges are sharp with no Fresnel fringe.", cue:["mode","mag","focus"], ok:()=>S.mode==="img" && S.mag>=2 && Math.abs(model().dfEff)<150},
  {t:"Correct objective astigmatism", d:"Go to Very high magnification, spread the beam and move the stage onto amorphous carbon (the status bar shows what is under the centre). Turn on the FFT. Elliptical Thon rings mean astigmatism. Use the Objective stigmator until the rings are circles. Over a hole the FFT is empty; over a particle you see lattice spots.", cue:["mag","fft","stig"], ok:()=>S.mag===3 && hyp(model().ast)<3},
  {t:"Set Scherzer focus and acquire", d:"Underfocus slightly until the gold lattice fringes are strongest (about −66 nm at 200 kV). Press Acquire.", cue:["focus","acq"], ok:()=>acqOK},
];
let stepIdx = 0, acqOK = false;
const stepsEl = document.getElementById("steps");
function buildSteps(){
  stepsEl.innerHTML = "";
  steps.forEach((s, i) => {
    const li = document.createElement("li");
    li.innerHTML = `<span class="t">${s.t}</span><span class="d">${s.d}</span>`;
    li.addEventListener("click", () => { stepIdx = i; refreshSteps(); });
    stepsEl.appendChild(li);
  });
}
function refreshSteps(){
  [...stepsEl.children].forEach((li, i) => {
    li.classList.toggle("cur", i === stepIdx);
    li.classList.toggle("done", !!steps[i].done);
  });
  document.getElementById("stepCount").textContent = stepIdx < steps.length ? `Step ${stepIdx+1} of ${steps.length}` : "Complete";
  document.querySelectorAll("[data-cue]").forEach(el => el.classList.remove("cue"));
  if (UI.guide && steps[stepIdx]) steps[stepIdx].cue.forEach(c => document.querySelectorAll(`[data-cue="${c}"]`).forEach(el => el.classList.add("cue")));
}
function checkSteps(){
  const s = steps[stepIdx];
  if (!s) return;
  if (s.ok()){
    s.done = true;
    if (stepIdx < steps.length - 1) stepIdx++; else stepIdx = steps.length;
    refreshSteps();
  }
}
document.getElementById("prevStep").onclick = () => { stepIdx = Math.max(0, stepIdx-1); steps[stepIdx].done = false; refreshSteps(); };
document.getElementById("skipStep").onclick = () => { if (stepIdx < steps.length){ steps[stepIdx].done = true; stepIdx++; refreshSteps(); } };

// ---------------- controls ----------------
const ARROW = {up:"M6 2 11 9H1z", down:"M6 10 1 3h10z", left:"M2 6 9 1v10z", right:"M10 6 3 11V1z"};
function makePad(host, key){
  const pad = document.createElement("div"); pad.className = "pad";
  const cells = [null,"up",null,"left","knob","right",null,"down",null];
  cells.forEach(c => {
    const b = document.createElement("button");
    if (!c){ b.className = "blank"; b.tabIndex = -1; b.setAttribute("aria-hidden","true"); pad.appendChild(b); return; }
    if (c === "knob"){
      b.className = "knob"; b.setAttribute("aria-label", "Drag to adjust");
      let last = null;
      b.addEventListener("pointerdown", e => { b.setPointerCapture(e.pointerId); last = {x:e.clientX, y:e.clientY}; });
      b.addEventListener("pointermove", e => { if (!last) return; const dx = e.clientX-last.x, dy = e.clientY-last.y; last = {x:e.clientX, y:e.clientY}; nudgeKey(key, dx*0.35, -dy*0.35); });
      const end = () => last = null;
      b.addEventListener("pointerup", end); b.addEventListener("pointercancel", end);
    } else {
      b.innerHTML = `<svg viewBox="0 0 12 12"><path d="${ARROW[c]}"/></svg>`;
      b.setAttribute("aria-label", c);
      const dir = {up:[0,1], down:[0,-1], left:[-1,0], right:[1,0]}[c];
      let tm = null, iv = null;
      const stop = () => { clearTimeout(tm); clearInterval(iv); tm = iv = null; };
      b.addEventListener("pointerdown", e => { e.preventDefault(); nudgeKey(key, dir[0], dir[1]); tm = setTimeout(() => iv = setInterval(() => nudgeKey(key, dir[0], dir[1]), 55), 300); });
      b.addEventListener("pointerup", stop); b.addEventListener("pointerleave", stop); b.addEventListener("pointercancel", stop);
      b.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " "){ e.preventDefault(); nudgeKey(key, dir[0], dir[1]); } });
    }
    pad.appendChild(b);
  });
  host.prepend(pad);
}
const STEP = {bs:[0.01,0.05], c2:[0.01,0.05], obj:[0.25,1], c2stig:[0.02,0.1], objstig:[0.5,3], gun:[0.02,0.1], btilt:[0.1,0.5], proj:[0.01,0.05]};
function nudgeKey(padKey, dx, dy){
  let k = padKey;
  if (padKey === "ap") k = UI.apSel;
  if (padKey === "stig") k = UI.stig === "c2" ? "c2stig" : "objstig";
  if (padKey === "dir") k = UI.dir;
  nudge(k, dx, dy);
}
function nudge(k, dx, dy){
  const c = UI.coarse ? 1 : 0;
  if (k === "stage"){ const st = MAGS[S.mag].R*(c ? 0.2 : 0.04); S.stage.x += dx*st; S.stage.y += dy*st; }
  else if (k === "z"){ S.stage.z = +(S.stage.z + dx*(c ? 2 : 0.2)).toFixed(3); }
  else if (k === "focus"){ S.dfc += dx*MAGS[S.mag].f[c]; }
  else if (STEP[k]){ const o = S[k]; o.x += dx*STEP[k][c]; o.y += dy*STEP[k][c]; }
  else throw new Error("Unknown control: "+k);
  sync();
}

const $ = id => document.getElementById(id);
makePad($("bsPad"), "bs"); makePad($("apPad"), "ap"); makePad($("stigPad"), "stig"); makePad($("dirPad"), "dir"); makePad($("stagePad"), "stage");

function press(el, v){ el.setAttribute("aria-pressed", v ? "true" : "false"); }
function fillApSize(){
  const list = UI.apSel === "c2" ? C2S : OBJS, cur = UI.apSel === "c2" ? S.c2.size : S.obj.size;
  $("apSize").innerHTML = list.map((o,i)=>`<option value="${i}" ${i===cur?"selected":""}>${o.n}</option>`).join("");
}
$("specBtn").onclick = () => { S.spec = !S.spec; sync(); };
$("ht").onchange = e => { S.ht = +e.target.value; if (!S.ht) S.beam = false; sync(); };
$("valveBtn").onclick = () => { S.valves = !S.valves; sync(); };
$("beamBtn").onclick = () => { if (!S.ht) return; S.beam = !S.beam; sync(); };
$("spot").onchange = e => { S.spot = +e.target.value; sync(); };
$("bright").oninput = e => { S.bright = +e.target.value; sync(); };
$("apSel").onchange = e => { UI.apSel = e.target.value; fillApSize(); sync(); };
$("apSize").onchange = e => { (UI.apSel === "c2" ? S.c2 : S.obj).size = +e.target.value; sync(); };
$("apInBtn").onclick = () => { const a = UI.apSel === "c2" ? S.c2 : S.obj; a.in = !a.in; sync(); };
$("stigC2").onclick = () => { UI.stig = "c2"; sync(); };
$("stigObj").onclick = () => { UI.stig = "obj"; sync(); };
$("dirSel").onchange = e => { UI.dir = e.target.value; sync(); };
function holdRepeat(el, fn){
  let tm = null, iv = null;
  const stop = () => { clearTimeout(tm); clearInterval(iv); tm = iv = null; };
  el.addEventListener("pointerdown", e => { e.preventDefault(); fn(); tm = setTimeout(() => iv = setInterval(fn, 70), 350); });
  el.addEventListener("pointerup", stop); el.addEventListener("pointerleave", stop); el.addEventListener("pointercancel", stop);
  el.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " "){ e.preventDefault(); fn(); } });
}
holdRepeat($("zUp"), () => nudge("z", 1, 0));
holdRepeat($("zDown"), () => nudge("z", -1, 0));
$("modeImg").onclick = () => { S.mode = "img"; sync(); };
$("modeDiff").onclick = () => { S.mode = "diff"; sync(); };
$("mag").onchange = e => { S.mag = +e.target.value; sync(); };
$("focus").oninput = e => { S.dfc = +e.target.value; sync(); };
holdRepeat($("fUp"), () => nudge("focus", 1, 0));
holdRepeat($("fDown"), () => nudge("focus", -1, 0));
$("stdFocus").onclick = () => { S.dfc = 0; sync(); };
$("disp").onchange = e => { S.display = e.target.value; sync(); };
$("wob").onchange = e => { S.wob = e.target.value; sync(); };
$("fftBtn").onclick = () => { S.fft = !S.fft; sync(); };
$("stopBtn").onclick = () => { S.stop = !S.stop; sync(); };
$("fineBtn").onclick = () => { UI.coarse = false; sync(); };
$("coarseBtn").onclick = () => { UI.coarse = true; sync(); };
$("guideBtn").onclick = () => { UI.guide = !UI.guide; press($("guideBtn"), UI.guide); refreshSteps(); };
$("truthBtn").onclick = () => { UI.truth = !UI.truth; press($("truthBtn"), UI.truth); $("truthBtn").textContent = UI.truth ? "Hide" : "Show"; $("truthWrap").hidden = !UI.truth; };
$("randBtn").onclick = () => { randomize(); steps.forEach(s => s.done = false); stepIdx = 0; acqOK = false; resetControls(); sync(); refreshSteps(); };

function findSite(){
  for (let r=0; r<30; r++) for (let a=0; a<24; a++){
    const x = Math.cos(a/24*2*Math.PI)*r*400, y = Math.sin(a/24*2*Math.PI)*r*400;
    const f = vnoise(x/700, y/700, 5)*0.65 + vnoise(x/180, y/180, 6)*0.35;
    if (f < 0.66 || f > 0.72) continue;
    const hx = Math.floor(x/3200), hy = Math.floor(y/3200);
    if (hash(hx,hy,11) < 0.78){
      const cx = (hx+0.5+(hash(hx,hy,12)-0.5)*0.18)*3200, cy = (hy+0.5+(hash(hx,hy,13)-0.5)*0.18)*3200, rr = 700 + hash(hx,hy,14)*600;
      if (Math.hypot(x-cx, y-cy) < rr + 300) continue;
    }
    return {x, y};
  }
  return {x:0, y:0};
}
function resetControls(){
  Object.assign(S, {spot:3, bright:75, mode:"img", mag:0, dfc:0, wob:"off", fft:false, stop:false});
  for (const k of ["bs","c2stig","objstig","gun","btilt","proj"]) S[k] = {x:0,y:0};
  S.c2 = {in:false,size:1,x:0,y:0}; S.obj = {in:false,size:2,x:0,y:0}; const st = findSite(); S.stage = {x:st.x, y:st.y, z:0};
}

const f2 = v => (v>=0?"+":"") + v.toFixed(2), f1 = v => (v>=0?"+":"") + v.toFixed(1);
function sync(){
  S.dfc = clamp(S.dfc, -30000, 30000);
  S.stage.z = clamp(S.stage.z, -200, 200);
  press($("specBtn"), S.spec); $("specBtn").textContent = S.spec ? "Holder in" : "Insert holder";
  $("ht").value = S.ht;
  press($("valveBtn"), S.valves); $("valveBtn").textContent = S.valves ? "Open" : "Closed";
  press($("beamBtn"), S.beam); $("beamBtn").textContent = S.beam ? "Beam on" : "Beam off"; $("beamBtn").disabled = !S.ht;
  $("spot").value = S.spot;
  $("bright").value = S.bright; $("brightVal").textContent = S.bright.toFixed(1);
  $("bsVal").textContent = `x ${f2(S.bs.x)}  y ${f2(S.bs.y)}`;
  const a = UI.apSel === "c2" ? S.c2 : S.obj;
  press($("apInBtn"), a.in); $("apInBtn").textContent = a.in ? "Retract" : "Insert";
  $("apVal").textContent = UI.apSel === "c2" ? `C2 x ${f2(S.c2.x)}  y ${f2(S.c2.y)}` : `OBJ x ${f1(S.obj.x)}  y ${f1(S.obj.y)} mrad`;
  $("apSel").value = UI.apSel;
  press($("stigC2"), UI.stig === "c2"); press($("stigObj"), UI.stig === "obj");
  $("stigVal").textContent = UI.stig === "c2" ? `C2 x ${f2(S.c2stig.x)}  y ${f2(S.c2stig.y)}` : `OBJ x ${f1(S.objstig.x)}  y ${f1(S.objstig.y)} nm`;
  $("dirSel").value = UI.dir;
  const dv = S[UI.dir];
  $("dirVal").textContent = `x ${UI.dir==="btilt"?f1(dv.x):f2(dv.x)}  y ${UI.dir==="btilt"?f1(dv.y):f2(dv.y)}${UI.dir==="btilt"?" mrad":""}`;
  const us = v => Math.abs(v) >= 1000 ? (v/1000).toFixed(2)+" µm" : v.toFixed(1)+" nm";
  $("stageVal").textContent = `x ${us(S.stage.x)}  y ${us(S.stage.y)}`;
  $("zVal").textContent = `${S.stage.z.toFixed(1)} µm`;
  press($("modeImg"), S.mode === "img"); press($("modeDiff"), S.mode === "diff");
  $("mag").value = S.mag;
  $("focus").value = S.dfc; $("focusVal").textContent = `${S.dfc.toFixed(0)} nm`;
  $("wob").value = S.wob;
  $("disp").value = S.display;
  press($("fftBtn"), S.fft); press($("stopBtn"), S.stop); $("stopBtn").textContent = S.stop ? "Retract" : "Insert";
  press($("fineBtn"), !UI.coarse); press($("coarseBtn"), UI.coarse);
  dirty = true;
}

// ---------------- acquisition ----------------
const acquired = [];
function addToGallery(prefix){
  const url = cv.toDataURL("image/jpeg", 0.85);
  const cap = (prefix || "") + (S.mode === "img" ? `${MAGS[S.mag].label} · Δf ${S.dfc.toFixed(0)}` : "Diffraction");
  acquired.unshift({url, cap});
  if (acquired.length > 8) acquired.pop();
  $("gallery").innerHTML = acquired.map(a => `<figure><img src="${a.url}" alt="${a.cap}"><figcaption>${a.cap}</figcaption></figure>`).join("");
}
$("acqBtn").onclick = () => {
  const on = S.ht && S.beam && S.valves;
  if (!on) return;
  const m = model();
  addToGallery("");
  if (S.mag === 3 && S.mode === "img" && m.dfEff > -110 && m.dfEff < -30 && hyp(m.ast) < 3 && m.fringePass) acqOK = true;
};

function regionAtCentre(){
  if (!S.spec) return "no specimen";
  const px = S.mag >= 2 ? MAGS[S.mag].R/128 : 1;
  world(S.stage.x, S.stage.y, Math.min(px, 1));
  return _cls;
}
function statusBar(){
  const o = observe();
  $("status").innerHTML = `<span>beam centroid <b>${f2(o.centroid.x)}, ${f2(o.centroid.y)}</b></span><span>beam radius <b>${o.radius.toFixed(2)}</b></span><span>ellipticity <b>${o.ellipticity.toFixed(2)}</b></span><span>under centre <b>${regionAtCentre()}</b></span><span>seed <b>${seed}</b></span>`;
}
function truthTable(){
  if (!UI.truth) return;
  const m = model(), mt = metrics();
  const rows = [
    ["Beam shift", hyp(m.bsE).toFixed(3), "0.03", hyp(m.bsE) < 0.03],
    ["C2 aperture", S.c2.in ? hyp(sub(S.c2,H.c2)).toFixed(3) : "out", "0.03", S.c2.in && hyp(sub(S.c2,H.c2)) < 0.03],
    ["C2 stigmator", mt.c2Stig.toFixed(3), "0.05", mt.c2Stig < 0.05],
    ["Gun tilt", m.gE.toFixed(3), "0.08", m.gE < 0.08],
    ["Eucentric Z (µm)", m.zE.toFixed(2), "±0.3", Math.abs(m.zE) < 0.3],
    ["Rotation centre (mrad)", hyp(m.tau).toFixed(2), "0.3", hyp(m.tau) < 0.3],
    ["Projector", hyp(m.projE).toFixed(3), "0.03", hyp(m.projE) < 0.03],
    ["Obj. aperture (mrad)", S.obj.in ? m.objRel.toFixed(2) : "out", "0.15 r", S.obj.in && m.objRel < 0.15*m.objR],
    ["Obj. stigmator (nm)", hyp(m.ast).toFixed(1), "3", hyp(m.ast) < 3],
    ["Defocus (nm)", m.dfEff.toFixed(0), "−66", m.dfEff > -110 && m.dfEff < -30],
  ];
  $("truth").innerHTML = `<tr><th>Alignment</th><th class="n">Error</th><th class="n">Tol.</th></tr>` +
    rows.map(r => `<tr><td><span class="dot ${r[3]?"ok":""}"></span>${r[0]}</td><td class="n">${r[1]}</td><td class="n">${r[2]}</td></tr>`).join("");
}

// ---------------- main loop ----------------
let dirty = true, lastT = 0, uiT = 0;
function loop(t){
  const animating = S.beam && S.ht;
  if (dirty || (animating && t - lastT > 45)){
    render(t); dirty = false; lastT = t;
  }
  if (t - uiT > 200){ uiT = t; checkSteps(); statusBar(); truthTable(); }
  requestAnimationFrame(loop);
}

// ---------------- automated routines (observe-only) ----------------
// Yield between measurement frames so observers still receive progress during long routines.
const frame = () => new Promise(r => {
  setImmediate(() => { render(performance.now()); dirty = false; r(); });
});
const settle = async () => { if (typeof abortAlign !== "undefined" && abortAlign) throw new Error("stopped"); await frame(); await frame(); return observe(); };
const logEl = $("autolog");
const log = s => { logEl.textContent = (s + "\n" + logEl.textContent).slice(0, 2000); };
let busy = false;
async function guard(name, fn){
  if (busy) return; busy = true;
  document.querySelectorAll(".autorow .btn").forEach(b => b.disabled = true);
  try { log(`${name}: start`); await fn(); log(`${name}: done`); }
  catch(e){ log(`${name}: ${e.message}`); }
  finally { busy = false; document.querySelectorAll(".autorow .btn").forEach(b => b.disabled = false); sync(); }
}
function needBeam(){ if (!S.ht || !S.beam) throw new Error("turn the high tension and beam on first"); S.mode = "img"; S.wob = "off"; }

// If the focused spot is off the screen, find it with a spread beam first, as an operator would
async function findBeam(){
  S.bright = XO + 1.5;
  let o = await settle();
  for (let it=0; it<8 && o.current < 0.02; it++){
    // spread progressively; as a last resort pull the C2 aperture so the beam covers more of the screen
    let w = null;
    for (const b of [72, 100]){ S.bright = b; w = await settle(); if (w.current >= 0.02) break; }
    let pulled = false;
    if (w.current < 0.02 && S.c2.in){ S.c2.in = false; pulled = true; w = await settle(); }
    if (w.current < 0.02){ if (pulled) S.c2.in = true; throw new Error("no beam on the screen even with a spread beam and no C2 aperture; check gun tilt"); }
    S.bs.x -= 1.2*w.centroid.x; S.bs.y -= 1.2*w.centroid.y;
    if (pulled) S.c2.in = true;
    S.bright = XO + 1.5; o = await settle();
  }
  if (o.current < 0.02) throw new Error("could not bring the focused beam onto the screen");
}
async function autoBeam(){
  needBeam();
  const saveMag = S.mag, saveBright = S.bright;
  S.mag = 1;                                   // work at SA magnification (20 kx), as in the Tecnai C2 procedure
  try { await findBeam(); await autoBeamCore(); } finally { S.mag = saveMag; S.bright = saveBright; sync(); }
}
async function autoBeamCore(){
  if (!S.c2.in){ S.c2.in = true; log("inserted C2 aperture"); }
  const clampv = (x, y, lim) => { const n = Math.hypot(x, y); return n > lim ? [x*lim/n, y*lim/n] : [x, y]; };
  // calibrate the beam-shift response on the focused spot
  S.bright = XO + 1.5; let o = await settle();
  const c0 = o.centroid; S.bs.x += 0.1; const o1 = await settle(); S.bs.x -= 0.1;
  let gBs = (o1.centroid.x - c0.x)/0.1;
  if (!(gBs > 0.3 && gBs < 3)) gBs = 1;              // implausible: use the nominal calibration
  let gAp = null;
  for (let it=0; it<16; it++){
    S.bright = XO + 1.5; o = await settle();
    if (o.current < 0.02){ await findBeam(); o = await settle(); }
    let [dx, dy] = clampv(o.centroid.x/gBs, o.centroid.y/gBs, 0.5);
    S.bs.x -= dx; S.bs.y -= dy;
    S.bright = 88; o = await settle();
    if (o.current < 0.02) continue;
    if (gAp === null){
      const s0 = o.centroid; S.c2.x += 0.05; const oc = await settle(); S.c2.x -= 0.05;
      gAp = (oc.centroid.x - s0.x)/0.05;
      if (!(gAp > 0.2 && gAp < 2)) gAp = 0.85;
    }
    [dx, dy] = clampv(o.centroid.x/gAp, o.centroid.y/gAp, 0.3);
    S.c2.x -= dx; S.c2.y -= dy;
    o = await settle();
    log(`  iter ${it+1}: spread-beam offset ${hyp(o.centroid).toFixed(3)}`);
    if (hyp(o.centroid) < 0.004 && it > 1) break;
  }
  S.bright = XO + 1.5; const f = await settle();
  if (f.current >= 0.02){ S.bs.x -= f.centroid.x/gBs; S.bs.y -= f.centroid.y/gBs; }
}
async function autoGun(){
  needBeam();
  let best = (await settle()).current, d = 0.12;
  for (let it=0; it<24 && d > 0.005; it++){
    let improved = false;
    for (const [ax, sg] of [["x",1],["x",-1],["y",1],["y",-1]]){
      S.gun[ax] += sg*d; const c = (await settle()).current;
      if (c > best*1.0005){ best = c; improved = true; } else S.gun[ax] -= sg*d;
    }
    if (!improved) d /= 2;
  }
  log(`  screen current ${best.toFixed(2)} nA`);
}
async function autoStig(){
  needBeam();
  const save = S.bright;
  const ap = S.c2.in ? C2S[S.c2.size] : C2NONE;
  S.bright = XO + 0.18/(1.5*ap.sf)*55;
  let best = (await settle()).ellipticity, d = 0.15;
  for (let it=0; it<30 && d > 0.004; it++){
    let improved = false;
    for (const [ax, sg] of [["x",1],["x",-1],["y",1],["y",-1]]){
      S.c2stig[ax] += sg*d; const e = (await settle()).ellipticity;
      if (e < best){ best = e; improved = true; } else S.c2stig[ax] -= sg*d;
    }
    if (!improved) d /= 2;
  }
  log(`  ellipticity ${best.toFixed(3)}`);
  S.bright = save;
}
async function autoBeamShift(){
  needBeam();
  const save = S.bright, saveMag = S.mag;
  S.mag = 1;
  try {
    await findBeam();
    let o = await settle();
    const c0 = o.centroid; S.bs.x += 0.1; const o1 = await settle(); S.bs.x -= 0.1;
    const g = (o1.centroid.x - c0.x)/0.1 || 1;
    for (let it=0; it<4; it++){ o = await settle(); S.bs.x -= o.centroid.x/g; S.bs.y -= o.centroid.y/g; }
    o = await settle();
    log(`  spot offset ${hyp(o.centroid).toFixed(3)}`);
    return hyp(o.centroid);
  } finally { S.bright = save; S.mag = saveMag; sync(); }
}
$("autoBeam").onclick = () => guard("beam + C2", autoBeam);
$("autoGun").onclick = () => guard("gun tilt", autoGun);
$("autoStig").onclick = () => guard("C2 stig", autoStig);

// ---------------- Auto align: measure each alignment, correct only what is out of tolerance ----------------
// Every step measures its alignment from camera frames (never the hidden state). Steps within tolerance are
// left untouched; the working conditions (magnification, intensity, focus, mode, stage x/y, display) are restored.
let abortAlign = false;
const pxNm = () => 2*MAGS[S.mag].R/N;
async function grab(){
  if (abortAlign) throw new Error("stopped");
  await frame(); await frame();
  return Float32Array.from(raw);
}
const HANN128 = (() => { const w = new Float64Array(128); for (let i=0;i<128;i++) w[i] = 0.5 - 0.5*Math.cos(2*Math.PI*(i+0.5)/128); return w; })();
const HANN256 = (() => { const w = new Float64Array(N); for (let i=0;i<N;i++) w[i] = 0.5 - 0.5*Math.cos(2*Math.PI*(i+0.5)/N); return w; })();

// Shift (pixels, x right, y up) that moves the content of frame a onto frame b; phase correlation of the central 128².
function imageShift(a, b){
  const n = 128, o = (N - n)/2;
  const ar = new Float64Array(n*n), ai = new Float64Array(n*n), br = new Float64Array(n*n), bi = new Float64Array(n*n);
  let ma = 0, mb = 0;
  for (let j=0;j<n;j++) for (let i=0;i<n;i++){ const q = (j+o)*N + i + o; ma += a[q]; mb += b[q]; }
  ma /= n*n; mb /= n*n;
  for (let j=0;j<n;j++) for (let i=0;i<n;i++){ const q = (j+o)*N + i + o, w = HANN128[i]*HANN128[j]; ar[j*n+i] = (a[q]-ma)*w; br[j*n+i] = (b[q]-mb)*w; }
  fft2(ar, ai, n, false); fft2(br, bi, n, false);
  for (let k=0;k<n*n;k++){
    const re = br[k]*ar[k] + bi[k]*ai[k], im = bi[k]*ar[k] - br[k]*ai[k], m = Math.hypot(re, im) + 1e-12;
    ar[k] = re/m; ai[k] = im/m;
  }
  fft2(ar, ai, n, true);
  let bj = 0, bI = 0, bv = -1e9;
  for (let k=0;k<n*n;k++) if (ar[k] > bv){ bv = ar[k]; bj = (k/n)|0; bI = k % n; }
  const at = (j, i) => ar[((j+n)%n)*n + ((i+n)%n)];
  const sub = (v0, vm, vp) => { const d = vm - 2*v0 + vp; return d === 0 ? 0 : 0.5*(vm - vp)/d; };
  let dx = bI + sub(bv, at(bj, bI-1), at(bj, bI+1)), dy = bj + sub(bv, at(bj-1, bI), at(bj+1, bI));
  if (dx > n/2) dx -= n; if (dy > n/2) dy -= n;
  return [dx, -dy];
}

// --- defocus from image shift under ±beam tilt (nm, sample relative to the objective focal plane)
async function measureDefocus(tilt){
  const b0 = {x: S.btilt.x, y: S.btilt.y};
  S.btilt = {x: b0.x + tilt, y: b0.y}; const ip = await grab();
  S.btilt = {x: b0.x - tilt, y: b0.y}; const im = await grab();
  S.btilt = b0;
  return -imageShift(im, ip)[0]*pxNm()/(2*tilt*1e-3);
}
async function beamTiltFocus(useZ, target, iters=6){
  let tilt = 0.25, df = 0;
  for (let i=0;i<iters;i++){
    df = await measureDefocus(tilt);
    const err = df - target;
    if (useZ) S.stage.z -= err/1000; else S.dfc -= err;
    if (Math.abs(err) < Math.max(10, 2*pxNm())) break;
    tilt = clamp(20*pxNm()/(2*Math.max(Math.abs(err)*0.3, 1)*1e-3), 0.25, 3);
  }
  return df;
}

// --- beam-tilt offset from the rotation centre (mrad), from image shift under a focus wobble
async function measureTau(){
  const f0 = S.dfc, wob = clamp(2500*pxNm(), 150, 8000);
  S.dfc = f0 + wob; const ip = await grab();
  S.dfc = f0 - wob; const im = await grab();
  S.dfc = f0;
  const [dx, dy] = imageShift(im, ip), px = pxNm();
  return [-dx*px/(2*wob*1e-3), -dy*px/(2*wob*1e-3)];
}

// --- objective astigmatism from the Thon rings: defocus per direction, fitted with Δf0 + a·cos2θ + b·sin2θ
const CTF_D = (() => { const d = []; for (let v=-3000; v<600; v+=2) d.push(v); return d; })();
let ctfModelCache = null;
function ctfModels(kc, lam){
  const key = lam + "|" + kc[0].toFixed(6) + "|" + kc[kc.length-1].toFixed(6);
  if (ctfModelCache && ctfModelCache.key === key) return ctfModelCache.m;
  const nb = kc.length, m = new Float32Array(CTF_D.length*nb);
  for (let c=0;c<CTF_D.length;c++){
    let mean = 0, sq = 0;
    for (let r=0;r<nb;r++){ const k2 = kc[r]*kc[r]; const x = Math.PI*lam*CTF_D[c]*k2 + 0.5*Math.PI*CS*lam*lam*lam*k2*k2; const v = Math.sin(x)**2; m[c*nb+r] = v; mean += v; }
    mean /= nb;
    for (let r=0;r<nb;r++){ m[c*nb+r] -= mean; sq += m[c*nb+r]**2; }
    const sd = Math.sqrt(sq/nb) + 1e-9;
    for (let r=0;r<nb;r++) m[c*nb+r] /= sd;
  }
  ctfModelCache = {key, m};
  return m;
}
async function measureAstig(frames=4){
  const n = N, P = new Float64Array(n*n), re = new Float64Array(n*n), im = new Float64Array(n*n);
  for (let f=0; f<frames; f++){
    const a = await grab();
    let mean = 0; for (let q=0;q<n*n;q++) mean += a[q]; mean /= n*n;
    for (let j=0;j<n;j++) for (let i=0;i<n;i++){ const q = j*n+i; re[q] = (a[q]-mean)*HANN256[i]*HANN256[j]; im[q] = 0; }
    fft2(re, im, n, false);
    for (let j=0;j<n;j++) for (let i=0;i<n;i++){ const q = j*n+i, sj = (j + n/2) % n, si = (i + n/2) % n; P[sj*n+si] += re[q]*re[q] + im[q]*im[q]; }
  }
  const px = pxNm(), lam = LAMBDA[S.ht] || LAMBDA[200], kmax = 0.5/px, sectors = 24, NB = 90;
  const kb = []; for (let r=0;r<NB;r++) kb.push(kmax*(0.12 + 0.5*r/(NB-1)));
  const nb = NB - 1, kc = []; for (let r=0;r<nb;r++) kc.push(0.5*(kb[r] + kb[r+1]));
  const prof = new Float64Array(sectors*nb), cnt = new Float64Array(sectors*nb), c = n/2, dk = 1/(n*px);
  for (let j=0;j<n;j++) for (let i=0;i<n;i++){
    const kx = (i - c)*dk, ky = -(j - c)*dk, k = Math.hypot(kx, ky);
    if (k < kb[0] || k >= kb[NB-1]) continue;
    let r = 0; while (r < nb-1 && k >= kb[r+1]) r++;
    let ang = Math.atan2(ky, kx); if (ang < 0) ang += Math.PI; if (ang >= Math.PI) ang -= Math.PI;
    const s = Math.min(sectors-1, (ang/Math.PI*sectors)|0);
    prof[s*nb+r] += Math.log(P[j*n+i] + 1e-12); cnt[s*nb+r]++;
  }
  const model = ctfModels(kc, lam), theta = [], best = [], qual = [];
  for (let s=0;s<sectors;s++){
    const row = new Float64Array(nb);
    for (let r=0;r<nb;r++) row[r] = cnt[s*nb+r] ? prof[s*nb+r]/cnt[s*nb+r] : 0;
    const osc = new Float64Array(nb);                                  // remove the smooth background (15-bin mean)
    for (let r=0;r<nb;r++){ let acc = 0; for (let q=-7;q<=7;q++) acc += row[clamp(r+q, 0, nb-1)]; osc[r] = row[r] - acc/15; }
    let mean = 0; for (let r=0;r<nb;r++) mean += osc[r]; mean /= nb;
    let sq = 0; for (let r=0;r<nb;r++){ osc[r] -= mean; sq += osc[r]**2; }
    const sd = Math.sqrt(sq/nb) + 1e-9; for (let r=0;r<nb;r++) osc[r] /= sd;
    let bs = -1e9, bd = 0;
    for (let ci=0; ci<CTF_D.length; ci++){ let acc = 0; const o = ci*nb; for (let r=0;r<nb;r++) acc += osc[r]*model[o+r]; if (acc > bs){ bs = acc; bd = CTF_D[ci]; } }
    theta.push((s + 0.5)*Math.PI/sectors); best.push(bd); qual.push(bs/nb);
  }
  // reject weak sectors, then sectors that locked onto a different ring family (far from the median)
  const qs = [...qual].sort((p, q) => p - q), qmin = Math.max(0.2, 0.5*qs[qs.length >> 1]);
  let keep = qual.map(q => q > qmin);
  if (keep.filter(Boolean).length < 8) return null;
  const ds = best.filter((_, s) => keep[s]).sort((p, q) => p - q), dmed = ds[ds.length >> 1];
  keep = keep.map((k, s) => k && Math.abs(best[s] - dmed) < 800);
  if (keep.filter(Boolean).length < 8) return null;
  const good0 = keep.slice();
  let coef = [0, 0, 0], resid = [];
  for (let it=0; it<4; it++){
    const A = [[0,0,0],[0,0,0],[0,0,0]], y = [0,0,0];
    for (let s=0;s<sectors;s++){ if (!keep[s]) continue; const v = [1, Math.cos(2*theta[s]), Math.sin(2*theta[s])];
      for (let p=0;p<3;p++){ y[p] += v[p]*best[s]; for (let q=0;q<3;q++) A[p][q] += v[p]*v[q]; } }
    coef = solve3(A, y);
    resid = theta.map((t, s) => coef[0] + coef[1]*Math.cos(2*t) + coef[2]*Math.sin(2*t) - best[s]);
    const kr = resid.filter((_, s) => keep[s]).map(Math.abs).sort((p, q) => p - q);
    const lim = Math.max(15, 3*1.4826*kr[kr.length >> 1]);
    const nk = good0.map((g, s) => g && Math.abs(resid[s]) < lim);
    if (nk.filter(Boolean).length < 8 || nk.every((v, s) => v === keep[s])) break;
    keep = nk;
  }
  const kr2 = resid.filter((_, s) => keep[s]);
  return {defocus: coef[0], vec: [coef[1], coef[2]], rms: Math.sqrt(kr2.reduce((a, v) => a + v*v, 0)/kr2.length)};
}
function solve3(A, y){
  const M = A.map((r, i) => [...r, y[i]]);
  for (let c=0;c<3;c++){
    let p = c; for (let r=c+1;r<3;r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    [M[c], M[p]] = [M[p], M[c]];
    for (let r=0;r<3;r++){ if (r === c) continue; const f = M[r][c]/M[c][c]; for (let k=c;k<4;k++) M[r][k] -= f*M[c][k]; }
  }
  return [M[0][3]/M[0][0], M[1][3]/M[1][1], M[2][3]/M[2][2]];
}

// ---------------- steps: each returns {status: "ok"|"fixed"|"off"|"skip", text}
const ALIGN_STEPS = [
  {id: "beam", name: "Beam shift + C2 aperture", tol: "focused spot within 0.02, spread beam within 0.01 of centre",
   async run(fix){
     S.mag = 1; await findBeam();
     S.bright = XO + 1.5; const spot = hyp((await settle()).centroid);
     let spread = 0;
     if (S.c2.in){ S.bright = 88; spread = hyp((await settle()).centroid); }
     const before = `spot ${spot.toFixed(3)}` + (S.c2.in ? `, spread ${spread.toFixed(3)}` : "");
     if (spot < 0.02 && spread < 0.01) return {status: "ok", text: before};
     if (!fix) return {status: "off", text: before};
     if (S.c2.in) await autoBeamCore(); else await autoBeamShift();
     S.bright = XO + 1.5; const s2 = hyp((await settle()).centroid);
     let p2 = 0; if (S.c2.in){ S.bright = 88; p2 = hyp((await settle()).centroid); }
     return {status: "fixed", text: `${before} → spot ${s2.toFixed(3)}` + (S.c2.in ? `, spread ${p2.toFixed(3)}` : "")};
   }},
  {id: "gun", name: "Gun tilt", tol: "no probe direction raises the current by more than 0.5 %",
   async run(fix){
     S.mag = 1; S.bright = 60;
     const c0 = (await settle()).current; let gain = 0;
     for (const [ax, sg] of [["x",1],["x",-1],["y",1],["y",-1]]){
       S.gun[ax] += sg*0.03; const c = (await settle()).current; S.gun[ax] -= sg*0.03;
       gain = Math.max(gain, c/c0 - 1);
     }
     const before = `${c0.toFixed(2)} nA`;
     if (gain < 0.005) return {status: "ok", text: `${before} (at maximum)`};
     if (!fix) return {status: "off", text: `${before}, +${(gain*100).toFixed(1)} % available`};
     await autoGun();
     return {status: "fixed", text: `${before} → ${(await settle()).current.toFixed(2)} nA`};
   }},
  {id: "c2stig", name: "Condenser astigmatism", tol: "beam ellipticity below 0.03",
   async run(fix){
     S.mag = 1;
     const ap = S.c2.in ? C2S[S.c2.size] : C2NONE;
     S.bright = XO + 0.18/(1.5*ap.sf)*55;
     const e0 = (await settle()).ellipticity;
     if (e0 < 0.03) return {status: "ok", text: `ellipticity ${e0.toFixed(3)}`};
     if (!fix) return {status: "off", text: `ellipticity ${e0.toFixed(3)}`};
     await autoStig();
     S.bright = XO + 0.18/(1.5*ap.sf)*55;
     return {status: "fixed", text: `ellipticity ${e0.toFixed(3)} → ${(await settle()).ellipticity.toFixed(3)}`};
   }},
  {id: "z", name: "Eucentric focus (stage Z)", tol: "|Δf| below 100 nm at eucentric focus",
   async run(fix){
     S.mag = 2; S.bright = 95; S.dfc = 0;
     const z0 = S.stage.z;
     let df = await measureDefocus(0.25);
     if (Math.abs(df) < 3000) df = await measureDefocus(2);
     if (Math.abs(df) < 100) return {status: "ok", text: `Δf ${df.toFixed(0)} nm`};
     // a single small-tilt reading underestimates large defocus, so measure fully by converging, then decide
     await beamTiltFocus(true, 0);
     const total = (z0 - S.stage.z)*1000;
     const before = `Δf ${(total/1000).toFixed(2)} µm`;
     if (!fix){ S.stage.z = z0; return {status: "off", text: before}; }
     const after = await measureDefocus(2);
     return {status: "fixed", text: `${before} → ${after.toFixed(0)} nm`};
   }},
  {id: "rot", name: "Rotation centre", tol: "beam tilt offset below 0.8 mrad (measurement precision ≈ 0.3 mrad)",
   async run(fix){
     S.mag = 2; S.bright = 95;
     const a = await measureTau(), b = await measureTau();
     const t0 = [(a[0]+b[0])/2, (a[1]+b[1])/2], m0 = Math.hypot(...t0);
     if (m0 < 0.8) return {status: "ok", text: `${m0.toFixed(2)} mrad`};
     if (!fix) return {status: "off", text: `${m0.toFixed(2)} mrad`};
     let t = t0;
     for (let i=0;i<6;i++){
       S.btilt = {x: S.btilt.x - t[0], y: S.btilt.y - t[1]};
       t = await measureTau();
       if (Math.hypot(...t) < 0.1) break;
     }
     return {status: "fixed", text: `${m0.toFixed(2)} → ${Math.hypot(...t).toFixed(2)} mrad`};
   }},
  {id: "ostig", name: "Objective astigmatism", tol: "below 3 nm (needs amorphous film in view)",
   async run(fix){
     if (!fix && alignState.z && alignState.z.status === "off")
       return {status: "skip", text: "correct eucentric focus first; Thon rings are unreadable this far from focus"};
     S.mag = 3; S.bright = 95; S.dfc = -400;
     const m0 = await measureAstig();
     if (!m0) return {status: "skip", text: "no Thon rings here: move to amorphous film"};
     const a0 = Math.hypot(...m0.vec);
     if (a0 < 3) return {status: "ok", text: `${a0.toFixed(1)} nm`};
     if (!fix) return {status: "off", text: `${a0.toFixed(1)} nm`};
     const st0 = [S.objstig.x, S.objstig.y], step = 20, cols = [];
     for (const e of [[step, 0], [0, step]]){
       S.objstig = {x: st0[0] + e[0], y: st0[1] + e[1]};
       const mi = await measureAstig();
       cols.push(mi ? [(mi.vec[0]-m0.vec[0])/step, (mi.vec[1]-m0.vec[1])/step] : [e[0]/step, e[1]/step]);
     }
     let M = [[cols[0][0], cols[1][0]], [cols[0][1], cols[1][1]]];
     let det = M[0][0]*M[1][1] - M[0][1]*M[1][0];
     if (!(Math.abs(det) > 0.3 && Math.abs(det) < 3)){ M = [[1,0],[0,1]]; det = 1; }
     const stepFrom = v => { let dx = -( M[1][1]*v[0] - M[0][1]*v[1])/det, dy = -(-M[1][0]*v[0] + M[0][0]*v[1])/det;
                             const n = Math.hypot(dx, dy); if (n > 100){ dx *= 100/n; dy *= 100/n; } return [dx, dy]; };
     let cur = st0.map((v, i) => v + stepFrom(m0.vec)[i]);
     S.objstig = {x: cur[0], y: cur[1]};
     let m = await measureAstig();
     for (let i=0;i<2 && m && Math.hypot(...m.vec) >= 3;i++){
       const d = stepFrom(m.vec); cur = [cur[0]+d[0], cur[1]+d[1]]; S.objstig = {x: cur[0], y: cur[1]};
       m = await measureAstig();
     }
     return {status: "fixed", text: `${a0.toFixed(1)} → ${m ? Math.hypot(...m.vec).toFixed(1) : "?"} nm`};
   }},
];

const alignState = {};
function renderAlignList(){
  $("alignList").innerHTML = ALIGN_STEPS.map(s => {
    const st = alignState[s.id] || {};
    return `<li><label><input type="checkbox" id="al_${s.id}" ${st.off ? "" : "checked"}> <span class="nm">${s.name}</span></label>
      <span class="pill ${st.status || ""}">${{ok: "OK", fixed: "Fixed", off: "Out", skip: "Skipped", run: "…", err: "Error"}[st.status] || ""}</span>
      <span class="tx">${st.text || s.tol}</span></li>`;
  }).join("");
  ALIGN_STEPS.forEach(s => { $("al_" + s.id).onchange = e => { (alignState[s.id] = alignState[s.id] || {}).off = !e.target.checked; }; });
}
function remoteAlign(fix){
  if (remoteAligning || busy || !linkSend) return;
  remoteAligning = true;
  ["alignBtn", "checkBtn"].forEach(id => $(id).disabled = true); $("stopBtn2").disabled = false;
  const steps = ALIGN_STEPS.filter(s => !(alignState[s.id] && alignState[s.id].off)).map(s => s.id);
  steps.forEach(id => { const st = alignState[id] = alignState[id] || {}; st.status = ""; st.text = "waiting…"; });
  renderAlignList();
  linkSend({type: "autoalign", fix, steps});
}
async function autoAlign(fix){
  if (alignEngine === "as" && linkUp) return remoteAlign(fix);
  if (busy) return;
  if (!S.ht || !S.beam || !S.valves || !S.spec){ log("Auto align: load the specimen, switch on HT, open the valves and switch the beam on first"); return; }
  busy = true; abortAlign = false;
  const btns = ["alignBtn", "checkBtn"].map($); btns.forEach(b => b.disabled = true); $("stopBtn2").disabled = false;
  const saved = {mag: S.mag, bright: S.bright, mode: S.mode, dfc: S.dfc, wob: S.wob, fft: S.fft, display: S.display,
                 stop: S.stop, x: S.stage.x, y: S.stage.y};
  S.mode = "img"; S.wob = "off"; S.fft = false; S.stop = false; S.display = "camera";
  log(fix ? "Auto align: start" : "Check alignment: start");
  try {
    for (const s of ALIGN_STEPS){
      const st = alignState[s.id] = alignState[s.id] || {};
      if (st.off){ continue; }
      st.status = "run"; st.text = "measuring…"; renderAlignList(); sync();
      try {
        const r = await s.run(fix);
        if (!fix && r.status === "off" && ALIGN_STEPS.some(o => o === s ? false : (ALIGN_STEPS.indexOf(o) < ALIGN_STEPS.indexOf(s) && alignState[o.id] && alignState[o.id].status === "off")))
          r.text += " (approximate: earlier steps are out of tolerance)";
        Object.assign(st, r);
      } catch(e){
        if (abortAlign) { st.status = "err"; st.text = "stopped"; renderAlignList(); throw e; }
        st.status = "err"; st.text = e.message;
      }
      log(`  ${s.name}: ${st.status} · ${st.text}`);
      renderAlignList();
    }
    log(fix ? "Auto align: done" : "Check alignment: done");
  } catch(e){ log("Auto align: " + e.message); }
  finally {
    Object.assign(S, {mag: saved.mag, bright: saved.bright, mode: saved.mode, dfc: saved.dfc, wob: saved.wob, fft: saved.fft,
                      display: saved.display, stop: saved.stop});
    S.stage.x = saved.x; S.stage.y = saved.y;
    busy = false; abortAlign = false;
    btns.forEach(b => b.disabled = false); $("stopBtn2").disabled = true;
    sync(); renderAlignList();
  }
}
// Small random drift of the hidden misalignments on top of the current state (controls are not touched)
function simulateDrift(){
  const r = Math.random, d = (a) => (r() - 0.5)*2*a;
  H.bs.x += d(0.15); H.bs.y += d(0.15);
  H.c2.x += d(0.06); H.c2.y += d(0.06);
  H.cs.x += d(0.12); H.cs.y += d(0.12);
  H.gun.x += d(0.12); H.gun.y += d(0.12);
  H.z0 += d(3);
  H.tau.x += d(1.2); H.tau.y += d(1.2);
  H.os.x += d(10); H.os.y += d(10);
  optCache.clear(); dirty = true;
  ALIGN_STEPS.forEach(s => { const st = alignState[s.id]; if (st){ st.status = ""; st.text = ""; } });
  renderAlignList();
  log("Drift applied to the column; controls unchanged. Run Check or Auto align.");
}
renderAlignList();
$("alignBtn").onclick = () => autoAlign(true);
$("checkBtn").onclick = () => autoAlign(false);
$("stopBtn2").onclick = () => { if (remoteAligning && linkSend) linkSend({type: "stop"}); else abortAlign = true; };
$("engPage").onclick = () => setEngine("page");
$("engAS").onclick = () => setEngine("as");
$("driftBtn").onclick = simulateDrift;


// ---------------- AutoScript bridge ----------------
// When this page is opened as a local file, it connects to the AutoScript twin server
// (python -m tem_twin_autoscript) and carries out the commands it forwards.
function b64f32(f32){
  const u8 = new Uint8Array(f32.buffer, f32.byteOffset, f32.byteLength);
  let s = "";
  for (let i=0; i<u8.length; i+=0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i+0x8000));
  return btoa(s);
}
async function bridgeCommand(cmd, a){
  switch (cmd){
    case "state": {
      await frame();
      const m = model();
      return {S: TEM.get(), current: (S.ht && S.beam && S.valves) ? screenCurrent : 0, illum: m.illum, observe: observe()};
    }
    case "set": TEM.set(a.patch || {}); await frame(); return TEM.get();
    case "acquire": {
      const prev = S.display;
      if (prev === "screen"){ S.display = "camera"; sync(); }
      await frame(); await frame();
      const data = Float32Array.from(raw);
      if (!remoteAligning) addToGallery("AutoScript · ");
      if (prev === "screen"){ S.display = prev; sync(); }
      const m = model();
      return {w: N, h: N, data: b64f32(data), S: TEM.get(), current: (S.ht && S.beam && S.valves) ? screenCurrent : 0, illum: m.illum};
    }
    case "auto": {
      if (busy) throw new Error("another alignment routine is running");
      busy = true;
      try {
        const name = a.name;
        log(`AutoScript ${name}: start`);
        let offset = 0;
        if (name === "beamshift") offset = await autoBeamShift();
        else if (name === "beam"){ await autoBeam(); const m0 = S.mag, b0 = S.bright; S.mag = 1; S.bright = 88; offset = hyp((await settle()).centroid); S.mag = m0; S.bright = b0; sync(); }
        else if (name === "gun") await autoGun();
        else if (name === "c2stig") await autoStig();
        else throw new Error("unknown routine " + name);
        log(`AutoScript ${name}: done`);
        return {ok: offset < 0.02, offset, log: logEl.textContent.split("\n").slice(0, 8).join("\n")};
      } finally { busy = false; sync(); }
    }
    case "metrics": return metrics();
    case "randomize": return TEM.randomize(a.seed);
    default: throw new Error("unknown command " + cmd);
  }
}
let linkSend = null, linkUp = false, remoteAligning = false, alignEngine = "page";
function setEngine(e){
  alignEngine = (e === "as" && linkUp) ? "as" : "page";
  press($("engPage"), alignEngine === "page"); press($("engAS"), alignEngine === "as");
}
function onLinkEvent(msg){
  if (msg.type === "progress"){
    const st = alignState[msg.step] = alignState[msg.step] || {};
    st.status = msg.status; st.text = msg.text; renderAlignList();
  } else if (msg.type === "log"){ log(msg.text); }
  else if (msg.type === "done"){
    remoteAligning = false;
    ["alignBtn", "checkBtn"].forEach(id => $(id).disabled = false); $("stopBtn2").disabled = true;
    sync();
  }
}
// ---------------- public API ----------------
const TEM = window.TEM = {
  detectorFrame: () => {
    render(performance.now());
    const scale = S.mode === "img" ? 2 * MAGS[S.mag].R * 1e-9 / N : 0.080 / N;
    const units = S.mode === "img" ? "m" : "rad";
    return {w:N, h:N, dtype:"<f4", data:b64f32(raw), timestamp:new Date().toISOString(),
      spatial_calibrations:[0,1].map(() => ({offset:-(N-1)/2*scale, scale, units})),
      intensity_calibration:{offset:0, scale:1, units:"a.u."},
      state:TEM.get(), simulated:true};
  },
  restore: state => {
    TEM.cloudApply({S: state.S, H: state.H, seed: state.seed});
    Object.assign(alignState, state.alignState || {});
    acquired.splice(0, acquired.length, ...(state.acquired || []).slice(0, 8));
    $("gallery").innerHTML = acquired.map(a => `<figure><img src="${a.url}" alt="${a.cap}"><figcaption>${a.cap}</figcaption></figure>`).join("");
    logEl.textContent = state.log || "";
    if (state.busy) log("Previous operation was interrupted; verify state before resuming.");
    busy = remoteAligning = false;
    renderAlignList(); fillApSize(); sync();
  },
  cloudSnapshot: () => JSON.parse(JSON.stringify({S,H,seed,alignState,acquired,engine:alignEngine,log:logEl.textContent,busy:busy||remoteAligning})),
  cloudApply: patch => {
    const merge = (target, changes) => {
      for (const [key, value] of Object.entries(changes)){
        if (!Object.hasOwn(target,key)) throw new Error('Unknown state field');
        if (target[key] && typeof target[key]==='object'){
          if (!value || typeof value!=='object' || Array.isArray(value)) throw new Error('Invalid state');
          merge(target[key],value);
        } else {
          if (typeof value!==typeof target[key] || (typeof value==='number'&&!Number.isFinite(value))) throw new Error('Invalid state');
          target[key]=value;
        }
      }
    };
    if (patch.S) merge(S,patch.S);
    if (patch.H) merge(H,patch.H);
    if (patch.seed!==undefined){ if (!Number.isInteger(patch.seed)) throw new Error('Invalid seed'); seed=patch.seed; }
    if (patch.alignment){
      for(const [id,off] of Object.entries(patch.alignment)){
        if(!ALIGN_STEPS.some(s=>s.id===id)||typeof off!=='boolean')throw new Error('Invalid alignment selection');
        (alignState[id]=alignState[id]||{}).off=off;
      }renderAlignList();
    }
    if (patch.H || patch.seed!==undefined){ specCache.clear();optCache.clear();waveCache.clear(); }
    sync();
  },
  get: () => JSON.parse(JSON.stringify(S)),
  set: patch => { for (const [k,v] of Object.entries(patch)){ if (v && typeof v === "object" && S[k] && typeof S[k] === "object") Object.assign(S[k], v); else S[k] = v; } sync(); },
  nudge: (k, dx, dy=0) => nudge(k, dx, dy),
  observe: () => observe(),
  acquire: () => ({w:N, h:N, data: Float32Array.from(raw)}),
  metrics, randomize: s => { const r = randomize(s); sync(); return r; },
  frame, model: () => model(),
  region: (x = S.stage.x, y = S.stage.y) => { if (!S.spec) return 'no specimen'; world(x, y, 0.05); return _cls; },
};

randomize(20260925);
resetControls();
buildSteps(); fillApSize(); sync(); refreshSteps();
requestAnimationFrame(loop);

window.TEM.command = bridgeCommand;
window.TEM.event = onLinkEvent;
linkUp = true; linkSend = window.backendEvent; $("engAS").disabled = false; setEngine("as");
})();
