import fs from 'node:fs';
import readline from 'node:readline';
import { JSDOM, VirtualConsole } from 'jsdom';
import { createCanvas } from '@napi-rs/canvas';

const send = value => process.stdout.write(JSON.stringify(value) + '\n');
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', error => { throw error; });
const dom = new JSDOM(fs.readFileSync(new URL('template.html', import.meta.url), 'utf8'), {
  runScripts: 'outside-only', virtualConsole,
});
const { window } = dom;
const { document } = window;
const canvases = new WeakMap();
function canvasFor(element) {
  let canvas = canvases.get(element);
  if (!canvas) {
    canvas = createCanvas(element.width || 300, element.height || 150);
    canvases.set(element, canvas);
  }
  if (canvas.width !== element.width) canvas.width = element.width;
  if (canvas.height !== element.height) canvas.height = element.height;
  return canvas;
}
window.HTMLCanvasElement.prototype.getContext = function (type) {
  if (type !== '2d') throw new Error('Only 2D canvas is supported');
  const context = canvasFor(this).getContext('2d');
  return new Proxy(context, {
    get(target, key) {
      if (key === 'drawImage') return (image, ...args) => target.drawImage(
        image instanceof window.HTMLCanvasElement ? canvasFor(image) : image, ...args);
      const value = target[key];
      return typeof value === 'function' ? value.bind(target) : value;
    },
    set(target, key, value) { target[key] = value; return true; },
  });
};
window.HTMLCanvasElement.prototype.toDataURL = function (type = 'image/png', quality) {
  return canvasFor(this).toDataURL(type, quality);
};
window.HTMLElement.prototype.setPointerCapture = () => {};
window.requestAnimationFrame = fn => window.setTimeout(() => fn(performance.now()), 50);
window.cancelAnimationFrame = id => window.clearTimeout(id);
window.backendEvent = value => send({ event: value });
// Run trusted bundled physics in Node's native realm, not through jsdom's slow global proxy.
const initialize = new Function('window', 'document', 'requestAnimationFrame',
  fs.readFileSync(new URL('engine.js', import.meta.url), 'utf8'));
initialize(window, document, window.requestAnimationFrame);

let sequence = 0;
function identify() {
  for (const element of document.body.querySelectorAll('*')) {
    if (!element.dataset.twinNode) element.dataset.twinNode = String(++sequence);
  }
}
function snapshot() {
  identify();
  const controls = {};
  for (const element of document.querySelectorAll('input,select')) {
    controls[element.dataset.twinNode] = { value: element.value, checked: element.checked };
  }
  const images = {};
  for (const element of document.querySelectorAll('canvas')) {
    if (!element.hidden) images[element.dataset.twinNode] = element.toDataURL('image/jpeg', 0.9);
  }
  return { html: document.body.innerHTML, controls, images, state: window.TEM.get() };
}
function control(value) {
  if (!value || !/^\d+$/.test(value.node || '')) throw new Error('Invalid control');
  const element = document.querySelector(`[data-twin-node="${value.node}"]`);
  if (!element || element.disabled || !element.matches('button,input,select,#steps li')) {
    throw new Error('Unknown or disabled control');
  }
  const event = type => element.dispatchEvent(new window.MouseEvent(type, { bubbles: true, cancelable: true }));
  if (value.type === 'click' && element.matches('button,#steps li')) {
    // Each press is bounded; disconnects cannot leave a held timer running.
    event('pointerdown'); event('pointerup'); element.click();
  } else if (['input', 'change'].includes(value.type) && element.matches('input,select')) {
    if (element.tagName === 'SELECT' && ![...element.options].some(option => option.value === String(value.value))) {
      throw new Error('Invalid option');
    }
    if (element.type === 'range' || element.type === 'number') {
      const number = Number(value.value);
      if (!Number.isFinite(number) || (element.min !== '' && number < Number(element.min)) ||
          (element.max !== '' && number > Number(element.max))) throw new Error('Out of bounds');
    }
    if (element.type === 'checkbox') {
      if (typeof value.checked !== 'boolean') throw new Error('Invalid checkbox');
      element.checked = value.checked;
    } else element.value = String(value.value);
    element.dispatchEvent(new window.Event(value.type, { bubbles: true }));
  } else if (value.type === 'drag' && element.matches('button.knob')) {
    if (![value.dx, value.dy].every(n => Number.isFinite(n) && Math.abs(n) <= 100)) throw new Error('Invalid drag');
    element.dispatchEvent(new window.MouseEvent('pointerdown', { clientX: 0, clientY: 0 }));
    element.dispatchEvent(new window.MouseEvent('pointermove', { clientX: value.dx, clientY: value.dy }));
    event('pointerup');
  } else throw new Error('Unsupported input');
  return true;
}

function nativeSnapshot() {
  identify();
  const controls = [];
  for (const element of document.querySelectorAll('button,input,select')) {
    if (element.matches('.blank,.knob')) continue;
    const pad = element.closest('.padwrap');
    const section = element.closest('.sec,section');
    const group = section?.querySelector('h2')?.firstChild?.textContent?.trim() || 'General';
    const direction = element.getAttribute('aria-label');
    const label = (pad && direction ? (pad.querySelector('.name')?.textContent || pad.id) + ' ' + direction :
      element.getAttribute('aria-label') || document.querySelector(`label[for="${element.id}"]`)?.textContent ||
      element.closest('.cell')?.querySelector('label')?.textContent || element.textContent || element.id).trim();
    controls.push({node:element.dataset.twinNode, id:element.id, group, label,
      kind:element.tagName === 'SELECT' ? 'select' : element.tagName === 'BUTTON' ? 'button' : element.type,
      disabled:element.disabled, pressed:element.getAttribute('aria-pressed') === 'true',
      checked:element.checked, value:element.value, min:element.min, max:element.max, step:element.step,
      options:element.tagName === 'SELECT' ? [...element.options].map(o=>({value:o.value,label:o.textContent})) : undefined});
  }
  const readouts = {};
  for (const id of ['brightVal','bsVal','apVal','stigVal','dirVal','stageVal','zVal','focusVal','cur','status','autolog']) {
    readouts[id] = document.getElementById(id)?.textContent || '';
  }
  return {frame:window.TEM.detectorFrame(), controls, readouts};
}

// Private stdin/stdout RPC. Browsers have no engine connection or execution endpoint.
let queue = Promise.resolve();
readline.createInterface({ input: process.stdin }).on('line', line => {
  const execute = async () => {
    let message;
    try {
      message = JSON.parse(line);
      let result;
      if (message.cmd === 'snapshot') result = snapshot();
      else if (message.cmd === 'native_snapshot') result = nativeSnapshot();
      else if (message.cmd === 'checkpoint') result = window.TEM.cloudSnapshot();
      else if (message.cmd === 'restore') { window.TEM.restore(message.args.state); result = true; }
      else if (message.cmd === 'control') result = control(message.args.value);
      else if (message.cmd === 'event') result = window.TEM.event(message.args.value) ?? null;
      else if (message.cmd === 'template') result = document.head.innerHTML;
      else result = await window.TEM.command(message.cmd, message.args || {});
      send({ id: message.id, ok: true, result });
    } catch (error) { send({ id: message?.id, ok: false, error: String(error.message || error) }); }
  };
  // Observation/progress must not wait behind an entire bounded alignment command.
  let cmd;
  try { cmd = JSON.parse(line).cmd; } catch { /* execute reports malformed RPC */ }
  if (['snapshot', 'template', 'checkpoint', 'event'].includes(cmd)) void execute();
  else queue = queue.then(execute);
}).on('close', () => { dom.window.close(); process.exit(0); });
process.on('SIGTERM', () => { dom.window.close(); process.exit(0); });
send({ ready: true, engine: 'node' });
