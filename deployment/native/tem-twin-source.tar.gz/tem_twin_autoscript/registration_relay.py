"""Authenticated outbound device connections; the Tango-facing relay is loopback only."""
import asyncio
import hashlib
import re
import secrets
from aiohttp import web, WSMsgType

class RelayPeer:
    def __init__(self, ws, credential):
        self.ws = ws; self.credential = credential; self.pending = {}

    async def request(self, method, path, body=None):
        identifier = secrets.token_hex(16)
        future = asyncio.get_running_loop().create_future()
        self.pending[identifier] = future
        try:
            await self.ws.send_json(dict(id=identifier, method=method, path=path, body=body))
            return await asyncio.wait_for(future, 310)
        finally:
            self.pending.pop(identifier, None)

    def disconnect(self):
        for future in list(self.pending.values()):
            if not future.done(): future.set_exception(ConnectionError('Device disconnected; operation outcome is unknown. Do not automatically retry.'))

class RelayHub:
    def __init__(self, service):
        self.service = service; self.peers = {}

    def authorized(self, device, credential, code=''):
        if not isinstance(device, str) or not re.fullmatch(r'[a-z0-9_\-]+/[a-z0-9_\-]+/[a-z0-9_\-]+', device) or len(credential) < 32:
            return False
        owner = self.service.state['owners'].get(device)
        if self.service.state.get('metadata', {}).get(device, {}).get('status') == 'revoked':
            return False
        if owner:
            return secrets.compare_digest(owner, hashlib.sha256(credential.encode()).hexdigest())
        application = self.service.state.get('requests', {}).get(device, {})
        if application.get('status') in ('pending', 'approved') and secrets.compare_digest(application.get('credential_hash', ''), hashlib.sha256(credential.encode()).hexdigest()):
            return True
        hashed = hashlib.sha256(code.encode()).hexdigest()
        return not self.service.config.get('approval_required') and self.service.config['enrollment_codes'].get(hashed) == device and hashed not in self.service.state['used_codes']

    def connected(self, device, credential):
        peer = self.peers.get(device)
        return bool(peer and not peer.ws.closed and secrets.compare_digest(peer.credential, credential))

    async def connect(self, request):
        device = request.query.get('device', '')
        auth = request.headers.get('Authorization', '')
        credential = auth[7:] if auth.startswith('Bearer ') else ''
        if not self.authorized(device, credential, request.headers.get('X-Enrollment-Code', '')):
            raise web.HTTPUnauthorized()
        previous = self.peers.get(device)
        if previous and not previous.ws.closed: raise web.HTTPConflict(text='Device already connected')
        ws = web.WebSocketResponse(heartbeat=20, max_msg_size=16*1024*1024)
        await ws.prepare(request)
        peer = RelayPeer(ws, credential); self.peers[device] = peer
        try:
            await ws.send_json({'type':'connected','device':device})
            async for message in ws:
                if message.type == WSMsgType.TEXT:
                    try:
                        value = message.json()
                        future = peer.pending.get(value.get('id'))
                        if future is not None and not future.done():
                            status = value.get('status')
                            if not isinstance(status, int) or not 200 <= status <= 599: raise ValueError()
                            future.set_result((status, value.get('data')))
                    except (ValueError, TypeError, AttributeError):
                        await ws.close(code=1008, message=b'Invalid relay response')
        finally:
            peer.disconnect()
            if self.peers.get(device) is peer: self.peers.pop(device, None)
        return ws

    async def status(self, request):
        auth = request.headers.get('Authorization','')
        credential = auth[7:] if auth.startswith('Bearer ') else ''
        if len(credential) < 32: raise web.HTTPUnauthorized()
        try: device = (await request.json()).get('device','')
        except (ValueError, AttributeError): raise web.HTTPBadRequest()
        return web.json_response({'connected': self.connected(device, credential)})

    async def forward(self, request):
        device = request.match_info['device'].replace('~','/')
        auth = request.headers.get('Authorization', '')
        credential = auth[7:] if auth.startswith('Bearer ') else ''
        peer = self.peers.get(device)
        if not self.connected(device, credential): raise web.HTTPServiceUnavailable(text='Device connection unavailable')
        tail = request.match_info['tail']
        if tail == 'describe' and request.method == 'GET':
            body = None
        elif re.fullmatch(r'invoke/[A-Za-z_][A-Za-z0-9_]*', tail) and request.method == 'POST':
            if device not in self.service.state['nodes']: raise web.HTTPForbidden(text='Device is not registered')
            body = await request.json()
            if not isinstance(body, dict): raise web.HTTPBadRequest(text='Expected an argument object')
        else: raise web.HTTPNotFound()
        try:
            status, data = await peer.request(request.method, '/api/v1/'+tail, body)
            return web.json_response(data, status=status)
        except (ConnectionError, TimeoutError):
            return web.json_response({'error':'Device disconnected or timed out; execution outcome is unknown','retry':False},status=503)

    def internal_app(self):
        app = web.Application(client_max_size=16*1024*1024)
        app.router.add_route('*','/relay/{device}/api/v1/{tail:.*}',self.forward)
        return app

    async def close(self):
        await asyncio.gather(*(peer.ws.close(code=1001,message=b'Registration service restarting') for peer in list(self.peers.values())))
