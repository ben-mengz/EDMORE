"""Server-owned TEM simulation, AutoScript, MCP and a display-only web client."""

import argparse
import asyncio
import contextlib
import json
import logging
import os
import signal
import sys
import uuid
from pathlib import Path

from aiohttp import WSMsgType, web

from .orc_server import TwinApiError
from .runtime import TwinRuntime

ROOT = Path(__file__).parent


class SharedTwin:
    def __init__(self, link, state_file=None):
        self.link = link
        self.viewers = set()
        self.snapshot = None
        self.ready = False
        self.revision = 0
        self.head = ""
        self.instance = uuid.uuid4().hex
        self.state_file = Path(state_file) if state_file else None
        self.saved = None

    def checkpoint(self):
        if not self.state_file or not self.link.connected:
            return
        value = json.dumps(self.link.call("checkpoint"), allow_nan=False)
        if value == self.saved:
            return
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.state_file.with_suffix(".tmp")
        with temporary.open("w") as output:
            output.write(value)
            output.flush()
            os.fsync(output.fileno())
        temporary.replace(self.state_file)
        self.saved = value

    async def run(self):
        self.head = await asyncio.to_thread(self.link.call, "template")
        try:
            while self.link.connected:
                self.snapshot = await asyncio.to_thread(self.link.call, "snapshot")
                self.revision += 1
                self.ready = True
                if self.revision % 8 == 0:
                    await asyncio.to_thread(self.checkpoint)
                await self.broadcast()
                await asyncio.sleep(0.25)
            raise RuntimeError("Backend engine stopped")
        finally:
            self.ready = False

    def message(self):
        return {"type": "state", "instance": self.instance, "revision": self.revision, "snapshot": self.snapshot}

    async def broadcast(self):
        viewers = list(self.viewers)
        message = self.message()
        # A cancelled/failed socket drain belongs to that viewer, never to the simulation task.
        results = await asyncio.gather(
            *(asyncio.wait_for(viewer.send_json(message), 2) for viewer in viewers),
            return_exceptions=True,
        )
        failed = [viewer for viewer, result in zip(viewers, results) if isinstance(result, BaseException)]
        self.viewers.difference_update(failed)
        await asyncio.gather(*(asyncio.wait_for(viewer.close(), 1) for viewer in failed), return_exceptions=True)

    async def control(self, value):
        if not isinstance(value, dict) or value.get("type") not in ("click", "input", "change", "drag"):
            raise ValueError("Unsupported input")
        if value.get("instance") != self.instance:
            raise ValueError("Stale simulation view; refresh before operating")
        await asyncio.to_thread(self.link.call, "control", value=value)


def create_app(twin):
    async def index(request):
        if not twin.ready:
            raise web.HTTPServiceUnavailable(text="Digital Twin is starting. Reload shortly.")
        page = ('<!doctype html><html><head>' + twin.head +
                '<script defer src="/morphdom.min.js"></script><script defer src="/viewer.js"></script>' +
                '</head><body><main id="twin-view"></main></body></html>')
        return web.Response(text=page, content_type="text/html", headers={"Cache-Control": "no-store"})

    async def asset(request):
        return web.FileResponse(ROOT / "web" / request.match_info["name"], headers={"Cache-Control": "no-cache"})

    async def health(request):
        ready = twin.ready and twin.link.connected
        return web.json_response({"ready": ready, "engine": "node", "viewers": len(twin.viewers),
                                  "revision": twin.revision}, status=200 if ready else 503)

    async def stream(request):
        if request.headers.get("Origin") != f"{request.scheme}://{request.host}":
            raise web.HTTPForbidden()
        ws = web.WebSocketResponse(max_msg_size=16384, heartbeat=20, compress=True)
        await ws.prepare(request)
        twin.viewers.add(ws)
        try:
            if twin.snapshot:
                await ws.send_json(twin.message())
            async for message in ws:
                if message.type == WSMsgType.TEXT:
                    try:
                        if not twin.ready:
                            raise ValueError("Engine unavailable")
                        await twin.control(json.loads(message.data))
                        await ws.send_json({"type": "ack"})
                    except (ValueError, TypeError, KeyError, TwinApiError, TimeoutError):
                        await ws.send_json({"type": "ack", "error": "Operation rejected or engine unavailable"})
        finally:
            twin.viewers.discard(ws)
        return ws

    async def shutdown(app):
        await asyncio.gather(*(asyncio.wait_for(ws.close(code=1001, message=b"Server restarting"), 1)
                               for ws in list(twin.viewers)), return_exceptions=True)

    app = web.Application()
    app.add_routes([web.get("/", index), web.get("/health", health), web.get("/stream", stream),
                    web.get(r"/{name:viewer\.js|morphdom\.min\.js}", asset)])
    app.on_shutdown.append(shutdown)
    return app


async def serve(args):
    children, tasks = [], []
    runner = native_runner = runtime = None
    stop = asyncio.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        asyncio.get_running_loop().add_signal_handler(sig, stop.set)
    try:
        runtime = await asyncio.to_thread(TwinRuntime, port=args.autoscript_port)
        if args.state_file and Path(args.state_file).exists():
            state = json.loads(Path(args.state_file).read_text())
            await asyncio.to_thread(runtime.link.call, "restore", state=state)
        from .tango_stack import start_tango
        await start_tango(args, children)
        twin = SharedTwin(runtime.link, args.state_file)
        runner = web.AppRunner(create_app(twin))
        await runner.setup()
        await web.TCPSite(runner, args.host, args.port).start()
        from .native_api import create_native_app
        native_runner = web.AppRunner(create_native_app(twin))
        await native_runner.setup()
        await web.TCPSite(native_runner, args.host, args.native_port).start()
        print(f"Backend Twin GUI: http://{args.host}:{args.port}/", flush=True)
        tasks = [asyncio.create_task(twin.run()), asyncio.create_task(stop.wait())]
        tasks.extend(asyncio.create_task(child.wait()) for child in children)
        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for task in done:
            task.result()
        if not stop.is_set():
            raise RuntimeError("A twin service exited")
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if runner:
            await runner.cleanup()
        if native_runner:
            await native_runner.cleanup()
        # Stop the gateway and device before their database dependency.
        for child in reversed(children):
            if child.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    child.terminate()
            try:
                await asyncio.wait_for(child.wait(), 10)
            except TimeoutError:
                child.kill()
                await child.wait()
        if runtime:
            try:
                if 'twin' in locals():
                    await asyncio.to_thread(twin.checkpoint)
            finally:
                await asyncio.to_thread(runtime.close)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8768)
    parser.add_argument("--mcp-port", type=int, default=8767)
    parser.add_argument("--native-port", type=int, default=8769)
    parser.add_argument("--autoscript-port", type=int, default=7521)
    parser.add_argument("--state-file", default=os.environ.get("TEM_TWIN_STATE_FILE"))
    parser.add_argument("--tango-db-port", type=int, default=10000)
    parser.add_argument("--tango-device-port", type=int, default=10001)
    parser.add_argument("--tango-http-device-port", type=int, default=10002)
    parser.add_argument("--tango-device", default="edmore/tem/twin")
    parser.add_argument("--tango-data-dir", default=os.environ.get("TEM_TWIN_TANGO_DIR", str(Path.home() / ".dsh/edmore/tem-tango")))
    parser.add_argument("--tango-http-nodes", default=os.environ.get("TEM_TWIN_HTTP_NODES"),
                        help="Server-private JSON mapping remote Tango device names to TEM node URLs and tokens")
    parser.add_argument("--tango-extra-devices", help="Admin JSON mapping additional device names to Tango URLs")
    logging.basicConfig(level=logging.INFO)
    asyncio.run(serve(parser.parse_args()))


if __name__ == "__main__":
    main()
