"""Versioned raw-detector subscription API for native clients; shares the GUI/MCP engine."""

import asyncio
import contextlib
import json
import logging

from aiohttp import WSMsgType, web

from .orc_server import TwinApiError

logger = logging.getLogger(__name__)


class NativeStream:
    FRAME_STALE_AFTER = 3.0
    RETRY_DELAY = 1.0
    CLOSE_TIMEOUT = 1.0

    def __init__(self, twin):
        self.twin = twin
        self.viewers = set()
        self.revision = 0
        self.task = None
        self.first_viewer_at = None
        self.last_frame_at = None
        self.last_error = None

    @staticmethod
    def _now():
        return asyncio.get_running_loop().time()

    def add_viewer(self, viewer):
        if not self.viewers:
            self.first_viewer_at = self._now()
        self.viewers.add(viewer)

    def discard_viewer(self, viewer):
        self.viewers.discard(viewer)
        if not self.viewers:
            self.first_viewer_at = None

    def status(self):
        task_ready = self.task is not None and not self.task.done()
        frame_age = None if self.last_frame_at is None else self._now() - self.last_frame_at
        frame_ready = True
        if self.viewers:
            if frame_age is not None:
                frame_ready = frame_age <= self.FRAME_STALE_AFTER
            else:
                frame_ready = (self.first_viewer_at is not None and
                               self._now() - self.first_viewer_at <= self.FRAME_STALE_AFTER)
        return task_ready and frame_ready, frame_age

    async def snapshot(self):
        value = await asyncio.to_thread(self.twin.link.call, "native_snapshot", 5)
        self.revision += 1
        return {"type": "detector", "protocol": 1, "instance": self.twin.instance,
                "revision": self.revision, **value}

    async def close_viewer(self, viewer, **kwargs):
        self.discard_viewer(viewer)
        # A disconnected peer can block even close() while draining its socket.
        try:
            await asyncio.wait_for(viewer.close(drain=False, **kwargs), self.CLOSE_TIMEOUT)
        except Exception:
            logger.warning("Native detector viewer close failed or timed out", exc_info=True)

    async def run(self):
        while True:
            if self.viewers:
                try:
                    message = await self.snapshot()
                    self.last_frame_at = self._now()
                    self.last_error = None
                except Exception as exc:
                    self.last_error = f"{type(exc).__name__}: {exc}"
                    logger.exception("Native detector snapshot failed; retrying")
                    await asyncio.sleep(self.RETRY_DELAY)
                    continue
                for viewer in list(self.viewers):
                    try:
                        await asyncio.wait_for(viewer.send_json(message), 2)
                    except Exception:
                        logger.warning("Native detector viewer send failed; disconnecting viewer",
                                       exc_info=True)
                        await self.close_viewer(viewer)
            await asyncio.sleep(0.25)


NATIVE_STREAM_KEY = web.AppKey("native_stream", NativeStream)


def create_native_app(twin):
    stream = NativeStream(twin)

    def check_origin(request):
        origin = request.headers.get("Origin")
        if origin and origin != f"{request.scheme}://{request.host}":
            raise web.HTTPForbidden()

    async def health(request):
        stream_ready, frame_age = stream.status()
        ready = twin.ready and twin.link.connected and stream_ready
        return web.json_response({"ready": ready, "stream_ready": stream_ready, "protocol": 1,
                                  "instance": twin.instance, "detector": "tem_twin_detector",
                                  "viewers": len(stream.viewers),
                                  "last_frame_age_s": None if frame_age is None else round(frame_age, 3),
                                  "last_error": stream.last_error},
                                 status=200 if ready else 503)

    async def subscribe(request):
        check_origin(request)
        if not twin.ready:
            raise web.HTTPServiceUnavailable()
        ws = web.WebSocketResponse(max_msg_size=16384, heartbeat=20)
        await ws.prepare(request)
        stream.add_viewer(ws)
        try:
            async for message in ws:
                if message.type == WSMsgType.TEXT:
                    value = {}
                    try:
                        value = json.loads(message.data)
                        if not isinstance(value, dict):
                            raise ValueError("Invalid input")
                        await twin.control(value)
                        await ws.send_json({"type": "ack", "request_id": value.get("request_id")})
                    except (ValueError, TypeError, KeyError, TwinApiError, TimeoutError):
                        await ws.send_json({"type": "ack", "request_id": value.get("request_id") if isinstance(value, dict) else None,
                                            "error": "Input rejected; refresh state and check connection"})
        finally:
            stream.discard_viewer(ws)
        return ws

    async def lifecycle(app):
        stream.task = asyncio.create_task(stream.run(), name="native-detector-stream")
        try:
            yield
        finally:
            stream.task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await stream.task

    async def shutdown(app):
        await asyncio.gather(*(stream.close_viewer(
            ws, code=1001, message=b"Twin server restarting") for ws in list(stream.viewers)))

    app = web.Application()
    app[NATIVE_STREAM_KEY] = stream
    app.add_routes([web.get("/health", health), web.get("/stream", subscribe)])
    app.cleanup_ctx.append(lifecycle)
    app.on_shutdown.append(shutdown)
    return app
