/* Display and input transport only. No microscope state, physics or alignment engine. */
(() => {
  const view = document.getElementById('twin-view');
  let socket, revision = 0, instance = null, connected = false, lastPointer = null;
  let holdDelay, holdInterval, repeated = false;
  const release = () => { clearTimeout(holdDelay); clearInterval(holdInterval); lastPointer = null; };
  const send = message => {
    if (connected && socket.readyState === WebSocket.OPEN) {
      console.debug('Twin input', message.type, message.node);
      socket.send(JSON.stringify({ ...message, instance }));
    }
  };
  function connection(text, online) {
    const chip = document.getElementById('linkChip');
    if (chip) { chip.textContent = text; chip.className = online ? 'link on' : 'link'; }
    view.inert = !online;
  }
  function render(message) {
    revision = message.revision;
    instance = message.instance;
    const snapshot = message.snapshot;
    const target = document.createElement('main');
    target.id = 'twin-view';
    target.innerHTML = snapshot.html;
    for (const [node, value] of Object.entries(snapshot.controls)) {
      const element = target.querySelector(`[data-twin-node="${node}"]`);
      if (!element) continue;
      element.value = value.value;
      if (typeof value.checked === 'boolean') element.checked = value.checked;
    }
    morphdom(view, target, {
      getNodeKey: node => node.dataset?.twinNode || node.id,
      onBeforeElUpdated: (from, to) => {
        if (from.tagName === 'DETAILS') to.open = from.open;
        return !from.isEqualNode(to) || from.matches('input,select');
      },
    });
    // DOM equality ignores live form properties, so synchronize these even on unchanged subtrees.
    for (const [node, value] of Object.entries(snapshot.controls)) {
      const element = view.querySelector(`[data-twin-node="${node}"]`);
      if (!element) continue;
      element.value = value.value;
      if (typeof value.checked === 'boolean') element.checked = value.checked;
    }
    for (const [node, source] of Object.entries(snapshot.images)) {
      const canvas = view.querySelector(`canvas[data-twin-node="${node}"]`);
      if (!canvas) continue;
      const version = revision, image = new Image();
      image.onload = () => { if (version === revision) canvas.getContext('2d').drawImage(image, 0, 0); };
      image.src = source;
    }
    connection('Backend connected', true);
  }
  view.addEventListener('click', event => {
    const element = event.target.closest('button,#steps li');
    if (repeated) { repeated = false; return; }
    if (element && !element.disabled && !element.classList.contains('knob')) {
      send({ type: 'click', node: element.dataset.twinNode });
    }
  });
  for (const type of ['input', 'change']) view.addEventListener(type, event => {
    const element = event.target;
    if (element.matches('input,select')) send({ type, node: element.dataset.twinNode,
      value: element.value, checked: element.checked });
  });
  view.addEventListener('pointerdown', event => {
    repeated = false;
    const repeat = event.target.closest('.pad button:not(.knob):not(.blank),#zUp,#zDown,#fUp,#fDown');
    if (repeat) {
      holdDelay = setTimeout(() => {
        repeated = true;
        send({ type: 'click', node: repeat.dataset.twinNode });
        holdInterval = setInterval(() => send({ type: 'click', node: repeat.dataset.twinNode }), 120);
      }, 300);
    }
    const knob = event.target.closest('button.knob');
    if (!knob) return;
    knob.setPointerCapture(event.pointerId);
    lastPointer = { node: knob.dataset.twinNode, x: event.clientX, y: event.clientY };
  });
  view.addEventListener('pointermove', event => {
    if (!lastPointer) return;
    const dx = Math.max(-100, Math.min(100, event.clientX - lastPointer.x));
    const dy = Math.max(-100, Math.min(100, event.clientY - lastPointer.y));
    send({ type: 'drag', node: lastPointer.node, dx, dy });
    lastPointer.x = event.clientX; lastPointer.y = event.clientY;
  });
  for (const type of ['pointerup', 'pointercancel']) window.addEventListener(type, release);
  window.addEventListener('blur', release);
  function connect() {
    socket = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/stream`);
    socket.onopen = () => { connected = true; };
    socket.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.type === 'state') render(message);
      else if (message.type === 'ack' && !message.error) console.debug('Twin input accepted');
      else if (message.error) {
        const log = document.getElementById('autolog');
        if (log) log.textContent = message.error + '\n' + log.textContent;
        console.error(message.error);
      }
    };
    socket.onclose = () => {
      connected = false; release(); connection('Backend disconnected', false);
      setTimeout(connect, 1500);
    };
    socket.onerror = () => socket.close();
  }
  connect();
})();
