(() => {
  const el = id => document.getElementById(id);
  const text = (id, value, fallback = '-') => { el(id).textContent = value ?? fallback; };
  const number = (value, digits = 3) => Number.isFinite(value) ? Number(value).toFixed(digits) : '-';
  const metric = (value, unit, scale = 1, digits = 3) => Number.isFinite(value) ? `${number(value * scale, digits)} ${unit}` : '-';
  let socket, requestId = 0;
  const dirty = new Set();
  const vectorSpecs = [
    ['beam_shift','Beam shift','µm',1e6], ['beam_tilt','Beam tilt','mrad',1e3],
    ['gun_shift','Gun shift','µm',1e6], ['gun_tilt','Gun tilt','logical',1],
    ['image_shift','Image shift','µm',1e6], ['image_tilt','Image tilt','mrad',1e3],
    ['condenser_stigmator','Condenser stigmator','logical',1],
    ['objective_stigmator','Objective stigmator','logical',1],
  ];

  function buildVectorControls() {
    el('vector-controls').innerHTML = vectorSpecs.map(([key,label,unit]) => `<div class="vector">
      <h3>${label}</h3><div class="form">
      <div class="field"><label for="${key}-x">X (${unit})</label><input id="${key}-x" type="number" step="0.0001"></div>
      <div class="field"><label for="${key}-y">Y (${unit})</label><input id="${key}-y" type="number" step="0.0001"></div></div>
      <div class="actions"><button data-vector="${key}">Apply ${label}</button></div></div>`).join('');
  }
  buildVectorControls();

  function setInput(id, value, digits = 4) {
    const input = el(id);
    if (!dirty.has(id) && document.activeElement !== input && Number.isFinite(value)) input.value = Number(value).toFixed(digits);
  }

  function command(name, args) {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;
    const status = el('command-status');
    status.textContent = `${name}…`;
    status.className = 'command';
    socket.send(JSON.stringify({type:'command', request_id:++requestId, command:name, arguments:args}));
  }

  function setAlignmentBusy(busy) {
    for (const button of document.querySelectorAll('#align-list button,#align-selected,#check-selected')) button.disabled = busy;
  }

  function runAlignment(phases, fix) {
    if (!phases.length) return;
    setAlignmentBusy(true);
    el('align-result').textContent = `${fix ? 'Aligning' : 'Checking'} ${phases.join(', ')}…`;
    command('run_alignment', {phases, fix});
  }

  function formatAlignment(result) {
    if (result.phase) {
      return `${result.phase}: ${result.status}\n${result.detail}\nverified: ${Boolean(result.verified)}\nworking conditions restored: ${Boolean(result.working_conditions_restored)}`;
    }
    const lines = [`${result.fix ? 'Alignment' : 'Check'} ${result.success ? 'completed' : 'needs attention'}`];
    for (const [phase, value] of Object.entries(result.phases || {})) lines.push(`${phase}: ${value.status} · ${value.detail}`);
    return lines.join('\n');
  }

  function connection(label, state) {
    const chip = el('connection');
    chip.textContent = label;
    chip.className = `chip ${state || ''}`;
  }

  function render(message) {
    const s = message.snapshot || {};
    const v = s.values || {};
    const mag = v.magnification || {};
    const stage = v.stage || {};
    const shift = v.beam_shift || {};
    const tilt = v.beam_tilt || {};
    connection(s.connected ? 'AutoScript connected' : 'Disconnected', s.connected ? 'on' : 'bad');
    text('endpoint', s.endpoint); text('system', v.system_name); text('camera', s.camera);
    text('latency', s.latency_ms == null ? '-' : `${s.latency_ms} ms`);
    text('exposure', metric(s.exposure_s, 'ms', 1000, 0));
    text('magnification', mag.label || (mag.nominal ? `${mag.nominal} x` : null));
    text('mode', v.projector_mode); text('spot', v.spot_size);
    text('intensity', number(v.intensity, 4)); text('defocus', metric(v.defocus_m, 'nm', 1e9, 1));
    text('voltage', metric(v.acceleration_voltage_v, 'kV', 1e-3, 0), 'Unavailable');
    for (const axis of ['x','y','z']) text(`stage-${axis}`, metric(stage[axis], 'µm', 1e6, 3));
    for (const axis of ['a','b']) text(`stage-${axis}`, metric(stage[axis], 'mrad', 1e3, 3));
    for (const axis of ['x','y']) {
      text(`shift-${axis}`, metric(shift[axis], 'µm', 1e6, 4));
      text(`tilt-${axis}`, metric(tilt[axis], 'mrad', 1e3, 4));
    }
    if (document.activeElement !== el('mode-control')) el('mode-control').value = v.projector_mode || 'Imaging';
    const mags = s.capabilities?.magnifications || [];
    if (el('mag-control').options.length !== mags.length) {
      el('mag-control').innerHTML = mags.map(value => `<option value="${value.nominal}">${value.label}</option>`).join('');
    }
    if (document.activeElement !== el('mag-control') && mag.nominal) el('mag-control').value = String(mag.nominal);
    setInput('spot-control', v.spot_size, 0); setInput('intensity-control', v.intensity, 4);
    setInput('defocus-control', Number.isFinite(v.defocus_m) ? v.defocus_m * 1e9 : null, 1);
    for (const axis of ['x','y','z']) setInput(`stage-control-${axis}`, Number.isFinite(stage[axis]) ? stage[axis] * 1e6 : null, 3);
    for (const axis of ['a','b']) setInput(`stage-control-${axis}`, Number.isFinite(stage[axis]) ? stage[axis] * 1e3 : null, 3);
    for (const [key,,,_scale] of vectorSpecs) {
      const value = v[key] || {};
      setInput(`${key}-x`, Number.isFinite(value.x) ? value.x * _scale : null, 5);
      setInput(`${key}-y`, Number.isFinite(value.y) ? value.y * _scale : null, 5);
    }
    const c2 = v.c2_position || {};
    setInput('c2-x', Number.isFinite(c2.x) ? c2.x * 1e6 : null, 4);
    setInput('c2-y', Number.isFinite(c2.y) ? c2.y * 1e6 : null, 4);
    if (s.frame) el('frame').src = s.frame;
    const fi = s.frame_info || {};
    text('shape', fi.shape ? fi.shape.join(' × ') : null);
    text('range', Number.isFinite(fi.min) ? `${number(fi.min,0)}–${number(fi.max,0)}` : null);
    text('mean', number(fi.mean, 1)); text('revision', message.revision);
    el('hud').innerHTML = `<b>${String(v.projector_mode || 'UNKNOWN').toUpperCase()}</b><br>${mag.label || '-'}<br>${s.camera || '-'} · ${metric(s.exposure_s, 'ms', 1000, 0)}`;
    text('stamp', new Date((s.captured_at || 0) * 1000).toLocaleTimeString());
    const errors = s.errors || [];
    el('errors').textContent = errors.length ? errors.join('\n') : 'All requested readbacks available.';
    el('errors').className = errors.length ? 'error' : 'ok';
  }

  function connect() {
    socket = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/stream`);
    socket.onopen = () => connection('Waiting for AutoScript', '');
    socket.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.type === 'state') render(message);
      else if (message.type === 'ack') {
        const status = el('command-status');
        status.textContent = message.error || `${message.result?.command || 'Command'} accepted and queued for readback.`;
        status.className = message.error ? 'command error' : 'command ok';
        if (!message.error) dirty.clear();
        if (message.result?.command === 'run_alignment' || message.error && el('align-result').textContent.includes('…')) {
          setAlignmentBusy(false);
          el('align-result').textContent = message.error || formatAlignment(message.result.alignment);
          el('align-result').className = message.error ? 'align-result error' : 'align-result';
        }
      }
    };
    socket.onclose = () => { connection('Monitor disconnected', 'bad'); setTimeout(connect, 1500); };
    socket.onerror = () => socket.close();
  }
  el('apply-optics').addEventListener('click', () => command('set_optics', {
    projector_mode: el('mode-control').value, magnification: Number(el('mag-control').value),
    spot_size: Number(el('spot-control').value), intensity: Number(el('intensity-control').value),
    defocus_nm: Number(el('defocus-control').value),
  }));
  el('blank-beam').addEventListener('click', () => command('set_beam_blank', {blanked:true}));
  el('unblank-beam').addEventListener('click', () => command('set_beam_blank', {blanked:false}));
  el('move-stage').addEventListener('click', () => command('move_stage', Object.fromEntries(
    ['x','y','z','a','b'].map(axis => [axis, Number(el(`stage-control-${axis}`).value)]))));
  el('vector-controls').addEventListener('click', event => {
    const button = event.target.closest('button[data-vector]');
    if (!button) return;
    const target = button.dataset.vector;
    command('set_vector', {target, x:Number(el(`${target}-x`).value), y:Number(el(`${target}-y`).value)});
  });
  el('c2-position').addEventListener('click', () => command('set_c2', {action:'position',x:Number(el('c2-x').value),y:Number(el('c2-y').value)}));
  el('c2-insert').addEventListener('click', () => command('set_c2', {action:'insert'}));
  el('c2-retract').addEventListener('click', () => command('set_c2', {action:'retract'}));
  document.addEventListener('input', event => { if (event.target.matches('input,select')) dirty.add(event.target.id); });
  document.addEventListener('change', event => { if (event.target.matches('input,select')) dirty.add(event.target.id); });
  el('randomize-twin').addEventListener('click', () => command('randomize_twin', {}));
  el('align-list').addEventListener('click', event => {
    const button = event.target.closest('button[data-align-one]');
    if (button) { event.preventDefault(); runAlignment([button.dataset.alignOne], true); }
  });
  const selectedPhases = () => [...document.querySelectorAll('#align-list input:checked')].map(input => input.value);
  el('align-selected').addEventListener('click', () => runAlignment(selectedPhases(), true));
  el('check-selected').addEventListener('click', () => runAlignment(selectedPhases(), false));
  connect();
})();
