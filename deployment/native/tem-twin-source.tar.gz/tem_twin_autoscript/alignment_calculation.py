"""Pure, bounded calculations over AutoScript observations; no instrument access."""

from collections import OrderedDict
import json
import threading
import uuid
import operator

import numpy as np


class AlignmentCalculator:
    def __init__(self, max_bytes=64 * 1024 * 1024):
        self.max_bytes = max_bytes
        self._images = OrderedDict()
        self._bytes = 0
        self._lock = threading.RLock()

    def remember(self, image):
        array = np.array(image, copy=True)
        if array.nbytes > self.max_bytes:
            raise ValueError("Image exceeds calculation cache capacity")
        array.flags.writeable = False
        key = uuid.uuid4().hex
        with self._lock:
            while self._bytes + array.nbytes > self.max_bytes or len(self._images) >= 128:
                _, old = self._images.popitem(last=False)
                self._bytes -= old.nbytes
            self._images[key] = array
            self._bytes += array.nbytes
        return key

    def _image(self, key):
        with self._lock:
            if key not in self._images:
                raise ValueError("Unknown or expired image reference; acquire a new image")
            a = self._images[key]
        if a.ndim != 2 or a.shape[0] != a.shape[1] or a.shape[0] < 8:
            raise ValueError("Expected a square image of at least 8 pixels per side")
        return self._array(a)

    @staticmethod
    def _array(value, shape=None):
        a = np.asarray(value, dtype=float)
        if not np.isfinite(a).all() or (shape is not None and a.shape != shape):
            raise ValueError("Invalid numeric shape or non-finite input")
        return a

    @classmethod
    def _positive(cls, value):
        result = float(cls._array(value, ()))
        if result <= 0:
            raise ValueError("Expected a positive value")
        return result

    def calculate_alignment(self, operation: str, inputs: dict, settings: dict | None = None) -> dict:
        """Calculate only; never acquire, change controls, or run a calibration loop.

        Operations and inputs:
        dark: image_ref -> dark_counts (99.95 percentile).
        beam: image_ref, dark_counts -> beam_found, centroid, ellipticity, radius.
        image_shift: moving_ref, reference_ref -> shift_px [x right, y up].
        jacobian: columns (two response differences), probe, central=false,
          max_condition=50, min_abs_det=1e-12 -> matrix, condition, valid.
          For rotation use central=true, max_condition=3, min_abs_det=0.
        solve: matrix, residual, max_condition=50, gain=1, optional limit
          -> correction (SUBTRACT from control; units follow matrix columns).
        vector: a, b, scale=1 -> value=a+scale*b, norm (two-element vectors).
        objective: image_refs (exactly four), pixel_size_m, voltage_v, cs_m
          -> measurable, astigmatism_nm, vector_nm, defocus_nm, residual_nm.
        Algorithms match autoalign.py; workflow decides branches and thresholds.
        settings supplies fixed constants; inputs supplies measured values. Keys
        must not overlap. scalar: a, b=0, scale=1 -> value=a+scale*b.
        magnification: values (AutoScript structures), target -> value (SET structure),
          choosing nearest log magnification outside LM as in autoalign.goto_mag.
        expression: fixed bounded arithmetic tree in settings.expression; inputs
          provides observed variables. Supports numeric arithmetic, comparisons,
          lazy if/and/or, norm/limit/clip, and Point/structure construction. No
          Python code, I/O, imports, control calls, or alignment loops are allowed.
        """
        json.dumps({"inputs": inputs, "settings": settings}, allow_nan=False)
        result = self._calculate(operation, inputs, settings)
        json.dumps(result, allow_nan=False)
        return result

    def _calculate(self, operation, inputs, settings):
        settings = settings or {}
        if inputs.keys() & settings.keys():
            raise ValueError("Measured inputs cannot override fixed settings")
        inputs = {**settings, **inputs}
        if operation == "expression":
            # A bounded arithmetic tree, not Python eval: no calls, imports, or I/O.
            budget = [2048]
            def evaluate(node, depth=0):
                budget[0] -= 1
                if depth > 32 or budget[0] < 0:
                    raise ValueError("Calculation expression exceeds limits")
                ev = lambda item: evaluate(item, depth + 1)
                if isinstance(node, list):
                    return [ev(item) for item in node]
                if not isinstance(node, dict):
                    return node
                if set(node) == {"var"}:
                    value = inputs
                    for key in node["var"].split("."):
                        if key.startswith("_"):
                            raise ValueError("Private keys are not available")
                        value = value[int(key)] if isinstance(value, list) else value[key]
                    return value
                if "op" not in node:
                    return {key: ev(value) for key, value in node.items()}
                op, args = node["op"], node.get("args", [])
                if op == "if":
                    return ev(args[1]) if ev(args[0]) else ev(args[2])
                if op == "and":
                    return all(ev(arg) for arg in args)
                if op == "or":
                    return any(ev(arg) for arg in args)
                values = [ev(arg) for arg in args]
                binary = {"add": operator.add, "sub": operator.sub, "mul": operator.mul,
                          "div": operator.truediv, "lt": operator.lt, "le": operator.le,
                          "gt": operator.gt, "ge": operator.ge, "eq": operator.eq}
                if op in binary:
                    if op != "eq" and (len(values) != 2 or any(isinstance(v, bool) or not isinstance(v, (int, float)) for v in values)):
                        raise ValueError("Arithmetic and ordered comparisons require two numeric scalars")
                    return binary[op](*values)
                if op == "abs":
                    return abs(values[0])
                if op == "norm":
                    return float(np.linalg.norm(self._array(values[0], (2,))))
                if op == "limit":
                    vector = self._array(values[0], (2,))
                    limit = self._positive(values[1])
                    length = float(np.linalg.norm(vector))
                    return (vector * (limit / length) if length > limit else vector).tolist()
                if op == "max":
                    return max(values)
                if op == "min":
                    return min(values)
                if op == "clip":
                    return float(np.clip(*values))
                if op == "point":
                    x, y = self._array(values[0], (2,))
                    return {"__type__": "Point", "x": float(x), "y": float(y)}
                if op == "xy":
                    return [values[0]["x"], values[0]["y"]]
                if op == "structure":
                    value = dict(values[0])
                    value["__type__"] = value.pop("type")
                    return value
                raise ValueError(f"Unsupported expression operation: {op}")
            result = evaluate(inputs["expression"])
            if not isinstance(result, dict):
                raise ValueError("Expression must return a result object")
            return result
        if operation == "scalar":
            value = float(self._array(inputs["a"], ())) + float(self._array(inputs.get("scale", 1), ())) * float(self._array(inputs.get("b", 0), ()))
            self._array(value, ())
            return {"value": value}
        if operation == "magnification":
            values = inputs["values"]
            target = self._positive(inputs["target"])
            hm = [v for v in values if v["objective_lens_mode"] != "LM"] or values
            best = min(hm, key=lambda v: abs(np.log(self._positive(v["nominal"]) / target)))
            return {"value": {**{k: v for k, v in best.items() if k != "type"},
                              "__type__": "MagnificationData"}}
        if operation in ("dark", "beam"):
            a = self._image(inputs["image_ref"])
            peak = float(np.percentile(a, 99.95))
            if operation == "dark":
                return {"dark_counts": peak}
            dark = float(self._array(inputs["dark_counts"], ()))
            ys, xs = np.nonzero(a > 0.25 * peak)
            if peak <= max(5 * dark, 20) or len(xs) < 4:
                return {"beam_found": False, "centroid": None, "ellipticity": None,
                        "centroid_norm": None, "radius": None}
            n = a.shape[0]
            u, v = (xs + 0.5) / (n / 2) - 1, 1 - (ys + 0.5) / (n / 2)
            c = np.array([u.mean(), v.mean()])
            l2, l1 = np.linalg.eigvalsh(np.cov(np.vstack([u - c[0], v - c[1]])))
            return {"beam_found": True, "centroid": c.tolist(),
                    "centroid_norm": float(np.linalg.norm(c)),
                    "radius": float(2 * np.sqrt(max((l1 + l2) / 2, 0))),
                    "ellipticity": float(1 - np.sqrt(max(l2, 1e-12) / max(l1, 1e-12)))}
        if operation == "image_shift":
            from .autofunctions import image_shift
            a, b = self._image(inputs["moving_ref"]), self._image(inputs["reference_ref"])
            if a.shape != b.shape or a.std() == 0 or b.std() == 0:
                raise ValueError("Image pair must have equal shapes and nonzero contrast")
            return {"shift_px": list(image_shift(a, b))}
        if operation == "jacobian":
            columns = self._array(inputs["columns"], (2, 2))
            probe = self._positive(inputs["probe"])
            central = inputs.get("central", False)
            if not isinstance(central, bool):
                raise ValueError("central must be boolean")
            matrix = columns.T / (probe * (2 if central else 1))
            self._array(matrix, (2, 2))
            condition = float(np.linalg.cond(matrix))
            determinant = float(np.linalg.det(matrix))
            minimum = float(self._array(inputs.get("min_abs_det", 1e-12), ()))
            if minimum < 0:
                raise ValueError("min_abs_det must be nonnegative")
            valid = (np.isfinite(condition) and condition <= self._positive(inputs.get("max_condition", 50))
                     and abs(determinant) > 0 and abs(determinant) >= minimum)
            return {"valid": bool(valid), "matrix": matrix.tolist(),
                    "condition": condition if np.isfinite(condition) else None}
        if operation == "solve":
            matrix = self._array(inputs["matrix"], (2, 2))
            condition = float(np.linalg.cond(matrix))
            if not np.isfinite(condition) or condition > self._positive(inputs.get("max_condition", 50)):
                raise ValueError("Calibration matrix is singular or ill-conditioned")
            correction = np.linalg.solve(matrix, self._array(inputs["residual"], (2,)))
            correction *= float(self._array(inputs.get("gain", 1), ()))
            norm = float(np.linalg.norm(correction))
            if "limit" in inputs:
                limit = self._positive(inputs["limit"])
                if norm > limit:
                    correction *= limit / norm
            self._array(correction, (2,))
            return {"correction": correction.tolist(), "unlimited_norm": norm}
        if operation == "vector":
            value = self._array(inputs["a"], (2,)) + float(self._array(inputs.get("scale", 1), ())) * self._array(inputs["b"], (2,))
            self._array(value, (2,))
            return {"value": value.tolist(), "norm": float(np.linalg.norm(value))}
        if operation == "objective":
            from .autofunctions import power_spectrum, fit_defocus_map, fit_astigmatism
            from .autoalign import electron_wavelength_nm
            refs = inputs["image_refs"]
            if not isinstance(refs, list) or len(refs) != 4 or len(set(refs)) != 4:
                raise ValueError("Exactly four distinct frame references are required")
            images = [self._image(ref) for ref in refs]
            if any(a.shape != images[0].shape for a in images):
                raise ValueError("All frames must have the same shape")
            theta, d, q = fit_defocus_map(power_spectrum(images),
                self._positive(inputs["pixel_size_m"]) * 1e9,
                electron_wavelength_nm(self._positive(inputs["voltage_v"])),
                cs_nm=self._positive(inputs["cs_m"]) * 1e9)
            fit = fit_astigmatism(theta, d, q)
            if fit is None:
                return {"measurable": False, "astigmatism_nm": None}
            self._array([fit[0], *fit[1], fit[2]], (4,))
            return {"measurable": True, "astigmatism_nm": float(np.linalg.norm(fit[1])),
                    "vector_nm": fit[1].tolist(), "defocus_nm": fit[0], "residual_nm": fit[2]}
        raise ValueError(f"Unsupported calculation operation: {operation}")
