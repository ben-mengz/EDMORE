"""One Slurm allocation: keep registration alive while restarting the Twin child."""
import argparse
import asyncio
import json
import os
import signal
from pathlib import Path
from .registration_server import write_private


async def stop_child(process):
    if process is None or process.returncode is not None:
        return
    try:
        process.terminate()
        await asyncio.wait_for(process.wait(), 35)
    except TimeoutError:
        os.killpg(process.pid, signal.SIGKILL)
        await process.wait()
    except ProcessLookupError:
        await process.wait()


async def supervise(config):
    control = Path(config['control_dir'])
    control.mkdir(parents=True, exist_ok=True)
    request_path = control/'reload-request.json'
    response_path = control/'reload-response.json'
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stop.set)
    children = {}; logs = []

    async def start(name):
        log = (control/f'{name}.log').open('ab', buffering=0)
        logs.append(log)
        process = await asyncio.create_subprocess_exec(*config[name + '_command'],
            stdout=log, stderr=log, start_new_session=True)
        children[name] = process
        return process

    try:
        # Any old request is completed by this fresh Twin startup; never replay it.
        handled = json.loads(request_path.read_text())['id'] if request_path.exists() else None
        await start('twin')
        await start('registration')
        if handled:
            write_private(response_path, {'id': handled, 'ok': True})
        while not stop.is_set():
            if request_path.exists():
                request = json.loads(request_path.read_text())
                if request['id'] != handled:
                    handled = request['id']
                    try:
                        await stop_child(children['twin'])
                        await start('twin')
                        write_private(response_path, {'id': handled, 'ok': True})
                    except Exception:
                        write_private(response_path, {'id': handled, 'ok': False})
                        raise
            for name, process in list(children.items()):
                if process.returncode is not None:
                    print(f'{name} exited ({process.returncode}); restarting child', flush=True)
                    try: await asyncio.wait_for(stop.wait(), 3)
                    except TimeoutError: pass
                    if not stop.is_set(): await start(name)
            try: await asyncio.wait_for(stop.wait(), 0.25)
            except TimeoutError: pass
    finally:
        await stop_child(children.get('registration'))
        await stop_child(children.get('twin'))
        for log in logs: log.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    args = parser.parse_args()
    asyncio.run(supervise(json.loads(Path(args.config).read_text())))


if __name__ == '__main__': main()
