"""Own the engine and its AutoScript endpoint independently of all GUI viewers."""

import logging
import threading

from .handlers import TwinMicroscope
from .orc_server import OrcServer
from .twin_link import TwinLink


class TwinRuntime:
    def __init__(self, host="127.0.0.1", port=7521, prepare=True):
        self.link = TwinLink()
        self.server = OrcServer(TwinMicroscope(self.link), host=host, port=port)
        self.aligner = None
        self.align_lock = threading.Lock()
        self.port = port
        try:
            self.server.start()
            self.port = self.server.port
            self.link.on_event = self.on_event
            if prepare:
                self.link.set(spec=True, ht=200, beam=True, valves=True)
        except Exception:
            self.close()
            raise

    def on_event(self, message):
        if message.get("type") == "stop":
            if self.aligner:
                self.aligner.stop_requested = True
            return
        if message.get("type") != "autoalign" or not self.align_lock.acquire(blocking=False):
            return
        from autoscript_tem_microscope_client import TemMicroscopeClient
        from .autoalign import AutoAligner

        client = TemMicroscopeClient()
        try:
            client.connect("127.0.0.1", self.port)
            self.aligner = AutoAligner(
                client,
                progress=lambda step, status, text: self.link.send_event(type="progress", step=step, status=status, text=text),
                log=lambda text: self.link.send_event(type="log", text=text),
            )
            self.aligner.run(fix=bool(message.get("fix", True)), steps=message.get("steps"))
        except Exception as error:
            logging.getLogger(__name__).exception("GUI alignment failed")
            if self.link.connected:
                self.link.send_event(type="log", text=f"AutoScript alignment failed: {error}")
        finally:
            self.aligner = None
            self.align_lock.release()
            try:
                client.disconnect()
            finally:
                if self.link.connected:
                    self.link.send_event(type="done")

    def close(self):
        if self.aligner:
            self.aligner.stop_requested = True
        self.server.stop()
        self.link.close()
