"""
Auto alignment of a TEM using only AutoScript TEM client calls.

Each step measures its alignment from camera images (or the screen current), corrects it only when it is out
of tolerance, and leaves aligned steps untouched. Magnification, intensity, defocus, projector mode, stage X/Y
and the screen position are restored at the end; only stage Z keeps its eucentric correction.

Deflector responses are calibrated on the fly (a small known step and the measured image response give a 2x2
matrix), so the code does not assume that deflector axes line up with the camera. The same code drives the
digital twin (through its AutoScript server) and an AutoScript-enabled microscope.

    python -m tem_twin_autoscript.autoalign                  # align (twin on localhost)
    python -m tem_twin_autoscript.autoalign --check          # measure and report only
    python -m tem_twin_autoscript.autoalign --steps beam,z   # selected steps

    from tem_twin_autoscript.autoalign import AutoAligner
    AutoAligner(microscope).run(fix=True)

On a real instrument: use low exposure for the focused beam (camera protection), check that the C2 aperture is
motorised (otherwise only beam shift is corrected), and set cs to the objective lens value.
"""

import argparse
import math
import time

import numpy as np
from autoscript_tem_microscope_client.enumerations import CameraType, FocusMethod
from autoscript_tem_microscope_client.structures import (Point, RunBeamTiltAutoFocusSettings,
                                                         RunObjectiveAutoStigmatorSettings, StagePosition)

from .autofunctions import fit_astigmatism, fit_defocus_map, image_shift, power_spectrum

STEPS = [
    ("beam", "Beam shift + C2 aperture", "focused spot within 0.02 and spread beam within 0.01 of the field centre"),
    ("gun", "Gun tilt", "no probe direction raises the screen current by more than 0.5 %"),
    ("c2stig", "Condenser astigmatism", "beam ellipticity below 0.03"),
    ("z", "Eucentric focus (stage Z)", "sample within 100 nm of eucentric focus"),
    ("rot", "Rotation centre", "beam-tilt offset below 0.8 mrad"),
    ("ostig", "Objective astigmatism", "below 3 nm (needs amorphous film in view)"),
]


class Stopped(Exception):
    pass


def electron_wavelength_nm(volts):
    h, m0, e, c = 6.62607015e-34, 9.1093837e-31, 1.602176634e-19, 2.99792458e8
    return h / math.sqrt(2 * m0 * e * volts * (1 + e * volts / (2 * m0 * c * c))) * 1e9


class AutoAligner:
    def __init__(self, microscope, camera=CameraType.BM_CETA, cs=1.2e-3, progress=None, log=print,
                 spot_exposure=0.005, spread_exposure=0.02, image_exposure=0.2, settle_seconds=0.0):
        self.m = microscope
        self.camera = camera
        self.cs_nm = cs * 1e9
        self.progress = progress or (lambda step, status, text: None)
        self.log = log
        self.exp = {"spot": spot_exposure, "spread": spread_exposure, "image": image_exposure}
        self.settle_seconds = max(0.0, float(settle_seconds))
        self.stop_requested = False
        self.results = {}
        self.dark = 0.0
        self.fov_m = None

    # ================================================================== helpers
    def _check(self):
        if self.stop_requested:
            raise Stopped("stopped")

    def frame(self, kind="image", size=256):
        self._check()
        if self.settle_seconds:
            time.sleep(self.settle_seconds)
        img = self.m.acquisition.acquire_camera_image(self.camera, size, self.exp[kind])
        return img.data.astype(np.float64), img.metadata.binary_result.pixel_size.x

    def goto_mag(self, target):
        vals = list(self.m.optics.magnification.available_values)
        hm = [v for v in vals if v.objective_lens_mode != "LM"] or vals
        best = min(hm, key=lambda v: abs(math.log(v.nominal / target)))
        self.m.optics.magnification.value = best
        _a, px = self.frame("spread")
        self.fov_m = px * 256

    def set_beam(self, fraction):
        """Beam diameter as a fraction of the field of view (0.02 = focused spot, 1.1 = spread past the field)."""
        self.m.optics.beam_diameter = fraction * self.fov_m

    def beam(self, kind="spot"):
        """Lit-area centroid (field half-widths, x right, y up), radius and ellipticity; None if no beam."""
        a, _px = self.frame(kind)
        peak = np.percentile(a, 99.95)
        if peak <= max(5 * self.dark, 20):
            return None
        ys, xs = np.nonzero(a > 0.25 * peak)
        if len(xs) < 4:
            return None
        n = a.shape[0]
        u = (xs + 0.5) / (n / 2) - 1
        v = 1 - (ys + 0.5) / (n / 2)
        c = np.array([u.mean(), v.mean()])
        cov = np.cov(np.vstack([u - c[0], v - c[1]]))
        l1, l2 = sorted(np.linalg.eigvalsh(cov), reverse=True)
        return {"c": c, "r": 2 * math.sqrt(max((l1 + l2) / 2, 0)), "ell": 1 - math.sqrt(max(l2, 1e-12) / max(l1, 1e-12))}

    def spot(self):
        self.set_beam(0.02)
        return self.beam("spot")

    def spread(self):
        self.set_beam(0.9)
        return self.beam("spread")

    @staticmethod
    def _pt(p):
        return np.array([p.x, p.y], float)

    def jacobian(self, measure, get, set_, probe):
        """2x2 response of a measured vector to a Point-valued control, from +probe steps in x and y."""
        base = get()
        c0 = measure()
        cols = []
        for d in ((probe, 0.0), (0.0, probe)):
            set_(Point(base.x + d[0], base.y + d[1]))
            c = measure()
            cols.append((c - c0) / probe)
        set_(base)
        J = np.column_stack(cols)
        if not np.isfinite(J).all() or abs(np.linalg.det(J)) < 1e-12 or np.linalg.cond(J) > 50:
            raise RuntimeError("calibration failed (no clear response to the control)")
        return J

    @staticmethod
    def _limit(v, lim):
        n = float(np.hypot(*v))
        return v * (lim / n) if n > lim else v

    def _pattern_search(self, get, set_, measure, step, min_step, maximise, max_evals=80):
        best = measure()
        better = (lambda a, b: a > b) if maximise else (lambda a, b: a < b)
        evals = 0
        while step >= min_step and evals < max_evals:
            improved = False
            for dx, dy in ((step, 0), (-step, 0), (0, step), (0, -step)):
                p = get()
                set_(Point(p.x + dx, p.y + dy))
                v = measure(); evals += 1
                if better(v, best):
                    best, improved = v, True
                    break
                set_(p)
            if not improved:
                step /= 2
        return best

    # ================================================================== beam finding
    def find_beam(self):
        """Bring the focused spot onto the camera: spread the beam (and pull C2 if needed) and shift it back."""
        defl = self.m.optics.deflectors
        for _ in range(8):
            if self.spot() is not None:
                return
            b = self.spread()
            c2 = self.m.optics.aperture_mechanisms.C2
            pulled = False
            if b is None:
                self.set_beam(1.6)
                b = self.beam("spread")
            if b is None and c2.insertion_state == "Inserted":
                c2.retract(); pulled = True
                b = self.beam("spread")
            if b is None:
                if pulled:
                    c2.insert()
                raise RuntimeError("no beam on the camera even with a spread beam; check gun tilt and valves")
            bs = defl.beam_shift
            defl.beam_shift = Point(bs.x - 1.2 * b["c"][0] * self.fov_m / 2, bs.y - 1.2 * b["c"][1] * self.fov_m / 2)
            if pulled:
                c2.insert()
        if self.spot() is None:
            raise RuntimeError("could not bring the focused beam onto the camera")

    # ================================================================== steps
    def step_beam(self, fix):
        m = self.m
        defl = m.optics.deflectors
        c2 = m.optics.aperture_mechanisms.C2
        self.goto_mag(20e3)
        self.find_beam()
        c2_in = c2.insertion_state == "Inserted"
        s0 = float(np.hypot(*self.spot()["c"]))
        p0 = float(np.hypot(*self.spread()["c"])) if c2_in else 0.0
        before = "spot %.3f" % s0 + (", spread %.3f" % p0 if c2_in else "")
        if s0 < 0.02 and p0 < 0.01:
            return "ok", before
        if not fix:
            return "off", before

        spot_c = lambda: self.spot()["c"]
        spread_c = lambda: self.spread()["c"]
        Jb = self.jacobian(spot_c, lambda: defl.beam_shift, lambda p: setattr(defl, "beam_shift", p), 0.05 * self.fov_m / 2)
        Ja = None
        for _ in range(16):
            c = spot_c()
            d = self._limit(np.linalg.solve(Jb, c), 0.5 * self.fov_m / 2)
            bs = defl.beam_shift
            defl.beam_shift = Point(bs.x - d[0], bs.y - d[1])
            if not c2_in:
                if np.hypot(*spot_c()) < 0.004:
                    break
                continue
            if Ja is None:
                Ja = self.jacobian(spread_c, lambda: c2.position, lambda p: setattr(c2, "position", p), 2e-6)
            c = spread_c()
            if np.hypot(*c) < 0.004:
                break
            d = self._limit(np.linalg.solve(Ja, c), 6e-6)
            p = c2.position
            c2.position = Point(p.x - d[0], p.y - d[1])
        c = spot_c()
        d = np.linalg.solve(Jb, c)
        bs = defl.beam_shift
        defl.beam_shift = Point(bs.x - d[0], bs.y - d[1])
        s1 = float(np.hypot(*self.spot()["c"]))
        p1 = float(np.hypot(*self.spread()["c"])) if c2_in else 0.0
        return "fixed", "%s -> spot %.3f" % (before, s1) + (", spread %.3f" % p1 if c2_in else "")

    def step_gun(self, fix):
        m = self.m
        defl = m.optics.deflectors
        self.goto_mag(20e3)
        self.set_beam(0.35)                               # partly converged, whole beam on the screen

        def current():
            self._check()
            if self.settle_seconds:
                time.sleep(self.settle_seconds)
            return 0.5 * (m.detectors.screen.measure_current() + m.detectors.screen.measure_current())

        c0 = current()
        gain = 0.0
        base = defl.gun_tilt
        for dx, dy in ((0.03, 0), (-0.03, 0), (0, 0.03), (0, -0.03)):
            defl.gun_tilt = Point(base.x + dx, base.y + dy)
            gain = max(gain, current() / c0 - 1)
        defl.gun_tilt = base
        if gain < 0.005:
            return "ok", "%.3g A (at maximum)" % c0
        if not fix:
            return "off", "%.3g A, +%.1f %% available" % (c0, gain * 100)
        best = self._pattern_search(lambda: defl.gun_tilt, lambda p: setattr(defl, "gun_tilt", p),
                                    current, 0.1, 0.005, maximise=True)
        return "fixed", "%.3g A -> %.3g A" % (c0, best)

    def step_c2stig(self, fix):
        stig = self.m.optics.stigmators
        self.goto_mag(20e3)
        self.set_beam(0.2)                                # just off crossover: condenser astigmatism shows as an ellipse

        def ell():
            b = self.beam("spot")
            return 1.0 if b is None else b["ell"]
        e0 = ell()
        if e0 < 0.03:
            return "ok", "ellipticity %.3f" % e0
        if not fix:
            return "off", "ellipticity %.3f" % e0
        e1 = self._pattern_search(lambda: stig.condenser_stigmator, lambda p: setattr(stig, "condenser_stigmator", p),
                                  ell, 0.15, 0.004, maximise=False)
        return "fixed", "ellipticity %.3f -> %.3f" % (e0, e1)

    def step_z(self, fix):
        m = self.m
        stage = m.specimen.stage
        self.goto_mag(250e3)
        self.set_beam(1.1)
        m.optics.focus = 0.0                              # objective at eucentric focus
        z0 = stage.position.z
        m.auto_functions.run_beam_tilt_auto_focus(RunBeamTiltAutoFocusSettings(
            camera_detector=self.camera, focus_method=FocusMethod.STAGE_Z, maximum_iterations=6))
        dz = stage.position.z - z0
        before = "Z offset %.3f um" % (-dz * 1e6)
        if abs(dz) < 100e-9:
            stage.absolute_move(StagePosition(z=z0))      # within tolerance: leave the stage where it was
            return "ok", before
        if not fix:
            stage.absolute_move(StagePosition(z=z0))
            return "off", before
        return "fixed", "%s -> corrected by %+.2f um" % (before, dz * 1e6)

    def _wobble_shift(self, wob):
        m = self.m
        d0 = m.optics.defocus
        m.optics.defocus = d0 + wob; a, _ = self.frame("image")
        m.optics.defocus = d0 - wob; b, _ = self.frame("image")
        m.optics.defocus = d0
        return np.array(image_shift(b, a))

    def step_rot(self, fix):
        m = self.m
        if not fix and self.results.get("z", ("",))[0] == "off":
            return "skip", "correct eucentric focus first; the image is too far from focus to measure the tilt"
        defl = m.optics.deflectors
        self.goto_mag(250e3)
        self.set_beam(1.1)
        px = self.fov_m / 256
        # focus wobble giving ~3 px of image shift per mrad, so offsets up to ~10 mrad stay inside the correlation window
        wob = float(np.clip(1500 * px, 150e-9, 8e-6))
        shift = lambda: 0.5 * (self._wobble_shift(wob) + self._wobble_shift(wob))
        s0 = shift()
        # calibrate the image-shift response to beam tilt with central differences
        base = defl.beam_tilt
        probe = 1.5e-3
        cols = []
        for d in ((probe, 0.0), (0.0, probe)):
            defl.beam_tilt = Point(base.x + d[0], base.y + d[1]); sp = shift()
            defl.beam_tilt = Point(base.x - d[0], base.y - d[1]); sm = shift()
            cols.append((sp - sm) / (2 * probe))
        defl.beam_tilt = base
        J = np.column_stack(cols)
        sv = np.linalg.svd(J, compute_uv=False)
        if not np.isfinite(J).all() or sv[1] <= 0 or sv[0] / sv[1] > 3:
            return "err", "calibration failed (beam-tilt response is not a clean rotation); try on a thinner area"
        tau = np.linalg.solve(J, s0)
        t0 = float(np.hypot(*tau)) * 1e3
        if t0 < 0.8:
            return "ok", "%.2f mrad" % t0
        if not fix:
            return "off", "%.2f mrad" % t0
        gain, s_prev = 1.0, float(np.hypot(*s0))
        for _ in range(8):
            step = self._limit(gain * tau, 5e-3)
            bt = defl.beam_tilt
            defl.beam_tilt = Point(bt.x - step[0], bt.y - step[1])
            s1 = shift()
            if np.hypot(*s1) > s_prev:                    # got worse: undo and take a smaller step
                defl.beam_tilt = bt
                gain /= 2
                if gain < 0.1:
                    break
                continue
            s_prev = float(np.hypot(*s1))
            tau = np.linalg.solve(J, s1)
            if np.hypot(*tau) * 1e3 < 0.1:
                break
        return "fixed", "%.2f -> %.2f mrad" % (t0, float(np.hypot(*tau)) * 1e3)

    def _astigmatism(self):
        imgs, px = [], None
        for _ in range(4):
            a, px = self.frame("image")
            imgs.append(a)
        lam = electron_wavelength_nm(self._ht())
        theta, d, q = fit_defocus_map(power_spectrum(imgs), px * 1e9, lam, cs_nm=self.cs_nm)
        fit = fit_astigmatism(theta, d, q)
        return None if fit is None else float(np.hypot(*fit[1]))

    def _ht(self):
        try:
            return float(self.m.source.acceleration_voltage.value)
        except Exception:
            return 200e3

    def step_ostig(self, fix):
        m = self.m
        if not fix and self.results.get("z", ("",))[0] == "off":
            return "skip", "correct eucentric focus first; Thon rings are unreadable this far from focus"
        self.goto_mag(4e6)
        self.set_beam(1.1)
        d0 = m.optics.defocus
        m.optics.focus = 0.0
        m.optics.defocus = m.optics.defocus - 400e-9       # underfocus so several Thon rings are in the band
        try:
            a0 = self._astigmatism()
            if a0 is None:
                return "skip", "no Thon rings here: move to amorphous film"
            if a0 < 3:
                return "ok", "%.1f nm" % a0
            if not fix:
                return "off", "%.1f nm" % a0
        finally:
            m.optics.defocus = d0
        r = m.auto_functions.run_objective_auto_stigmator(RunObjectiveAutoStigmatorSettings(camera_detector=self.camera))
        return "fixed", "%.1f -> %.1f nm" % (a0, r.astigmatism * 1e9)

    # ================================================================== run
    def run(self, fix=True, steps=None):
        m = self.m
        steps = steps or [s[0] for s in STEPS]
        self.stop_requested = False
        self.results = {}
        stage = m.specimen.stage
        saved = {
            "mag": m.optics.magnification.value, "intensity": m.optics.intensity, "defocus": m.optics.defocus,
            "projector": m.optics.projector_mode, "pos": stage.position,
            "screen": m.detectors.screen.position,
        }
        self.log(("Auto align" if fix else "Check alignment") + " (AutoScript): start")
        try:
            m.optics.projector_mode = "Imaging"
            if saved["screen"] == "Inserted":
                m.detectors.screen.retract()
            m.optics.blank()                              # dark level of the camera
            self.fov_m = self.frame("spread")[1] * 256
            self.dark = float(np.percentile(self.frame("spread")[0], 99.95))
            m.optics.unblank()
            for sid, name, tol in STEPS:
                if sid not in steps:
                    continue
                self.progress(sid, "run", "measuring…")
                try:
                    status, text = getattr(self, "step_" + sid)(fix)
                except Stopped:
                    self.progress(sid, "err", "stopped")
                    raise
                except Exception as ex:
                    status, text = "err", str(ex)
                if not fix and status == "off" and any(self.results.get(p, ("",))[0] == "off" for p, *_ in STEPS[:[s[0] for s in STEPS].index(sid)]):
                    text += " (approximate: earlier steps are out of tolerance)"
                self.results[sid] = (status, text)
                self.progress(sid, status, text)
                self.log("  %s: %s · %s" % (name, status, text))
            self.log(("Auto align" if fix else "Check alignment") + " (AutoScript): done")
        except Stopped:
            self.log("Auto align (AutoScript): stopped")
        finally:
            try:
                m.optics.unblank()
                m.optics.magnification.value = saved["mag"]
                m.optics.intensity = saved["intensity"]
                m.optics.defocus = saved["defocus"]
                m.optics.projector_mode = saved["projector"]
                p = saved["pos"]
                stage.absolute_move(StagePosition(x=p.x, y=p.y))
                if saved["screen"] == "Inserted":
                    m.detectors.screen.insert()
            except Exception as ex:
                self.log("  could not restore working conditions: %s" % ex)
        return self.results


def main(argv=None):
    from autoscript_tem_microscope_client import TemMicroscopeClient
    ap = argparse.ArgumentParser(description="Auto alignment with AutoScript calls only")
    ap.add_argument("--host", default="localhost")
    ap.add_argument("--port", type=int, default=7521)
    ap.add_argument("--check", action="store_true", help="measure and report only")
    ap.add_argument("--steps", default=",".join(s[0] for s in STEPS), help="comma-separated: " + ",".join(s[0] for s in STEPS))
    ap.add_argument("--camera", default=CameraType.BM_CETA)
    ap.add_argument("--cs", type=float, default=1.2e-3, help="objective Cs in metres")
    a = ap.parse_args(argv)
    m = TemMicroscopeClient()
    m.connect(a.host, a.port)
    try:
        t0 = time.time()
        AutoAligner(m, camera=a.camera, cs=a.cs).run(fix=not a.check, steps=a.steps.split(","))
        print("took %.1f s" % (time.time() - t0))
    finally:
        m.disconnect()


if __name__ == "__main__":
    main()
