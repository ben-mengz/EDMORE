"""AutoScript-compatible server for the TEM Alignment Twin."""
__version__ = "1.0.0"
