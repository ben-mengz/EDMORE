'use strict';
const $ = id => document.getElementById(id);
let csrf = '', refreshing = false, timer = null, lastData = null, message = null;
const translations = {
  "removedDevices": ["已移除的设备", "Removed devices"],
  "clearRemoved": ["清空", "Clear"],
  "removedCleared": ["已清空 {count} 条已移除设备记录。", "Cleared {count} removed device records."],
  "title": [
    "设备管理",
    "Device Management"
  ],
  "changePassword": [
    "修改密码",
    "Change password"
  ],
  "logout": [
    "退出登录",
    "Log out"
  ],
  "adminLogin": [
    "管理员登录",
    "Administrator login"
  ],
  "loginDescription": [
    "审批注册申请，查看与管理 Tango 设备。",
    "Review enrollment requests and manage Tango devices."
  ],
  "username": [
    "用户名",
    "Username"
  ],
  "password": [
    "密码",
    "Password"
  ],
  "login": [
    "登录",
    "Log in"
  ],
  "loading": [
    "正在读取设备状态…",
    "Loading device status…"
  ],
  "refresh": [
    "刷新状态",
    "Refresh status"
  ],
  "requests": [
    "注册申请",
    "Enrollment requests"
  ],
  "checkIdentity": [
    "请核对电脑名称、设备名称和凭据指纹",
    "Check the computer, device name and credential fingerprint"
  ],
  "devices": [
    "Tango 设备",
    "Tango devices"
  ],
  "deviceDescription": [
    "禁用会停止云端访问；恢复后重新加入 Tango / MCP",
    "Disabling stops cloud access; enabling restores Tango / MCP access"
  ],
  "device": [
    "设备",
    "Device"
  ],
  "authorization": [
    "注册 / 连接",
    "Registration / connection"
  ],
  "actions": [
    "操作",
    "Actions"
  ],
  "recentOperations": [
    "最近的管理操作",
    "Recent management operations"
  ],
  "currentPassword": [
    "当前密码",
    "Current password"
  ],
  "newPassword": [
    "新密码（至少 12 字符）",
    "New password (at least 12 characters)"
  ],
  "savePassword": [
    "保存并重新登录",
    "Save and log in again"
  ],
  "cancel": [
    "取消",
    "Cancel"
  ],
  "footer": [
    "注册服务与 Twin / MCP 共用同一个云端任务。更新设备时会短暂重载云端服务。",
    "Enrollment and Twin / MCP share one cloud job. Device changes briefly reload the cloud service."
  ],
  "registered": [
    "已注册",
    "Registered"
  ],
  "pending": [
    "待审批",
    "Pending approval"
  ],
  "approved": [
    "已批准 · 等待同步",
    "Approved · awaiting sync"
  ],
  "rejected": [
    "已拒绝",
    "Rejected"
  ],
  "disabled": [
    "已禁用",
    "Disabled"
  ],
  "revoked": [
    "已撤销",
    "Revoked"
  ],
  "unregistered": [
    "已注销",
    "Unregistered"
  ],
  "running": [
    "执行中",
    "Running"
  ],
  "complete": [
    "已完成",
    "Complete"
  ],
  "failed": [
    "失败",
    "Failed"
  ],
  "interrupted": [
    "已中断",
    "Interrupted"
  ],
  "approve": [
    "批准",
    "Approve"
  ],
  "reject": [
    "拒绝",
    "Reject"
  ],
  "disable": [
    "禁用",
    "Disable"
  ],
  "enable": [
    "恢复",
    "Enable"
  ],
  "revoke": [
    "撤销注册",
    "Revoke registration"
  ],
  "retry": [
    "重试同步",
    "Retry sync"
  ],
  "confirmApprove": [
    "批准这台设备的注册？请确认它来自你认识的电脑。",
    "Approve this device? Confirm that you recognize the computer."
  ],
  "confirmReject": [
    "拒绝这条注册申请？",
    "Reject this enrollment request?"
  ],
  "confirmDisable": [
    "禁用该设备的云端访问？",
    "Disable cloud access for this device?"
  ],
  "confirmEnable": [
    "恢复该设备的云端访问？",
    "Restore cloud access for this device?"
  ],
  "confirmRevoke": [
    "撤销注册？此安装的旧凭据将被阻止。",
    "Revoke registration? This installation's old credentials will be blocked."
  ],
  "confirmRetry": [
    "重试这条已批准的注册申请？",
    "Retry this approved enrollment request?"
  ],
  "requestRejected": [
    "申请已拒绝",
    "Request rejected"
  ],
  "submitted": [
    "操作已提交。云端正在同步 Tango / MCP，请稍候。",
    "Operation submitted. Synchronizing Tango / MCP; please wait."
  ],
  "updated": [
    "最近更新：{value}",
    "Last updated: {value}"
  ],
  "missingDate": [
    "历史记录未保存时间",
    "No historical timestamp"
  ],
  "pendingUpdate": [
    "云端有待完成更新：{device}。请重试对应管理操作。",
    "Cloud update pending for {device}. Retry the corresponding management operation."
  ],
  "computer": [
    "电脑：{value}",
    "Computer: {value}"
  ],
  "notProvided": [
    "未提供",
    "Not provided"
  ],
  "fingerprint": [
    "凭据指纹：{value}",
    "Credential fingerprint: {value}"
  ],
  "requestedAt": [
    "申请时间：{value}",
    "Requested: {value}"
  ],
  "connected": [
    "连接已建立",
    "Connected"
  ],
  "disconnected": [
    "电脑未连接",
    "Computer disconnected"
  ],
  "noRequests": [
    "暂无注册申请。",
    "No enrollment requests."
  ],
  "systemDevice": [
    "系统设备 · 受保护",
    "Protected system device"
  ],
  "relay": [
    "HTTPS 主动连接",
    "Outbound HTTPS connection"
  ],
  "direct": [
    "现有直连设备",
    "Direct connection"
  ],
  "registeredAt": [
    "注册：{value}",
    "Registered: {value}"
  ],
  "unknownStatus": [
    "状态未获取",
    "Status unavailable"
  ],
  "online": [
    "在线",
    "Online"
  ],
  "offline": [
    "离线",
    "Offline"
  ],
  "unknown": [
    "未知",
    "Unknown"
  ],
  "visible": [
    "可见",
    "Visible"
  ],
  "removed": [
    "已移除",
    "Removed"
  ],
  "systemManaged": [
    "系统维护",
    "System managed"
  ],
  "loggedOut": [
    "已退出登录",
    "Logged out"
  ],
  "passwordChanged": [
    "密码已修改，请重新登录。",
    "Password changed. Please log in again."
  ],
  "liveUnavailable": [
    "暂时无法获取 Tango 实时状态，仍显示已保存的设备记录。",
    "Live Tango status is temporarily unavailable; saved device records are still shown"
  ],
  "invalidLogin": [
    "用户名或密码不正确",
    "Invalid username or password"
  ],
  "waitLogin": [
    "请等待一分钟后重试",
    "Please wait one minute before retrying"
  ],
  "invalidOrigin": [
    "浏览器来源不匹配",
    "Invalid browser origin"
  ],
  "invalidSession": [
    "会话已失效，请重新登录",
    "Invalid session token"
  ],
  "invalidPassword": [
    "密码长度须为 12 至 256 字符",
    "Use a password of 12–256 characters"
  ],
  "wrongPassword": [
    "当前密码不正确",
    "Current password does not match"
  ],
  "updateRunning": [
    "云端更新正在进行，请稍候",
    "A cloud update is already running"
  ],
  "connectionNotReady": [
    "设备 HTTPS 连接尚未就绪",
    "Device HTTPS connection is not ready"
  ],
  "pendingCloud": [
    "云端更新尚未完成，请使用相同设备凭据重试",
    "Cloud update pending; retry the same request with the same device credential"
  ],
  "cannotApprove": [
    "此申请当前无法批准",
    "Request cannot be approved"
  ],
  "discoveryPending": [
    "MCP 设备发现尚未完成",
    "MCP device discovery has not converged"
  ],
  "networkError": [
    "无法连接服务器，请检查网络后重试",
    "Cannot connect to the server. Check your network and retry."
  ]
};
let language = 'en';
try { const saved = localStorage.getItem('edmore-admin-language'); if (saved === 'zh' || saved === 'en') language = saved; } catch {}
const t = (key, args = {}) => (translations[key]?.[language === 'zh' ? 0 : 1] || key).replace(/\{(\w+)\}/g, (_, name) => args[name] ?? '');
const errorKeys = Object.fromEntries(Object.entries(translations).filter(([key]) => ['liveUnavailable','invalidLogin','waitLogin','invalidOrigin','invalidSession','invalidPassword','wrongPassword','updateRunning','connectionNotReady','pendingCloud','cannotApprove','discoveryPending'].includes(key)).map(([key, values]) => [values[1], key]));
Object.assign(errorKeys, {'401: Unauthorized':'invalidSession', 'Failed to fetch':'networkError', 'Load failed':'networkError'});
const translateError = text => errorKeys[text] ? t(errorKeys[text]) : text;
function displayNotice() {
  $('message').textContent = message ? (message.raw ? translateError(message.text) : t(message.text, message.args)) : '';
  $('message').hidden = !message;
  $('message').className = message?.error ? 'error' : '';
}
function notice(text, error = false, args = {}, raw = false) { message = text ? {text, error, args, raw} : null; displayNotice(); }
function setLanguage(value) {
  language = value; $('language').value = value; document.documentElement.lang = value === 'zh' ? 'zh-CN' : 'en';
  document.title = 'EDMORE · ' + t('title');
  document.querySelectorAll('[data-i18n]').forEach(node => { node.textContent = t(node.dataset.i18n); });
  if (lastData && csrf) render(lastData);
  displayNotice();
  try { localStorage.setItem('edmore-admin-language', value); } catch {}
}
const nativeReady = new Promise(resolve => { if (window.pywebview?.api) resolve(); else window.addEventListener('pywebviewready', resolve, {once:true}); });
async function api(path, body) {
  if (document.body.dataset.native === 'true') {
    await nativeReady;
    const result = await window.pywebview.api.admin_request(path, body || null, csrf);
    if (result.status >= 400) { if (result.status === 401 && path !== 'login') showLogin(); throw new Error(result.error); }
    return result.data;
  }
  const response = await fetch('/admin/api/' + path, {method:body ? 'POST' : 'GET', headers:body ? {'Content-Type':'application/json','X-CSRF-Token':csrf} : {}, body:body ? JSON.stringify(body) : undefined, cache:'no-store'});
  if (!response.ok) { if (response.status === 401 && path !== 'login') showLogin(); throw new Error(await response.text()); }
  return response.json();
}
function showLogin() { clearInterval(timer); timer = null; csrf = ''; lastData = null; $('dashboard').hidden = true; $('account').hidden = true; $('login-panel').hidden = false; $('password-panel').hidden = true; }
function element(tag, text, className) { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; if (className) node.className = className; return node; }
function date(value) { return value ? new Date(value).toLocaleString(language === 'zh' ? 'zh-CN' : 'en-GB') : t('missingDate'); }
async function action(device, type) {
  const key = 'confirm' + type[0].toUpperCase() + type.slice(1);
  if (!confirm(device + '\n\n' + t(key))) return;
  try { const result = await api('action', {device, action:type}); notice(result.status === 'rejected' ? 'requestRejected' : 'submitted'); await refresh(); }
  catch (error) { notice(error.message, true, {}, true); }
}
function button(device, type, danger = false) { const node = element('button', t(type), danger ? 'danger' : ''); node.addEventListener('click', () => action(device, type)); return node; }
function render(data) {
  lastData = data; $('updated').textContent = t('updated', {value:date(data.updated_at)});
  if (data.error) notice(data.error, true, {}, true);
  else if (data.pending_update) notice('pendingUpdate', true, {device:data.pending_update.device});
  else if (message?.text === 'pendingUpdate' || (message?.raw && ['liveUnavailable', 'networkError'].includes(errorKeys[message.text]))) notice('');
  $('requests').replaceChildren(); $('request-count').textContent = data.requests.filter(r => r.status === 'pending').length;
  for (const row of data.requests) {
    const card = element('div', undefined, 'card');
    card.append(element('h3', row.device), element('p', t('computer', {value:row.computer_name || t('notProvided')})), element('p', t('fingerprint', {value:row.fingerprint})), element('p', t('requestedAt', {value:date(row.submitted_at)})), element('p', t(row.status) + ' · ' + t(row.connected ? 'connected' : 'disconnected')));
    if (row.error) card.append(element('p', translateError(row.error), 'bad'));
    if (row.status === 'pending') card.append(button(row.device, 'approve'), button(row.device, 'reject', true));
    if (row.status === 'approved') card.append(button(row.device, 'retry'));
    $('requests').append(card);
  }
  if (!data.requests.length) $('requests').append(element('p', t('noRequests')));
  $('devices').replaceChildren();
  $('removed-devices').replaceChildren();
  const removedCount = data.devices.filter(row => row.mcp_visible === false).length;
  $('removed-count').textContent = removedCount;
  $('removed-group').hidden = removedCount === 0;
  for (const row of data.devices) {
    const tr = element('tr'), name = element('td'), auth = element('td'), controls = element('td');
    name.append(element('strong', row.device), element('div', t(row.protected ? 'systemDevice' : row.transport === 'https-relay' ? 'relay' : 'direct') + (row.kind ? ' · ' + row.kind : ''), 'muted'), element('div', t('registeredAt', {value:date(row.registered_at)}), 'muted'));
    auth.append(element('span', t(row.status), 'status'), element('div', t(row.available === null ? 'unknownStatus' : row.available ? 'online' : 'offline'), row.available ? 'muted good' : 'muted'));
    const tango = element('td', row.state);
    if (row.error) tango.append(element('div', translateError(row.error), 'muted'));
    const mcp = element('td', t(row.mcp_visible === null ? 'unknown' : row.mcp_visible ? 'visible' : 'removed'));
    if (row.protected) controls.append(element('span', t('systemManaged'), 'muted'));
    else if (row.status === 'disabled') controls.append(button(row.device, 'enable'), button(row.device, 'revoke', true));
    else if (row.status === 'registered') controls.append(button(row.device, 'disable'), button(row.device, 'revoke', true));
    tr.append(name, auth, tango, mcp, controls);
    $(row.mcp_visible === false ? 'removed-devices' : 'devices').append(tr);
  }
  $('operations').replaceChildren(); $('operations-panel').hidden = !data.operations.length;
  for (const op of data.operations.slice().reverse()) $('operations').append(element('div', op.device + ' · ' + t(op.action) + ' · ' + t(op.status) + (op.error ? ' · ' + translateError(op.error) : ''), 'operation'));
}
async function refresh() { if (refreshing || !csrf) return; refreshing = true; $('refresh').disabled = true; try { render(await api('devices')); } catch (error) { notice(error.message, true, {}, true); } finally { refreshing = false; $('refresh').disabled = false; } }
async function authenticated(session) { csrf = session.csrf; $('username').textContent = session.username; $('login-password').value = ''; $('login-panel').hidden = true; $('dashboard').hidden = false; $('account').hidden = false; notice(''); await refresh(); clearInterval(timer); timer = setInterval(refresh, 10000); }
$('language').addEventListener('change', event => setLanguage(event.target.value));
$('login-form').addEventListener('submit', async event => { event.preventDefault(); const submit = event.target.querySelector('button'); submit.disabled = true; try { await authenticated(await api('login', {username:$('login-user').value,password:$('login-password').value})); } catch (error) { notice(error.message,true,{},true); } finally { submit.disabled = false; } });
$('refresh').addEventListener('click', refresh);
$('clear-removed').addEventListener('click', async event => {
  event.preventDefault(); event.stopPropagation();
  const button = $('clear-removed'); button.disabled = true;
  try {
    const result = await api('clear-removed', {});
    notice('removedCleared', false, {count: result.cleared});
    await refresh();
  } catch (error) { notice(error.message, true, {}, true); }
  finally { button.disabled = false; }
});
$('logout').addEventListener('click', async () => { try { await api('logout', {}); showLogin(); notice('loggedOut'); } catch (error) { notice(error.message,true,{},true); } });
$('password-open').addEventListener('click', () => { $('password-panel').hidden = false; $('old-password').focus(); });
$('password-cancel').addEventListener('click', () => { $('password-panel').hidden = true; });
$('password-form').addEventListener('submit', async event => { event.preventDefault(); try { await api('password', {current_password:$('old-password').value,password:$('new-password').value}); event.target.reset(); $('password-panel').hidden = true; showLogin(); notice('passwordChanged'); } catch (error) { notice(error.message,true,{},true); } });
setLanguage(language);
api('session').then(authenticated).catch(() => showLogin());
