"""
AutoScript call handlers for the TEM Alignment Twin.

Every AutoScript TEM client call arrives as (object id, method name, arguments). Calls that have a
physical counterpart in the twin are mapped onto it here, converting between AutoScript's SI units
and the twin's internal units. Every other call (STEM, EDS, EELS, energy filter, ...) is answered by
a typed state store: setters are remembered, getters return the remembered or a default value of the
correct type, and methods succeed without effect. A log line marks these as "not modelled".

Unit conventions (AutoScript side -> twin side):
    beam shift            m        2.5 µm = 1 twin unit (one screen radius at 20 kx, where the beam is aligned)
    image shift           m        2.5 µm = 1 projector-alignment unit
    beam tilt             rad      1 mrad = 1 twin unit
    gun tilt              logical  1      = 1 twin unit
    condenser stigmator   logical  1      = 1 twin unit
    objective stigmator   logical  1      = 100 nm two-fold astigmatism
    C2 aperture position  m        20 µm  = 1 twin unit
    obj. aperture pos.    m        2 µm   = 1 mrad
    defocus               m        twin objective focus offset in nm
    focus                 -1 .. 1  ±30 µm objective focus range
    intensity             0 .. 1   brightness slider / 100
    stage x, y, z         m        twin stage x, y in nm, z in µm
"""

import logging
import math
import time

import cv2
import numpy as np
from autoscript_core.common import DataType as DT, DataTypeDefinition as DTD
from autoscript_core.serialization import DynamicObjectHandle
from autoscript_tem_microscope_client import structures as st
import autoscript_tem_microscope_client._structures_metadata as md_mod

from .catalog import CALLS
from .orc_server import TwinApiError
from . import autofunctions

log = logging.getLogger("tem_twin.handlers")

_ENV = {"DataType": DT, "DataTypeDefinition": DTD}
RETURN_TYPE = {(o, m): (eval(r, _ENV) if r else None) for o, m, r, _py in CALLS}

# ------------------------------------------------------------------ twin calibration
BS_M, PROJ_M, BT_RAD, OBJSTIG_NM = 2.5e-6, 2.5e-6, 1e-3, 100.0
C2_M, OBJ_M = 20e-6, 2e-6
FOCUS_RANGE_NM = 30000.0
XO = 45.0                                     # brightness at crossover
C2_SIZES_UM = [30, 50, 100]
C2_SF = [0.55, 0.8, 1.05]
C2_NONE_SF = 1.35
OBJ_SIZES_UM = [10, 20, 40]
MAGS = [  # nominal, sub-mode, objective lens mode, half field of view (nm)
    (1500, "LM", "LM", 40000.0),
    (20000, "SA", "HM", 2500.0),
    (250000, "SA", "HM", 200.0),
    (4000000, "Mh", "HM", 12.5),
]
CAMERA = "BM-Ceta"
CAMERA_PIXEL_M = 14e-6
COUNTS_PER_S = 4000.0

_handlers = {}


def on(obj, *methods):
    def deco(fn):
        for m in methods:
            _handlers[(obj, m)] = fn
        return fn
    return deco


def hid(v):
    return getattr(v, "id", v)


def P(x, y):
    return st.Point(float(x), float(y))


class TwinMicroscope:
    """Dispatcher: (object id, method, args) -> (return type, value)."""

    def __init__(self, link):
        self.link = link
        self.store = {}
        self.defocus_ref_nm = 0.0
        self.tilt = {"a": 0.0, "b": 0.0}
        self.camera_inserted = True
        self.unmodelled = set()

    # -------------------------------------------------------------- dispatch
    def __call__(self, object_id, method, args):
        key = ("" if object_id == "TemMicroscope" else object_id.replace("TemMicroscope.", "", 1), method)
        if key not in RETURN_TYPE and key not in _handlers:
            raise TwinApiError("Unknown AutoScript call %s.%s" % key)
        rt = RETURN_TYPE.get(key)
        fn = _handlers.get(key)
        value = fn(self, *args) if fn else self._fallback(key, rt, args)
        if rt is None:
            return DT.VOID, None
        return rt, value

    def _fallback(self, key, rt, args):
        obj, method = key
        handle = hid(args[0]) if args and hasattr(args[0], "id") else None
        if key not in self.unmodelled:
            self.unmodelled.add(key)
            log.info("not modelled in the twin, answered from the state store: %s.%s", obj, method)
        if method.endswith("_SET"):
            self.store[(obj, handle, method[:-4])] = args[-1]
            return None
        if method.endswith("_GET"):
            k = (obj, handle, method[:-4])
            return self.store[k] if k in self.store else default_value(rt)
        return default_value(rt)

    # -------------------------------------------------------------- twin state helpers
    def state(self):
        return self.link.state()

    def S(self):
        return self.state()["S"]

    def set(self, **patch):
        return self.link.set(**patch)

    def half_fov_nm(self, S=None):
        S = S or self.S()
        return MAGS[S["mag"]][3]

    def c2_sf(self, S):
        return C2_SF[S["c2"]["size"]] if S["c2"]["in"] else C2_NONE_SF


def default_value(dtd):
    if dtd is None or dtd == DT.VOID:
        return None
    if dtd == DT.DOUBLE:
        return 0.0
    if dtd in (DT.INT32, DT.INT64):
        return 0
    if dtd == DT.BOOL:
        return False
    if dtd == DT.STRING:
        return ""
    if dtd == DT.BYTE_ARRAY:
        return b""
    if dtd.primary_id == DT.LIST_PRIMARY_ID:
        return []
    if dtd.primary_id == DT.STRUCTURE_PRIMARY_ID:
        return build_structure(dtd.secondary_id)
    if dtd.primary_id == DT.DYNAMIC_OBJECT_HANDLE_PRIMARY_ID:
        return DynamicObjectHandle(dtd.secondary_id)
    return None


def build_structure(name):
    cls = getattr(st, name, None) or getattr(md_mod, name, None)
    if cls is None:
        raise TwinApiError("Structure %s is not available" % name)
    inst = cls()
    for item in getattr(inst, "_items", {}).values():
        if item.value is None and not item.is_optional:
            item.set_value(default_value(item.dtd))
    return inst


# ====================================================================== service / system
@on("Service.System", "Name_GET")
def _(t): return "TEM Alignment Twin"
@on("Service.System", "SerialNumber_GET")
def _(t): return "TWIN-0001"
@on("Service.System", "Version_GET")
def _(t): return "tem-alignment-twin 1.0"
@on("Service.AutoScript.Server", "Version_GET")
def _(t): return "1.17.0 (TEM Alignment Twin server)"
@on("Service.AutoScript.Server", "IsOffline_GET")
def _(t): return False
@on("Service.AutoScript.Server.Configuration", "GetValue")
def _(t, key):
    """Twin extras through AutoScript's configuration call (for benchmarking and ML):
    "twin.metrics" -> hidden misalignments as JSON; "twin.randomize=<seed>" -> new misaligned column."""
    import json
    if key == "twin.metrics":
        return json.dumps(t.link.call("metrics"))
    if key.startswith("twin.randomize"):
        seed = key.split("=", 1)[1] if "=" in key else None
        return str(t.link.call("randomize", seed=int(seed) if seed else None))
    return ""
@on("Service.Simulator", "SetSpecimenHolder")
def _(t, holder): t.set(spec=str(holder).lower() not in ("", "none"))
@on("Service.Simulator", "SetAcceleratorOn")
def _(t): t.set(ht=200)
@on("Service.Simulator", "SetAcceleratorOff")
def _(t): t.set(ht=0)


# ====================================================================== vacuum
@on("Vacuum", "State_GET")
def _(t): return "Ready"
@on("Vacuum.ColumnValves", "Open")
def _(t): t.set(valves=True)
@on("Vacuum.ColumnValves", "Close")
def _(t): t.set(valves=False)
@on("Vacuum.ColumnValves", "State_GET")
def _(t): return "Opened" if t.S().get("valves", True) else "Closed"


# ====================================================================== source / high tension
def _ht_get(t):
    return float(t.S()["ht"]) * 1e3


def _ht_set(t, volts):
    v = float(volts)
    t.set(ht=0 if v < 60e3 else (120 if v < 160e3 else 200))


for _o in ("Source.AccelerationVoltage", "Optics.AccelerationVoltage"):
    on(_o, "Value_GET")(_ht_get)
    on(_o, "Value_SET")(_ht_set)
    on(_o, "Limits_GET")(lambda t: st.Limits(120e3, 200e3))
on("Source", "IsAcceleratorOn_GET")(lambda t: t.S()["ht"] > 0)
on("Optics", "IsAcceleratorOn_GET")(lambda t: t.S()["ht"] > 0)
on("Source", "Type_GET")(lambda t: "SFEG")


# ====================================================================== beam blanking
@on("Optics", "Blank")
@on("Optics.Blanker", "Blank")
def _(t): t.set(beam=False)
@on("Optics", "Unblank")
@on("Optics.Blanker", "Unblank")
def _(t): t.set(beam=True)
@on("Optics", "IsBeamBlanked_GET")
@on("Optics.Blanker", "IsBeamBlanked_GET")
def _(t): return not t.S()["beam"]


# ====================================================================== optical modes
@on("Optics", "OpticalMode_GET")
def _(t): return "Tem"
@on("Optics", "OpticalMode_SET")
def _(t, mode):
    if mode != "Tem":
        raise TwinApiError("Only TEM mode is modelled in the twin; STEM is not available yet.")
@on("Optics", "ProjectorMode_GET")
def _(t): return "Imaging" if t.S()["mode"] == "img" else "Diffraction"
@on("Optics", "ProjectorMode_SET")
def _(t, mode): t.set(mode="img" if mode == "Imaging" else "diff")
@on("Optics", "ObjectiveLensMode_GET")
def _(t): return MAGS[t.S()["mag"]][2]
@on("Optics", "ObjectiveLensMode_SET")
def _(t, mode):
    S = t.S()
    if mode == "LM" and S["mag"] != 0:
        t.set(mag=0)
    elif mode == "HM" and S["mag"] == 0:
        t.set(mag=1)
    elif mode not in ("LM", "HM"):
        raise TwinApiError("Objective lens mode %s is not modelled" % mode)
@on("Optics", "IlluminationMode_GET")
def _(t): return "Parallel"
@on("Optics", "ProbeMode_GET")
def _(t): return "MicroProbe"


# ====================================================================== intensity, spot, beam size
@on("Optics", "Intensity_GET")
def _(t): return t.S()["bright"] / 100.0
@on("Optics", "Intensity_SET")
def _(t, v): t.set(bright=float(np.clip(v, 0, 1)) * 100.0)
@on("Optics", "SpotSizeIndex_GET")
def _(t): return int(t.S()["spot"])
@on("Optics", "SpotSizeIndex_SET")
def _(t, v):
    if not 1 <= int(v) <= 11:
        raise TwinApiError("Spot size index must be between 1 and 11")
    t.set(spot=int(min(v, 5)))
@on("Optics", "BeamDiameter_GET")
def _(t):
    S = t.S()
    s = (S["bright"] - XO) / 55 * 1.5 * t.c2_sf(S)
    return 2 * abs(s) * t.half_fov_nm(S) * 1e-9
@on("Optics", "BeamDiameter_SET")
def _(t, d):
    S = t.S()
    s = float(d) / 1e-9 / 2 / t.half_fov_nm(S)
    t.set(bright=float(np.clip(XO + s * 55 / (1.5 * t.c2_sf(S)), 0, 100)))
@on("Optics", "ConvergenceAngle_GET")
def _(t): return float(t.state()["illum"])


# ====================================================================== focus
def _defocus_get(t): return (t.S()["dfc"] - t.defocus_ref_nm) * 1e-9
def _defocus_set(t, v): t.set(dfc=float(v) / 1e-9 + t.defocus_ref_nm)
def _focus_get(t): return t.S()["dfc"] / FOCUS_RANGE_NM
def _focus_set(t, v): t.set(dfc=float(np.clip(v, -1, 1)) * FOCUS_RANGE_NM)
def _reset_defocus(t): t.defocus_ref_nm = t.S()["dfc"]


for _o in ("Optics", "Optics.Focusing.Tem"):
    on(_o, "Defocus_GET")(_defocus_get)
    on(_o, "Defocus_SET")(_defocus_set)
    on(_o, "Focus_GET")(_focus_get)
    on(_o, "Focus_SET")(_focus_set)
    on(_o, "ResetDefocus")(_reset_defocus)


# ====================================================================== magnification / camera length
def _mag_data(i):
    nom, sub, olm, _R = MAGS[i]
    label = ("%g kx" % (nom / 1e3)) if nom >= 1e4 else ("%d x" % nom)
    return st.MagnificationData(float(nom), float(nom) * 0.98, 0.0, label, sub, olm)


@on("Optics.Magnification", "AvailableValues_GET")
def _(t): return [_mag_data(i) for i in range(len(MAGS))]
@on("Optics.Magnification", "Value_GET")
def _(t): return _mag_data(t.S()["mag"])
@on("Optics.Magnification", "Value_SET")
def _(t, v):
    noms = [m[0] for m in MAGS]
    i = int(np.argmin([abs(math.log(max(v.nominal, 1) / n)) for n in noms]))
    if abs(noms[i] - v.nominal) / noms[i] > 0.05:
        raise TwinApiError("Magnification %g is not available; use magnification.available_values" % v.nominal)
    t.set(mag=i)
@on("Optics.Magnification", "Increase")
def _(t, steps):
    i = int(np.clip(t.S()["mag"] + int(steps), 0, len(MAGS) - 1))
    t.set(mag=i)
    return _mag_data(i)


_CL = lambda: st.CameraLengthData(0.25, 0.25, 0.0, "250 mm", "HM")
on("Optics.CameraLength", "AvailableValues_GET")(lambda t: [_CL()])
on("Optics.CameraLength", "Value_GET")(lambda t: _CL())
on("Optics.CameraLength", "Value_SET")(lambda t, v: None)
on("Optics.CameraLength", "Increase")(lambda t, steps: _CL())


# ====================================================================== deflectors
def _pt(key, scale):
    def get(t):
        v = t.S()[key]
        return P(v["x"] * scale, v["y"] * scale)

    def set_(t, p):
        cur = t.S()[key]
        t.set(**{key: {"x": cur["x"] if p.x is None else p.x / scale, "y": cur["y"] if p.y is None else p.y / scale}})
    return get, set_


DEFLECTORS = {"GunTilt": ("gun", 1.0), "BeamShift": ("bs", BS_M), "BeamTilt": ("btilt", BT_RAD), "ImageShift": ("proj", PROJ_M)}
for _name, (_key, _scale) in DEFLECTORS.items():
    _g, _s = _pt(_key, _scale)
    on("Optics.Deflectors", _name + "_GET")(_g)
    on("Optics.Deflectors", _name + "_SET")(_s)


@on("Optics.Deflectors", "GetAvailableDeflectors")
def _(t): return ["GunTilt", "GunShift", "BeamTilt", "BeamShift", "ImageTilt", "ImageShift"]
@on("Optics.Deflectors", "GetDeflectorValue")
def _(t, name):
    if name in DEFLECTORS:
        return _pt(*DEFLECTORS[name])[0](t)
    return t.store.get(("Optics.Deflectors", None, name), P(0, 0))
@on("Optics.Deflectors", "SetDeflectorValue")
def _(t, name, p):
    if name in DEFLECTORS:
        return _pt(*DEFLECTORS[name])[1](t, p)
    t.store[("Optics.Deflectors", None, name)] = p


# ====================================================================== stigmators
for _name, (_key, _scale) in {"CondenserStigmator": ("c2stig", 1.0), "ObjectiveStigmator": ("objstig", 1.0 / OBJSTIG_NM)}.items():
    _g, _s = _pt(_key, _scale)
    on("Optics.Stigmators", _name + "_GET")(_g)
    on("Optics.Stigmators", _name + "_SET")(_s)


# ====================================================================== apertures
APERTURES = {
    "C2": dict(key="c2", scale=C2_M, sizes=C2_SIZES_UM),
    "Objective": dict(key="obj", scale=OBJ_M, sizes=OBJ_SIZES_UM),
}


@on("Optics.ApertureMechanisms", "GetAvailable")
def _(t): return ["C1", "C2", "Objective", "SA"]
@on("Optics.ApertureMechanisms", "GetMechanism")
def _(t, name):
    if name not in ("C1", "C2", "Objective", "SA"):
        raise TwinApiError("Aperture mechanism %s is not present on this column" % name)
    return DynamicObjectHandle(name)
for _n in ("C1", "C2", "SA"):
    on("Optics.ApertureMechanisms", _n + "_GET")(lambda t, _n=_n: DynamicObjectHandle(_n))
on("Optics.ApertureMechanisms", "Objective_GET")(lambda t: DynamicObjectHandle("Objective"))
@on("Optics.ApertureMechanisms", "C3_GET")
def _(t): raise TwinApiError("This column has no C3 aperture (two-condenser system)")


def _ap(handle):
    return APERTURES.get(hid(handle))


def _ap_struct(name, um):
    return st.Aperture("%d um" % um, "Circular", um * 1e-6)


def _ap_method(name, real):
    def fn(t, handle, *args):
        a = _ap(handle)
        if a is None:
            return t._fallback(("DynamicObjects.ApertureMechanism", name), RETURN_TYPE[("DynamicObjects.ApertureMechanism", name)], [handle, *args])
        return real(t, a, *args)
    on("DynamicObjects.ApertureMechanism", name)(fn)


_ap_method("Insert", lambda t, a: t.set(**{a["key"]: {"in": True}}))
_ap_method("Retract", lambda t, a: t.set(**{a["key"]: {"in": False}}))
_ap_method("InsertionState_GET", lambda t, a: "Inserted" if t.S()[a["key"]]["in"] else "Retracted")
_ap_method("IsRetractable_GET", lambda t, a: True)
_ap_method("IsEnabled_GET", lambda t, a: True)
_ap_method("Enable", lambda t, a: None)
_ap_method("Disable", lambda t, a: None)
_ap_method("ResetPositions", lambda t, a: None)
_ap_method("Position_GET", lambda t, a: P(t.S()[a["key"]]["x"] * a["scale"], t.S()[a["key"]]["y"] * a["scale"]))
_ap_method("Position_SET", lambda t, a, p: t.set(**{a["key"]: {"x": p.x / a["scale"], "y": p.y / a["scale"]}}))
_ap_method("Apertures_GET", lambda t, a: [_ap_struct(a["key"], um) for um in a["sizes"]])
_ap_method("Aperture_GET", lambda t, a: _ap_struct(a["key"], a["sizes"][t.S()[a["key"]]["size"]]))


def _ap_set(t, a, aperture):
    sizes = a["sizes"]
    if aperture.diameter:
        i = int(np.argmin([abs(u * 1e-6 - aperture.diameter) for u in sizes]))
    else:
        names = ["%d um" % u for u in sizes]
        if aperture.name not in names:
            raise TwinApiError("Aperture %s not available; choose from %s" % (aperture.name, names))
        i = names.index(aperture.name)
    t.set(**{a["key"]: {"size": i}})


_ap_method("Aperture_SET", _ap_set)


# ====================================================================== beam stopper, screen
@on("Optics.BeamStopper", "Insert", "HalfInsert")
def _(t): t.set(stop=True)
@on("Optics.BeamStopper", "Retract")
def _(t): t.set(stop=False)
@on("Optics.BeamStopper", "InsertionState_GET")
def _(t): return "Inserted" if t.S()["stop"] else "Retracted"
@on("Detectors.Screen", "Insert")
def _(t): t.set(display="screen")
@on("Detectors.Screen", "Retract")
def _(t): t.set(display="camera")
@on("Detectors.Screen", "Position_GET")
def _(t): return "Inserted" if t.S()["display"] == "screen" else "Retracted"
@on("Detectors.Screen", "MeasureCurrent")
def _(t): return float(t.state()["current"]) * 1e-9


# ====================================================================== lenses
LENSES = ["C1", "C2", "OBJECTIVE", "DIFFRACTION", "INTERMEDIATE", "P1", "P2"]
on("Optics.Lenses", "GetAvailable")(lambda t: LENSES)


@on("Optics.Lenses", "GetLens")
def _(t, name):
    if name not in LENSES:
        raise TwinApiError("Lens %s is not present; available: %s" % (name, LENSES))
    return DynamicObjectHandle(name)
@on("DynamicObjects.Lens", "Name_GET")
def _(t, h): return hid(h)
@on("DynamicObjects.Lens", "Value_GET")
def _(t, h):
    n = hid(h)
    if n == "C2":
        return t.S()["bright"] / 100.0
    if n == "OBJECTIVE":
        return _focus_get(t)
    return t.store.get(("Lens", n), 0.0)
@on("DynamicObjects.Lens", "Value_SET")
def _(t, h, v):
    n = hid(h)
    if n == "C2":
        return t.set(bright=float(np.clip(v, 0, 1)) * 100)
    if n == "OBJECTIVE":
        return _focus_set(t, v)
    t.store[("Lens", n)] = float(v)


# ====================================================================== stage
def _stage_pos(t):
    s = t.S()["stage"]
    return st.StagePosition(s["x"] * 1e-9, s["y"] * 1e-9, s["z"] * 1e-6, t.tilt["a"], t.tilt["b"])


def _stage_move(t, p, relative):
    s = t.S()["stage"]
    new = dict(s)
    for ax, key, scale in (("x", "x", 1e-9), ("y", "y", 1e-9), ("z", "z", 1e-6)):
        v = getattr(p, ax)
        if v is not None:
            new[key] = (s[key] if relative else 0.0) + v / scale
    for ax in ("a", "b"):
        v = getattr(p, ax)
        if v is not None:
            t.tilt[ax] = (t.tilt[ax] if relative else 0.0) + v
    t.set(stage=new)


on("Specimen.Stage", "Position_GET")(_stage_pos)
on("Specimen.Stage", "AbsoluteMove", "AbsoluteMoveSafe")(lambda t, p: _stage_move(t, p, False))
on("Specimen.Stage", "RelativeMove", "RelativeMoveSafe")(lambda t, p, *rest: _stage_move(t, p, True))
on("Specimen.Stage", "IsMoving_GET")(lambda t: False)
on("Specimen.Stage", "IsEnabled_GET")(lambda t: True)
on("Specimen.Stage", "GetHolderType")(lambda t: "DoubleTilt")


@on("Specimen.Stage", "GetAxisLimits")
def _(t, axis):
    return {"X": st.Limits(-1e-3, 1e-3), "Y": st.Limits(-1e-3, 1e-3), "Z": st.Limits(-375e-6, 375e-6),
            "A": st.Limits(-math.radians(70), math.radians(70)), "B": st.Limits(-math.radians(30), math.radians(30))}[axis]


# ====================================================================== detectors and acquisition
on("Detectors", "CameraDetectors_GET")(lambda t: [CAMERA])
on("Detectors", "ScanningDetectors_GET")(lambda t: [])
on("Detectors", "EdsDetectors_GET")(lambda t: [])
on("Detectors", "EelsDetectors_GET")(lambda t: [])


@on("Detectors", "GetCameraDetector")
def _(t, name):
    if name != CAMERA:
        raise TwinApiError("Camera %s is not present; available: %s" % (name, [CAMERA]))
    return DynamicObjectHandle(CAMERA)
for _m, _f in {
    "Name_GET": lambda t, h: CAMERA, "DisplayName_GET": lambda t, h: "Ceta (twin)",
    "IsInsertable_GET": lambda t, h: True, "IsDoseSensitive_GET": lambda t, h: False, "IsOperational_GET": lambda t, h: True,
    "PixelSize_GET": lambda t, h: P(CAMERA_PIXEL_M, CAMERA_PIXEL_M),
    "ExposureTimeLimits_GET": lambda t, h: st.Limits(0.001, 10.0),
    "InsertionState_GET": lambda t, h: "Inserted" if t.camera_inserted else "Retracted",
    "GetSupportedImageSizes": lambda t, h: [st.CameraImageSize(s, "Full") for s in (256, 512, 1024, 2048, 4096)],
}.items():
    on("DynamicObjects.CameraDetector", _m)(_f)
@on("DynamicObjects.CameraDetector", "Insert")
def _(t, h): t.camera_inserted = True
@on("DynamicObjects.CameraDetector", "Retract")
def _(t, h): t.camera_inserted = False


def acquire_image(t, camera, size, exposure):
    if camera != CAMERA:
        raise TwinApiError("Camera %s is not present; available: %s" % (camera, [CAMERA]))
    if not t.camera_inserted:
        raise TwinApiError("Camera is retracted")
    size = int(size) or 1024
    if size not in (128, 256, 512, 1024, 2048, 4096):
        raise TwinApiError("Unsupported image size %d" % size)
    frame, info = t.link.frame()
    counts = np.random.poisson(np.clip(frame, 0, None) * float(exposure) * COUNTS_PER_S).astype(np.float32)
    img = cv2.resize(counts, (size, size), interpolation=cv2.INTER_LINEAR if size >= 256 else cv2.INTER_AREA)
    img = np.clip(img, 0, 65535).astype(np.uint16)
    S = info["S"]
    px_m = 2 * MAGS[S["mag"]][3] * 1e-9 / size
    meta = st.AdornedImageMetadata()
    meta.binary_result = md_mod.AdornedImageMetadataBinaryResult(pixel_size=P(px_m, px_m), bits_per_pixel=16)
    meta.optics = md_mod.AdornedImageMetadataOptics(
        acceleration_voltage=S["ht"] * 1e3, defocus=(S["dfc"] - t.defocus_ref_nm) * 1e-9,
        nominal_magnification=float(MAGS[S["mag"]][0]), spot_index=int(S["spot"]),
        projector_mode="Imaging" if S["mode"] == "img" else "Diffraction", optical_mode="Tem",
        beam_shift=P(S["bs"]["x"] * BS_M, S["bs"]["y"] * BS_M), beam_tilt=P(S["btilt"]["x"] * BT_RAD, S["btilt"]["y"] * BT_RAD),
        illumination_intensity_normalized=S["bright"] / 100.0, screen_current=float(info["current"]) * 1e-9,
        spherical_aberration=1.2e-3)
    meta.acquisition = md_mod.AdornedImageMetadataAcquisition(acquisition_date_time=time.strftime("%Y-%m-%dT%H:%M:%S"))
    return st.AdornedImage(img, meta)


on("Acquisition", "AcquireCameraImage")(acquire_image)
on("Acquisition", "AcquireCameraImageAdvanced")(lambda t, s: acquire_image(t, s.camera_detector, s.size, s.exposure_time))


@on("Acquisition", "AcquireCameraSeries")
def _(t, camera, size, exposure, count, *rest):
    return [acquire_image(t, camera, size, exposure) for _ in range(int(count))]


@on("Acquisition", "AcquireCameraSeriesAdvanced")
def _(t, s, count, *rest):
    return [acquire_image(t, s.camera_detector, s.size, s.exposure_time) for _ in range(int(count))]


def _stem_unavailable(t, *a):
    raise TwinApiError("STEM, EDS and EELS acquisition are not modelled in the twin yet.")


_stem_unavailable.unavailable = True


for _m in ("AcquireStemImage", "AcquireStemImages", "AcquireStemImagesAdvanced", "AcquireStemSegmentImages",
           "StartAcquireStemImagesAdvanced", "AcquireStemData", "AcquireStemDataAdvanced"):
    on("Acquisition", _m)(_stem_unavailable)
for _o, _m in (("Analysis.Eds", "AcquireSpectrum"), ("Analysis.Eds", "AcquireSpectrumImage"),
               ("Analysis.Eels", "AcquireSpectra"), ("Analysis.Eels", "AcquireSpectrumImage")):
    on(_o, _m)(_stem_unavailable)


# ====================================================================== auto functions
@on("AutoFunctions", "RunBeamCentering")
def _(t, *settings):
    r = t.link.call("auto", name="beamshift", timeout=120)
    d = float(r["offset"]) * t.half_fov_nm() * 1e-9
    return st.RunBeamCenteringResults("Good" if r["ok"] else "Improved", d, r.get("log", ""))


@on("AutoFunctions", "RunApertureCentering")
def _(t, settings):
    kind = settings.aperture_mechanism_type
    if kind != "C2":
        return st.RunApertureCenteringResults("Bad", [], "Only the C2 aperture can be centred automatically in the twin.")
    r = t.link.call("auto", name="beam", timeout=180)
    d = float(r["offset"]) * t.half_fov_nm() * 1e-9
    return st.RunApertureCenteringResults("Good" if r["ok"] else "Improved", [st.CenteringResult("C2", d)], r.get("log", ""))


@on("AutoFunctions", "RunBeamTiltAutoFocus")
def _(t, settings):
    return autofunctions.beam_tilt_autofocus(t, settings)


@on("AutoFunctions", "RunRotationCenterAlignment")
def _(t, *settings):
    return autofunctions.rotation_center(t, settings[0] if settings else None)


@on("AutoFunctions", "RunObjectiveAutoStigmator")
def _(t, settings):
    return autofunctions.objective_autostigmator(t, settings)


def _auto_unavailable(name, result):
    def fn(t, *a):
        r = build_structure(result)
        if hasattr(r, "quality"):
            r.quality = "Bad"
        if hasattr(r, "message"):
            r.message = "%s is not modelled in the twin." % name
        return r
    fn.unavailable = True
    return fn


for _m, _r in (("RunStemAutoFocus", "RunStemAutoFocusResults"), ("RunAutoComaCorrection", "RunAutoComaCorrectionResults"),
               ("RunOptiStem", "RunOptiStemResults"), ("RunImageCorrectorAutoTuning", "RunImageCorrectorResults"),
               ("RunProbeCorrectorAutoTuning", "RunProbeCorrectorResults")):
    on("AutoFunctions", _m)(_auto_unavailable(_m, _r))


def implemented_calls():
    """Calls that act on the twin's physics."""
    return sorted(k for k, f in _handlers.items() if k in RETURN_TYPE and not getattr(f, "unavailable", False))


def unavailable_calls():
    """Calls answered with an explicit 'not modelled' error or result."""
    return sorted(k for k, f in _handlers.items() if k in RETURN_TYPE and getattr(f, "unavailable", False))
