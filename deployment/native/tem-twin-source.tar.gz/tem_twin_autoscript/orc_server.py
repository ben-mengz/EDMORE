"""
Server side of the AutoScript ORC protocol, so the unmodified AutoScript TEM client can connect to the twin.

The AutoScript client talks to its server over TCP with framed messages (see autoscript_core.framed_transport):

    frame   = 'F' 'T' <type:1> 0x00 <sequence:int32> <length:int32> <content>
    message = <message type:1> <sequence:int32> <fields...>

The client library only ships the client half of the message codec (it serialises requests and
deserialises responses). This module implements the mirror half: it reads session inquiries,
join requests, call requests, keep-alives and session ends, and writes session offers, join
responses, call results and call errors. Values are (de)serialised with autoscript_core's own
AdvancedValueSerializer / AdvancedValueDeserializer, so types match what the client expects.
"""

import itertools
import logging
import socket
import threading
import traceback
import uuid

from autoscript_core.common import CallParameters, DataType
from autoscript_core.framed_transport import Frame, FrameSocket, FrameSocketState, FrameSocketException
from autoscript_core.orc.crates import MessageType
from autoscript_core.serialization import (AdvancedValueSerializer, BasicValueDeserializer, BasicValueSerializer,
                                           BytesBuilder, BytesChopper)

log = logging.getLogger("tem_twin.orc")


class TwinApiError(Exception):
    """Raised by handlers; delivered to the client as an AutoScript ApiException."""

    GENERAL_ERROR = 0x0001

    def __init__(self, message, code=GENERAL_ERROR):
        super().__init__(message)
        self.code = code


class _ServerFrameSocket(FrameSocket):
    def __init__(self, tcp_socket):
        super().__init__()
        self._tcp_socket = tcp_socket
        self.state = FrameSocketState.CONNECTED


def _parameter_deserializer():
    """The client's own deserializer, configured with every AutoScript structure and dynamic-object type."""
    from autoscript_tem_microscope_client import TemMicroscopeClient
    return TemMicroscopeClient()._TemMicroscopeClient__deserializer


class OrcServer:
    """Threaded TCP server; one thread per client connection."""

    def __init__(self, dispatcher, host="0.0.0.0", port=7521):
        self.dispatcher = dispatcher          # callable(object_id, method_name, args) -> (DataTypeDefinition, value)
        self.host, self.port = host, port
        self._serializer = AdvancedValueSerializer()
        self._deserializer = _parameter_deserializer()
        self._sessions = set()
        self._call_lock = threading.Lock()    # one call at a time, like the real server
        self._stop = threading.Event()
        self._listener = None

    # ---------------------------------------------------------------- lifecycle
    def _listen(self):
        self._listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._listener.bind((self.host, self.port))
        self._listener.listen(8)
        self.port = self._listener.getsockname()[1]
        log.info("AutoScript twin server listening on %s:%d", self.host, self.port)

    def serve_forever(self):
        if self._listener is None:
            self._listen()
        while not self._stop.is_set():
            try:
                conn, addr = self._listener.accept()
            except OSError:
                break
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            threading.Thread(target=self._serve_connection, args=(conn, addr), daemon=True).start()

    def start(self):
        self._listen()
        t = threading.Thread(target=self.serve_forever, daemon=True)
        t.start()
        return t

    def stop(self):
        self._stop.set()
        if self._listener:
            try:
                self._listener.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._listener.close()

    # ---------------------------------------------------------------- connection
    def _serve_connection(self, conn, addr):
        fs = _ServerFrameSocket(conn)
        seq = itertools.count(1)
        log.info("Client connected from %s:%d", *addr)
        try:
            while True:
                frame = fs.receive_frame()
                ch = BytesChopper(frame.content, 0)
                mtype = BasicValueDeserializer.deserialize_byte(ch)
                BasicValueDeserializer.deserialize_int32(ch)  # sender sequence number

                if mtype == MessageType.SESSION_INQUIRY:
                    session = uuid.uuid4().hex[:16]
                    self._send(fs, MessageType.SESSION_OFFER, next(seq), lambda b: BasicValueSerializer.serialize_string(session, b))

                elif mtype == MessageType.SESSION_JOIN_REQUEST:
                    desired = BasicValueDeserializer.deserialize_string(ch)
                    self._sessions.add(desired)
                    self._send(fs, MessageType.SESSION_JOIN_RESPONSE, next(seq), lambda b: BasicValueSerializer.serialize_string(desired, b))

                elif mtype == MessageType.CALL_REQUEST:
                    session_id = BasicValueDeserializer.deserialize_string(ch)
                    call_id = BasicValueDeserializer.deserialize_int32(ch)
                    BasicValueDeserializer.deserialize_byte(ch)  # attempt number
                    object_id = BasicValueDeserializer.deserialize_string(ch)
                    method = BasicValueDeserializer.deserialize_string(ch)
                    pbytes = BasicValueDeserializer.deserialize_byte_array(ch)
                    self._handle_call(fs, seq, session_id, call_id, object_id, method, pbytes)

                elif mtype == MessageType.KEEP_ALIVE:
                    pass

                elif mtype == MessageType.SESSION_END:
                    break
                else:
                    log.warning("Ignoring message type 0x%02X", mtype)
        except FrameSocketException:
            pass
        except Exception:
            log.error("Connection error:\n%s", traceback.format_exc())
        finally:
            log.info("Client %s:%d disconnected", *addr)
            fs.disconnect()

    def _handle_call(self, fs, seq, session_id, call_id, object_id, method, pbytes):
        try:
            args = self._decode_parameters(pbytes)
            with self._call_lock:
                dtd, value = self.dispatcher(object_id, method, args)
            result = CallParameters([dtd], [value])
            self._serializer.serialize_values(result)
            payload = result.serialized_bytes

            def body(b):
                BasicValueSerializer.serialize_string(session_id, b)
                BasicValueSerializer.serialize_int32(call_id, b)
                BasicValueSerializer.serialize_byte_array(payload, b)
            self._send(fs, MessageType.CALL_RESULT, next(seq), body)
        except Exception as ex:  # report every failure to the client as an ApiException
            code = getattr(ex, "code", TwinApiError.GENERAL_ERROR)
            text = str(ex) if isinstance(ex, TwinApiError) else "%s: %s" % (type(ex).__name__, ex)
            if not isinstance(ex, TwinApiError):
                log.error("%s.%s failed:\n%s", object_id, method, traceback.format_exc())

            def body(b):
                BasicValueSerializer.serialize_string(session_id, b)
                BasicValueSerializer.serialize_int32(call_id, b)
                BasicValueSerializer.serialize_int32(code, b)
                BasicValueSerializer.serialize_string(text, b)
                BasicValueSerializer.serialize_byte_array(b"", b)
            self._send(fs, MessageType.CALL_ERROR, next(seq), body)

    def _decode_parameters(self, pbytes):
        args = []
        if not pbytes:
            return args
        ch = BytesChopper(pbytes, 0)
        while ch.bytes_left() > 0:
            _dtd, value = self._deserializer.deserialize_value(ch)
            args.append(value)
        return args

    @staticmethod
    def _send(fs, mtype, sequence, write_body):
        b = BytesBuilder()
        b.add_bytes(bytes([mtype]))
        BasicValueSerializer.serialize_int32(sequence, b)
        write_body(b)
        fs.send_frame(Frame(b.get_data()))


VOID = (DataType.VOID, None)
