"""Expose the AutoScript calls that have real Digital Twin implementations.

The gateway deliberately invokes the generated AutoScript Python client.  It
does not read Twin state or use the browser bridge directly.  The Twin handler
catalogue is used only to decide which calls are real UI-backed capabilities;
placeholder state-store calls and explicitly unavailable calls are excluded.
"""

from __future__ import annotations

import base64
import inspect
import re
import uuid
from dataclasses import dataclass
from numbers import Number
from typing import Any, Callable

import numpy as np

from .catalog import CALLS
from .handlers import implemented_calls


def _snake(value: str) -> str:
    value = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", value)
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", value)
    return re.sub(r"_+", "_", value.replace(".", "_")).strip("_").lower()


@dataclass(frozen=True)
class AutoScriptCall:
    object_id: str
    protocol_method: str
    python_name: str

    @property
    def is_dynamic(self) -> bool:
        return self.object_id.startswith("DynamicObjects.")

    @property
    def operation(self) -> str:
        if self.protocol_method.endswith("_GET"):
            return "get"
        if self.protocol_method.endswith("_SET"):
            return "set"
        return "call"

    @property
    def tool_name(self) -> str:
        return f"autoscript_{_snake(self.object_id)}_{_snake(self.protocol_method)}"

    @property
    def display_name(self) -> str:
        return f"{self.object_id}.{self.protocol_method}"


_PYTHON_NAME = {(object_id, method): python_name for object_id, method, _return, python_name in CALLS}
UI_AUTOSCRIPT_CALLS = tuple(
    AutoScriptCall(object_id, method, _PYTHON_NAME[(object_id, method)])
    for object_id, method in implemented_calls()
)


def _annotation_type_name(annotation: Any) -> str | None:
    if annotation is inspect.Signature.empty:
        return None
    text = annotation if isinstance(annotation, str) else getattr(annotation, "__name__", str(annotation))
    candidates = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", text)
    ignored = {"Union", "List", "Tuple", "Optional", "None", "list", "tuple", "dict", "str", "int", "float", "bool"}
    return next((candidate for candidate in candidates if candidate not in ignored), None)


class AutoScriptGateway:
    """Invoke selected calls through a shared AutoScriptToolService client."""

    def __init__(self, service: Any):
        self.service = service
        self._handles: dict[str, Any] = {}
        self._client_identity: int | None = None

    @staticmethod
    def _resolve_static(client: Any, object_id: str) -> Any:
        target = client
        for segment in object_id.split("."):
            target = getattr(target, _snake(segment))
        return target

    def _remember_handle(self, value: Any) -> dict[str, Any]:
        handle_id = uuid.uuid4().hex
        self._handles[handle_id] = value
        return {
            "handle_id": handle_id,
            "type": type(value).__name__,
            "value": repr(value),
        }

    def _encode(self, value: Any, depth: int = 0) -> Any:
        if isinstance(value, np.generic):
            return value.item()
        if value is None or isinstance(value, (str, bool, int, float)):
            return value
        if isinstance(value, bytes):
            return {"encoding": "base64", "data": base64.b64encode(value).decode("ascii")}
        if isinstance(value, np.ndarray):
            result: dict[str, Any] = {
                "type": "ndarray",
                "shape": list(value.shape),
                "dtype": str(value.dtype),
                "size": int(value.size),
            }
            if value.ndim == 2:
                result["image_ref"] = self.service.calculator.remember(value)
            if value.size:
                numeric = value.astype(np.float64, copy=False)
                result.update(min=float(np.min(numeric)), max=float(np.max(numeric)), mean=float(np.mean(numeric)))
            if value.size <= 64:
                result["data"] = value.tolist()
            return result
        if isinstance(value, dict):
            return {str(key): self._encode(item, depth + 1) for key, item in value.items()}
        if isinstance(value, (list, tuple, set)):
            return [self._encode(item, depth + 1) for item in value]
        if hasattr(value, "_handle"):
            return self._remember_handle(value)
        if hasattr(value, "data") and isinstance(value.data, np.ndarray):
            return {"type": type(value).__name__, "data": self._encode(value.data, depth + 1),
                    "pixel_size_m": float(value.metadata.binary_result.pixel_size.x),
                    "metadata": self._encode(getattr(value, "metadata", None), depth + 1)}
        if isinstance(value, Number):
            return float(value)
        if depth < 5:
            try:
                parameters = inspect.signature(type(value)).parameters
            except (TypeError, ValueError):
                parameters = {}
            fields = {}
            for name in parameters:
                if hasattr(value, name):
                    try:
                        fields[name] = self._encode(getattr(value, name), depth + 1)
                    except Exception:
                        continue
            if fields:
                return {"type": type(value).__name__, **fields}
        return {"type": type(value).__name__, "value": str(value)}

    @staticmethod
    def _descriptor(target: Any, name: str) -> Any:
        return getattr(type(target), name, None)

    @staticmethod
    def _structure_class(type_name: str | None) -> type[Any] | None:
        if not type_name:
            return None
        from autoscript_tem_microscope_client import structures

        candidate = getattr(structures, type_name, None)
        return candidate if inspect.isclass(candidate) else None

    def _decode(self, value: Any, annotation: Any = inspect.Signature.empty) -> Any:
        if isinstance(value, list):
            return [self._decode(item) for item in value]
        if not isinstance(value, dict):
            return value
        explicit_type = value.get("__type__")
        type_name = explicit_type or _annotation_type_name(annotation)
        structure = self._structure_class(type_name)
        if structure is not None:
            payload = {key: self._decode(item) for key, item in value.items() if key != "__type__"}
            return structure(**payload)
        return {key: self._decode(item) for key, item in value.items()}

    def _decode_arguments(self, function: Callable[..., Any], arguments: list[Any] | dict[str, Any] | None):
        signature = inspect.signature(function)
        parameters = list(signature.parameters.values())
        if arguments is None:
            return (), {}
        if isinstance(arguments, dict):
            decoded = {}
            by_name = signature.parameters
            for name, value in arguments.items():
                annotation = by_name[name].annotation if name in by_name else inspect.Signature.empty
                decoded[name] = self._decode(value, annotation)
            return (), decoded
        decoded = []
        for index, value in enumerate(arguments):
            annotation = parameters[index].annotation if index < len(parameters) else inspect.Signature.empty
            decoded.append(self._decode(value, annotation))
        return tuple(decoded), {}

    def invoke(
        self,
        spec: AutoScriptCall,
        *,
        arguments: list[Any] | dict[str, Any] | None = None,
        value: Any = None,
        handle_id: str | None = None,
    ) -> dict[str, Any]:
        with self.service.client() as client:
            identity = id(client)
            if identity != self._client_identity:
                self._handles.clear()
                self._client_identity = identity
            if spec.is_dynamic:
                if not handle_id:
                    raise ValueError(f"{spec.display_name} requires handle_id")
                try:
                    target = self._handles[handle_id]
                except KeyError as exc:
                    raise ValueError("Unknown or stale AutoScript handle_id") from exc
            else:
                target = self._resolve_static(client, spec.object_id)

            if spec.operation == "get":
                result = getattr(target, spec.python_name)
            elif spec.operation == "set":
                descriptor = self._descriptor(target, spec.python_name)
                annotation = inspect.Signature.empty
                if isinstance(descriptor, property) and descriptor.fset is not None:
                    setter_parameters = list(inspect.signature(descriptor.fset).parameters.values())
                    if len(setter_parameters) > 1:
                        annotation = setter_parameters[1].annotation
                setattr(target, spec.python_name, self._decode(value, annotation))
                result = getattr(target, spec.python_name)
            else:
                function = getattr(target, spec.python_name)
                positional, keyword = self._decode_arguments(function, arguments)
                result = function(*positional, **keyword)

        return {
            "autoscript_call": spec.display_name,
            "operation": spec.operation,
            "result": self._encode(result),
        }


def _description(spec: AutoScriptCall) -> str:
    dynamic = " Requires a handle_id returned by another AutoScript tool." if spec.is_dynamic else ""
    if spec.operation == "set":
        inputs = " Pass the property value in value; structures may be JSON objects."
    elif spec.operation == "call":
        inputs = " Pass positional arguments as a JSON list or named arguments as a JSON object."
    else:
        inputs = ""
    return f"Invoke the UI-backed AutoScript call {spec.display_name}.{dynamic}{inputs}"


def register_ui_autoscript_tools(mcp: Any, service: Any) -> AutoScriptGateway:
    gateway = AutoScriptGateway(service)

    for spec in UI_AUTOSCRIPT_CALLS:
        if spec.operation == "get" and spec.is_dynamic:
            def tool(handle_id: str, _spec: AutoScriptCall = spec) -> dict[str, Any]:
                return gateway.invoke(_spec, handle_id=handle_id)
        elif spec.operation == "get":
            def tool(_spec: AutoScriptCall = spec) -> dict[str, Any]:
                return gateway.invoke(_spec)
        elif spec.operation == "set" and spec.is_dynamic:
            def tool(handle_id: str, value: Any, _spec: AutoScriptCall = spec) -> dict[str, Any]:
                return gateway.invoke(_spec, handle_id=handle_id, value=value)
        elif spec.operation == "set":
            def tool(value: Any, _spec: AutoScriptCall = spec) -> dict[str, Any]:
                return gateway.invoke(_spec, value=value)
        elif spec.is_dynamic:
            def tool(
                handle_id: str,
                arguments: list[Any] | dict[str, Any] | None = None,
                _spec: AutoScriptCall = spec,
            ) -> dict[str, Any]:
                return gateway.invoke(_spec, handle_id=handle_id, arguments=arguments)
        else:
            def tool(
                arguments: list[Any] | dict[str, Any] | None = None,
                _spec: AutoScriptCall = spec,
            ) -> dict[str, Any]:
                return gateway.invoke(_spec, arguments=arguments)

        tool.__name__ = spec.tool_name
        tool.__doc__ = _description(spec)
        mcp.tool(name=spec.tool_name, description=tool.__doc__, exclude_args=["_spec"])(tool)

    return gateway
