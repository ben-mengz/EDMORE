"""Small cross-process operation lock shared by GUI and Tango clients."""

from __future__ import annotations

import os
import threading
import time
from pathlib import Path


class OperationLock:
    def __init__(self, path: str | os.PathLike | None, timeout_seconds: float = 300.0):
        self.path = Path(path) if path else None
        self.timeout_seconds = max(0.1, float(timeout_seconds))
        self._thread_lock = threading.RLock()
        self._local = threading.local()
        self._file = None

    @classmethod
    def from_environment(cls) -> "OperationLock":
        return cls(os.environ.get("TEM_NODE_OPERATION_LOCK"))

    def _try_lock(self) -> bool:
        self._file.seek(0)
        if os.name == "nt":
            import msvcrt

            try:
                msvcrt.locking(self._file.fileno(), msvcrt.LK_NBLCK, 1)
                return True
            except OSError:
                return False
        import fcntl

        try:
            fcntl.flock(self._file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except BlockingIOError:
            return False

    def _unlock(self) -> None:
        self._file.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(self._file.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(self._file.fileno(), fcntl.LOCK_UN)

    def __enter__(self):
        self._thread_lock.acquire()
        depth = getattr(self._local, "depth", 0)
        if depth:
            self._local.depth = depth + 1
            return self
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._file = self.path.open("a+b")
            if self._file.tell() == 0:
                self._file.write(b"\0")
                self._file.flush()
            deadline = time.monotonic() + self.timeout_seconds
            while not self._try_lock():
                if time.monotonic() >= deadline:
                    self._file.close()
                    self._file = None
                    self._thread_lock.release()
                    raise TimeoutError(
                        f"Instrument operation lock was busy for {self.timeout_seconds:g} seconds"
                    )
                time.sleep(0.05)
        self._local.depth = 1
        return self

    def __exit__(self, exc_type, exc, traceback):
        depth = self._local.depth - 1
        self._local.depth = depth
        if depth == 0 and self._file is not None:
            try:
                self._unlock()
            finally:
                self._file.close()
                self._file = None
        self._thread_lock.release()
