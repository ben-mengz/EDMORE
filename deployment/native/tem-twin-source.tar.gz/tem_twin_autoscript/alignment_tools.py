"""Six bounded alignment operations, reusing the AutoScript-only source algorithm."""
import time
from .autoalign import AutoAligner, STEPS, Stopped


ALIGNMENT_TOOLS = {
    "align_beam_and_c2": "beam",
    "align_gun_tilt": "gun",
    "align_condenser_stigmation": "c2stig",
    "align_eucentric_z": "z",
    "align_rotation_center": "rot",
    "align_objective_stigmation": "ostig",
}


class VerifiedAligner(AutoAligner):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.deadline = time.monotonic() + 210

    def _check(self):
        super()._check()
        if time.monotonic() >= self.deadline:
            raise Stopped("Alignment time budget exhausted")

    def _ht(self):
        # Do not silently assume a voltage when fitting real image evidence.
        return float(self.m.source.acceleration_voltage.value)


def run_alignment(microscope, phase, settle_seconds=0.0, motion_timeout_seconds=60.0):
    """Run one original phase and recheck it before restoring working conditions.

    Each call has its own scope, so interruption between tools cannot leave an
    open sequence context. Rotation explicitly uses eucentric objective focus,
    as it would after the Z phase in the original full sequence.
    """
    if phase not in {sid for sid, _, _ in STEPS}:
        raise ValueError("Unknown alignment phase")
    logs, evidence = [], {}
    settle_seconds = max(0.0, float(settle_seconds))
    aligner = VerifiedAligner(microscope, log=logs.append, settle_seconds=settle_seconds)
    original_step = getattr(aligner, "step_" + phase)

    def execute(fix):
        if phase == "rot":
            microscope.optics.focus = 0.0
        status, detail = original_step(fix)
        evidence["correction"] = {"status": status, "detail": detail}
        if status == "fixed":
            deadline = time.monotonic() + motion_timeout_seconds
            stage = microscope.specimen.stage
            while bool(getattr(stage, "is_moving", False)):
                if time.monotonic() >= deadline:
                    raise TimeoutError(
                        f"Stage did not settle within {motion_timeout_seconds:g} seconds"
                    )
                time.sleep(0.1)
            if settle_seconds:
                time.sleep(max(0.25, settle_seconds))
            status, detail = original_step(False)
        evidence["verification"] = {"status": status, "detail": detail}
        return status, detail

    setattr(aligner, "step_" + phase, execute)
    error = None
    try:
        result = aligner.run(fix=True, steps=[phase])
        status, detail = result.get(phase, ("err", "Alignment did not return a result"))
    except Exception as exc:
        status, detail = "err", str(exc)
        error = str(exc)
    restoration_errors = [line for line in logs if "could not restore working conditions:" in line]
    restored = not restoration_errors and any("Auto align (AutoScript): start" in line for line in logs)
    verified = status == "ok" and evidence.get("verification", {}).get("status") == "ok" and restored
    return {
        "phase": phase,
        "success": verified,
        "verified": verified,
        "status": "passed" if verified else "error" if status == "err" or not restored else "not_converged" if status == "off" else "unmeasurable",
        "detail": detail,
        "completion_condition": next(tol for sid, _, tol in STEPS if sid == phase) + ("; C2 is checked only when inserted" if phase == "beam" else ""),
        **evidence,
        "working_conditions_restored": restored,
        "restoration_errors": restoration_errors,
        "error": error,
        "logs": logs,
        "retry_policy": "Do not automatically retry; verify instrument state after interruption or error.",
    }
