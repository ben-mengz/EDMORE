"""Private RPC to the single server-owned simulation engine (no browser connection)."""

import base64
import concurrent.futures
import itertools
import json
import os
from pathlib import Path
import subprocess
import threading

import numpy as np

from .orc_server import TwinApiError


class TwinLink:
    def __init__(self, **_legacy):
        self._pending = {}
        self._lock = threading.Lock()
        self._ids = itertools.count(1)
        self._connected = threading.Event()
        self.on_event = None
        self.process = subprocess.Popen(
            [os.environ.get("TEM_TWIN_NODE", "node"), str(Path(__file__).parent / "backend" / "runner.mjs")],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, encoding="utf-8", bufsize=1,
        )
        self._reader = threading.Thread(target=self._receive, daemon=True)
        self._reader.start()
        if not self.wait_connected(float(os.environ.get("TEM_TWIN_ENGINE_STARTUP_TIMEOUT", "15"))):
            self.close()
            raise TwinApiError("Backend engine did not start. Run npm ci in tem_twin_autoscript/backend.")

    def _receive(self):
        try:
            for line in self.process.stdout:
                try:
                    message = json.loads(line)
                except json.JSONDecodeError:
                    break
                if message.get("ready"):
                    self._connected.set()
                elif "event" in message:
                    if self.on_event:
                        threading.Thread(target=self.on_event, args=(message["event"],), daemon=True).start()
                else:
                    with self._lock:
                        future = self._pending.pop(message.get("id"), None)
                    if future and not future.done():
                        if message.get("ok"):
                            future.set_result(message.get("result"))
                        else:
                            future.set_exception(TwinApiError("Twin: " + str(message.get("error"))))
        finally:
            self._connected.clear()
            with self._lock:
                pending, self._pending = self._pending, {}
            for future in pending.values():
                if not future.done():
                    future.set_exception(TwinApiError("Backend engine stopped"))

    @property
    def connected(self):
        return self._connected.is_set() and self.process.poll() is None

    def wait_connected(self, timeout=None):
        return self._connected.wait(timeout)

    def call(self, cmd, timeout=60.0, **args):
        future = concurrent.futures.Future()
        with self._lock:
            if not self.connected:
                raise TwinApiError("Backend engine is unavailable")
            mid = next(self._ids)
            self._pending[mid] = future
            try:
                self.process.stdin.write(json.dumps({"id": mid, "cmd": cmd, "args": args}, allow_nan=False) + "\n")
                self.process.stdin.flush()
            except Exception:
                self._pending.pop(mid, None)
                raise
        try:
            return future.result(timeout)
        finally:
            with self._lock:
                self._pending.pop(mid, None)

    def send_event(self, **msg):
        self.call("event", value=msg)

    def state(self):
        return self.call("state")

    def set(self, **patch):
        return self.call("set", patch=patch)

    def frame(self):
        result = self.call("acquire")
        data = np.frombuffer(base64.b64decode(result["data"]), dtype=np.float32).reshape(result["h"], result["w"]).copy()
        return data, result

    def close(self):
        self._connected.clear()
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self._reader.join(timeout=2)
        self.process.stdin.close()
        self.process.stdout.close()
