# TEM Alignment Twin — AutoScript server

Control the TEM Alignment Twin with the **unmodified Thermo Fisher AutoScript TEM client**.
The server speaks AutoScript's own client/server protocol on port 7521, so a script written for the
microscope PC runs against the twin by connecting to `localhost` instead:

**Authors:** Manish Kumar (manish.kumar.1@hu-berlin.de) and Zhao Meng
(zhaomenq@physik.hu-berlin.de), Humboldt-Universität zu Berlin.

```python
from autoscript_tem_microscope_client import TemMicroscopeClient
microscope = TemMicroscopeClient()
microscope.connect("localhost")            # instead of the microscope PC's address
microscope.optics.magnification.value = microscope.optics.magnification.available_values[2]
image = microscope.acquisition.acquire_camera_image("BM-Ceta", 1024, 1.0)
```

```
Skills -> MCP :8767 -> Tango device -> AutoScript client -> TCP :7521 -> Node engine
                                                                     |
Browsers <- rendered images and controls <- GUI :8768 <----------------+
Browsers -> bounded control events -------> GUI :8768 -> same engine
```

The backend owns the only simulation state and performs all physics and image rendering.
The GUI only displays server-generated images and controls and sends input events. Opening,
closing or reconnecting a browser cannot create, replace or stop the simulation.
There is no browser bridge on 8766 and no Chromium/debugging-port dependency.
The existing JavaScript model runs in Node, using jsdom for its legacy control/view adapter
and a native Canvas renderer. Neither the model nor that adapter is served to browsers.

## Install

Python 3.11 or newer and Node.js 20 or newer.

```bash
# 1. AutoScript client from your licensed wheels (asyncroscopy/stubs/AutoScript_v_1.17)
pip install thermoscientific_logging-1.3.0-py3-none-any.whl autoscript_core-1.3.0-py3-none-any.whl \
            autoscript_tem_microscope_client-1.17.0-py3-none-any.whl
# 2. this package
pip install -e path/to/tem_twin_autoscript
# backend engine dependencies (run from this package directory)
npm ci --prefix tem_twin_autoscript/backend
# complete GUI + Tango + MCP stack
pip install -e 'path/to/tem_twin_autoscript[cloud]'
```

## Run

```bash
python -m tem_twin_autoscript.cloud        # engine + AutoScript + Tango + MCP + GUI
python -m tem_twin_autoscript              # engine + AutoScript only, no GUI needed
python -m tem_twin_autoscript --help
```

Open `http://127.0.0.1:8768/` for the GUI. The server loads the specimen and switches on
200 kV and the beam at startup, leaving hidden misalignments to correct. AutoScript-only
mode accepts `--as-is` to skip preparation. Existing local HTML entrypoints redirect to
this GUI rather than running another simulation.

Cloud deployment uses `python -m tem_twin_autoscript.cloud --host 0.0.0.0` inside the
existing VPN/network boundary. `--state-file /data/state.json` (or `TEM_TWIN_STATE_FILE`)
enables atomic checkpoints and restart restoration. Interrupted alignments are not resumed
automatically. Protect both GUI and MCP with the deployment's network access controls;
these endpoints do not implement per-user authentication themselves.

## AutoScript MCP tools

The cloud supervisor starts the single Tango MCP gateway automatically. To run
only a gateway against already-running registered devices:

```bash
tem-twin-mcp --devices /path/to/mcp-devices.json
```

The default Streamable HTTP endpoint is `http://127.0.0.1:8767/mcp`.
Listening on another interface is explicit:

```bash
tem-twin-mcp --devices /path/to/mcp-devices.json --http-host 0.0.0.0 --http-port 8767
```

The MCP now adapts the supported **asyncroscopy ElectronMicroscope commands**
onto named Tango commands that use the shared official AutoScript client. No
DATA/Tiled service or additional simulator is started. The generated `autoscript_*` tools
are no longer registered; the vendor SDK and ORC transport remain intact.
See [ASYNCROSCOPY_TOOLS.md](ASYNCROSCOPY_TOOLS.md) for the mapping, limitations,
six-tool overlap review, and argument changes.

The MCP also exposes six bounded alignment tools, one per original Python phase.
EDMORE's Alignment Sequence first asks the user to select a device, then approves
six calibration calls in order; numeric loops run inside
the tools, while Harness retains approval and execution-result review. See
[ALIGNMENT_TOOLS.md](ALIGNMENT_TOOLS.md) for tool names, verification and timeout
semantics. Atomic controls and the pure calculation tool remain available.
`get_twin_metrics` and `randomize_twin` are simulation-only benchmarking tools
and must not be used as alignment evidence.

See [TANGO_DEPLOYMENT.md](TANGO_DEPLOYMENT.md) for device registration, routing,
network boundaries and the simulation-only database limitation.

## What maps to what

| AutoScript | Twin | Units on the AutoScript side |
|---|---|---|
| `optics.deflectors.beam_shift` | beam shift | m (2.5 µm = one screen radius at 20 kx) |
| `optics.deflectors.beam_tilt` | beam tilt / rotation centre | rad |
| `optics.deflectors.gun_tilt` | gun tilt | logical |
| `optics.deflectors.image_shift` | projector alignment (diffraction shift) | m |
| `optics.stigmators.condenser_stigmator` | C2 stigmator | logical |
| `optics.stigmators.objective_stigmator` | objective stigmator | logical, 1 = 100 nm two-fold astigmatism |
| `optics.intensity`, `beam_diameter` | brightness (C2) | 0–1, m |
| `optics.spot_size_index` | spot size | 1–11 (twin models 1–5) |
| `optics.defocus`, `focus`, `reset_defocus()` | objective focus | m, −1…1 (±30 µm), `focus = 0` is eucentric focus |
| `optics.magnification` | 1500×, 20 kx, 250 kx, 4 Mx | `MagnificationData` |
| `optics.projector_mode` | imaging / diffraction | `ProjectorMode` |
| `optics.aperture_mechanisms.C2`, `.Objective` | apertures: insert, retract, position, size | m, `Aperture` |
| `optics.beam_stopper` | beam stop | |
| `optics.blank()`, `unblank()`, `vacuum.column_valves` | beam, column valves | |
| `source.acceleration_voltage` | high tension | V (120 or 200 kV) |
| `specimen.stage` | stage x, y, z (α, β stored) | m, rad |
| `detectors.screen` | fluorescent screen display, `measure_current()` | A |
| `acquisition.acquire_camera_image(...)` | camera frame → `AdornedImage` (uint16, pixel size and optics in metadata) | |

Auto functions run real image-based algorithms. They use only camera frames and control changes, never the twin's
hidden state:

| AutoScript | Method | Accuracy on the twin |
|---|---|---|
| `run_aperture_centering(C2)` | centre the focused beam with beam shift, the spread beam with the C2 aperture, iterate | beam and C2 < 0.005 screen radii |
| `run_beam_centering()` | focused beam centred with beam shift | < 0.005 screen radii |
| `run_beam_tilt_auto_focus()` | image shift under ±beam tilt equals Δf·tilt; coarse-to-fine tilt 0.25→3 mrad | ±2 nm at 4 Mx |
| same, `focus_method=FocusMethod.STAGE_Z` | same measurement, corrected with stage Z: **eucentric focus** | 36 µm → 0.02 µm |
| `run_rotation_center_alignment()` | image shift under a focus wobble gives the beam-tilt offset | ≈ 0.3–0.4 mrad |
| `run_objective_auto_stigmator()` | fits Thon-ring defocus in 24 directions, fits Δf₀ + a cos2θ + b sin2θ, calibrates the stigmator response, corrects | 25–40 nm → < 2.5 nm |

Two alignments have no AutoScript auto function, so `examples/alignment_steps.py` implements them with plain
AutoScript calls. The same code runs on the microscope:

| Function | Method | Result on the twin |
|---|---|---|
| `gun_tilt(m)` | pattern search on `optics.deflectors.gun_tilt`, maximising `detectors.screen.measure_current()` | gun tilt 0.65 → 0.005, current ×8 |
| `condenser_stigmation(m)` | beam set to ~20 % of the field, pattern search on `optics.stigmators.condenser_stigmator` minimising the ellipticity of the beam in camera images | C2 astigmatism 0.57 → 0.003 |

Coma, STEM, OptiSTEM and corrector tuning return a result with quality `Bad`. STEM, EDS and EELS acquisition raise
`ApiException`. The remaining calls (energy filter, EDS/EELS detectors, piezo stage, cooling holder, …) are
accepted and answered from a typed state store, so every AutoScript function can be called without errors.
See [COVERAGE.md](COVERAGE.md) for the full list of 395 calls.

## Auto align with AutoScript calls only

`tem_twin_autoscript/autoalign.py` aligns the column using nothing but AutoScript TEM calls, so the same code
runs on the twin and on an AutoScript-enabled microscope. Each step measures its alignment and corrects only if it
is out of tolerance. Afterwards it restores magnification, intensity, defocus, projector mode, stage X/Y and the
screen. Only stage Z keeps its eucentric correction.

```bash
python -m tem_twin_autoscript.autoalign                 # align
python -m tem_twin_autoscript.autoalign --check         # measure and report only
python -m tem_twin_autoscript.autoalign --steps beam,z  # beam, gun, c2stig, z, rot, ostig
```

```python
from tem_twin_autoscript.autoalign import AutoAligner
results = AutoAligner(microscope, cs=1.2e-3).run(fix=True)       # {step: (status, text)}
```

| Step | Measures with | Corrects with | Tolerance |
|---|---|---|---|
| beam | `acquire_camera_image` (lit-area centroid) at `beam_diameter` 2 % and 90 % of the field | `deflectors.beam_shift`, `aperture_mechanisms.C2.position` (2×2 calibrated) | spot 0.02, spread 0.01 of half field |
| gun | `detectors.screen.measure_current()` | `deflectors.gun_tilt` (pattern search) | < 0.5 % gain available |
| c2stig | beam ellipticity at 20 % of the field | `stigmators.condenser_stigmator` | ellipticity < 0.03 |
| z | `run_beam_tilt_auto_focus(focus_method=Stage_Z)`; the stage is moved back if within tolerance or in check mode | stage Z | 100 nm |
| rot | image shift under a ±defocus wobble, response to beam tilt calibrated by central differences | `deflectors.beam_tilt` (damped) | 0.8 mrad |
| ostig | Thon-ring defocus in 24 directions, robust fit of the two-fold term (Cs and λ from HT) | `run_objective_auto_stigmator` | 3 nm |

In the twin page, the **Auto align** panel has an engine switch. **In page** uses the page's own JavaScript
routines. **AutoScript** (available when the server is running) asks the server to run `autoalign.py` as an
ordinary AutoScript client and shows each step's result in the panel. **Check only** measures without changing
anything. **Simulate drift** perturbs the column without touching the controls, so re-alignment from a nearly
aligned state can be tested.

On a real instrument: keep the focused-beam exposure low (camera protection), note that `C2.position` needs a
motorised aperture, and pass the objective Cs.

## Ground truth for benchmarking

Two extra configuration keys go through AutoScript's own call:

```python
cfg = microscope.service.autoscript.server.configuration
cfg.get_value("twin.metrics")          # JSON with the hidden misalignments (beam shift, C2, Z, rotation centre, ...)
cfg.get_value("twin.randomize=42")     # draw a new misaligned column
```

`examples/04_random_benchmark.py` uses these to score an alignment routine over random starts.

## Files

- `tem_twin_autoscript/orc_server.py`: server half of the AutoScript protocol (session handshake, calls, errors),
  using `autoscript_core`'s own serialisers.
- `tem_twin_autoscript/handlers.py`: AutoScript calls → twin, with unit conversion and the typed fallback.
- `tem_twin_autoscript/autoalign.py`: auto alignment with AutoScript calls only (CLI and GUI engine).
- `tem_twin_autoscript/autofunctions.py`: image-based beam-tilt autofocus, rotation centre, objective stigmator.
- `tem_twin_autoscript/twin_link.py`: WebSocket link to the twin page.
- `tem_twin_autoscript/catalog.py`: names and return types of all 395 AutoScript calls (generated from the client).
- `tem_twin_autoscript/web/tem-alignment-twin.html`: the twin.

No AutoScript code is included here. The server imports your installed `autoscript_core` and
`autoscript_tem_microscope_client` at runtime.
