# Tango deployment

The cloud supervisor owns one Node engine, its AutoScript endpoint, a Tango
database, one TEMTwinDevice, and one MCP gateway. GUI and native subscription
paths are unchanged. There is no client-side simulator.

Default ports: AutoScript 7521, GUI 8768, native stream 8769, MCP 8767, Tango
database 10000, Tango device 10001. Tango and AutoScript bind loopback only;
only the existing GUI/native/MCP ports use --host. Local desktop Demo uses the
same supervisor. TEM_TWIN_TANGO_DIR controls persistent Tango data storage.

The managed database is PyTango's SQLite implementation, as used by asyncroscopy.
Upstream labels it experimental and not for mission-critical use:
https://tango-controls.readthedocs.io/projects/pytango/en/latest/how-to/databaseds.html
This deployment is for simulation. Before real hardware, deploy a supported
Tango database, explicit access controls, local interlocks and validated drivers.
Do not open Tango administration ports to the public Internet.

## Routing

list_devices returns configured targets and availability. select_device accepts
the user's explicit choice, checks the AutoScript connection through Tango, and
returns device. It does NOT change a process-global active device. Each operation
requires device, including all six alignment commands. No implicit default,
URL supplied by a tool caller, retry, or fallback to another device is permitted.

The six named align_* commands exist on the Tango device. They retain current
bounded synchronous semantics, a 210-second algorithm budget and 300-second
Tango timeout. MCP cancellation/timeout is NOT a hardware stop. Do not retry
until the actual outcome is checked. Async task IDs and remote cancellation are
not part of this migration. GUI controls remain on their existing input path;
this change does not introduce a cross-GUI/hardware operational lock.

## Multiple devices

For microscope computers that run only the Windows TEM node, keep Tango entirely
on the cloud server and configure `TEM_TWIN_HTTP_NODES` with a server-private
JSON file. Example:

```json
{
  "edmore/tem/windows_simulator_01": {
    "node_url": "http://141.20.47.165:8778",
    "node_token": "SERVER_PRIVATE_TOKEN_AT_LEAST_32_CHARACTERS",
    "operation_timeout_seconds": 300
  }
}
```

On the managed deployment this file is `/data/tango/http-nodes.json`. Keep it
mode 600 and never commit it. At startup the cloud supervisor registers a
`TEMHTTPProxyDevice` for every entry and exposes all registered devices through
the one cloud MCP endpoint. A remote computer can be offline during cloud
startup; discovery remains available, while selection and operations fail
closed until its node API returns with the configured identity.

An administrator can pass --tango-extra-devices extra-devices.json when starting
the cloud supervisor. Example (the second device must already be running):

```json
{"edmore/tem/twin_b": "tango://reachable-host:10000/edmore/tem/twin_b"}
```

The built-in edmore/tem/twin cannot be replaced by this file. The supervisor
writes mcp-devices.json into its Tango data directory. Refresh/restart the gateway
after changing registrations. A standalone gateway uses --devices with a full
mapping and can route to devices in different Tango databases. Identical device
classes remain separate by instance name, avoiding asyncroscopy's class-key
collision. Same-named tools must have compatible schemas; startup rejects conflicts.

Each added adapter must implement DescribeTools protocol 1, named JSON-string
commands, structured results, and actual device identity in result meta. An
arbitrary existing Tango device needs an adapter; it is not automatically
compatible. No existing second user Twin or real instrument is auto-registered.
To attach lab devices later, configure network reachability/VPN and explicit
endpoints; the current loopback-only database is deliberately not externally
reachable. Device servers, not the database, carry instrument requests.

## Workflow compatibility

The full Skill is selection + six phases. Each public single-phase Skill is
selection + its phase. Internal phase Skills bind device to
{{select_device.device}} using the existing result binding mechanism. The
selection uses ask mode and a confirmation gate; no LLM-inferred default.
The existing approved-argument gate rejects a substituted target. Missing
selection evidence blocks execution. Review and success/failure transitions stay
unchanged; no Harness core changes are required.

Refresh MCP discovery and start new plans after upgrading. Previously approved
plans lack the new selection step/required device argument and must not resume.
